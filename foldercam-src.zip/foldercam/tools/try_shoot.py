#!/usr/bin/env python3
"""自校正驱动：不靠猜坐标，直接从截图里按像素找快门。

为什么需要它：
  1) 我一开始把 MIUI 相机快门坐标目测成 (600,1898)，其实那在取景框里，
     点了半天相机根本没拍 —— 所以「照片不在 App 里」可能只是没拍到。
  2) 宿主 App 会和我们的 App 抢前台，任何跨工具调用的点击都会打偏，
     所以整条链路必须在一次进程内跑完。
  3) MIUI 的 OneShotImageCapture 拍完会自动回到调用方，所以
     「前台回到我们 App」就是拍摄成功的强信号。
"""
import os
import re
import struct
import subprocess
import sys
import time
import zlib

PKG = "com.harness.foldercam"
CAM = "com.android.camera"
FOLDER = "workA"
REL = "Pictures/FolderCam/" + FOLDER + "/"
SHOT_PNG = "build/cam_for_measure.png"


def sh(cmd, timeout=90):
    if isinstance(cmd, str):
        cmd = ["/system/bin/sh", "-c", cmd]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (p.stdout or "") + (p.stderr or "")
    except Exception as e:
        return "[sh error] %s" % e


def top():
    out = sh("dumpsys activity activities 2>/dev/null | grep -m1 ResumedActivity")
    m = re.search(r"u0 ([A-Za-z0-9_.]+)/([A-Za-z0-9_.$]+)", out)
    if not m:
        return "", ""
    pkg, act = m.group(1), m.group(2)
    return pkg, (pkg + act if act.startswith(".") else act)


def wait_for(pred, seconds, label, quiet=False):
    end = time.time() + seconds
    last = None
    while time.time() < end:
        cur = top()
        last = cur
        if pred(*cur):
            return True
        time.sleep(0.4)
    if not quiet:
        print("   !! 超时: %s (当前 %s/%s)" % (label, last[0], last[1]))
    return False


# ---------------------------------------------------------------- 像素找快门

def load_png(path):
    d = open(path, "rb").read()
    pos, w, h, ct = 8, 0, 0, 0
    idat = b""
    while pos < len(d):
        ln = struct.unpack(">I", d[pos:pos + 4])[0]
        tag = d[pos + 4:pos + 8]
        body = d[pos + 8:pos + 8 + ln]
        if tag == b"IHDR":
            w, h = struct.unpack(">II", body[:8])
            ct = body[9]
        elif tag == b"IDAT":
            idat += body
        pos += 12 + ln
    raw = zlib.decompress(idat)
    ch = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}[ct]
    stride = w * ch
    rows, prev, p = [], bytearray(stride), 0
    for _ in range(h):
        f = raw[p]
        p += 1
        line = bytearray(raw[p:p + stride])
        p += stride
        if f == 1:
            for i in range(ch, stride):
                line[i] = (line[i] + line[i - ch]) & 255
        elif f == 2:
            for i in range(stride):
                line[i] = (line[i] + prev[i]) & 255
        elif f == 3:
            for i in range(stride):
                a = line[i - ch] if i >= ch else 0
                line[i] = (line[i] + ((a + prev[i]) >> 1)) & 255
        elif f == 4:
            for i in range(stride):
                a = line[i - ch] if i >= ch else 0
                b = prev[i]
                c = prev[i - ch] if i >= ch else 0
                pa, pb, pc = abs(b - c), abs(a - c), abs(a + b - 2 * c)
                pr = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
                line[i] = (line[i] + pr) & 255
        rows.append(bytes(line))
        prev = line
    return w, h, ch, rows


def find_shutter(path):
    """在截图下半部分找最亮的白色团块，返回它的中心。快门就是最亮的大圆环。"""
    w, h, ch, rows = load_png(path)
    print("   截图 %dx%d" % (w, h))
    best = None
    # 只看下半部分
    for y in range(int(h * 0.5), h, 4):
        line = rows[y]
        run, start = 0, 0
        for x in range(0, w, 4):
            i = x * ch
            white = line[i] > 225 and line[i + 1] > 225 and line[i + 2] > 225
            if white:
                if run == 0:
                    start = x
                run += 1
            else:
                if run > 20:
                    width = run * 4
                    cx = start + width / 2
                    # 优先找又宽又靠下的（快门在底部中间）
                    score = width + (y - h * 0.5) * 0.5
                    if best is None or score > best[0]:
                        best = (score, int(cx), y, width)
                run = 0
        if run > 20:
            width = run * 4
            cx = start + width / 2
            score = width + (y - h * 0.5) * 0.5
            if best is None or score > best[0]:
                best = (score, int(cx), y, width)
    if not best:
        return None
    return best[1], best[2], best[3]


# ----------------------------------------------------------------

def photos():
    out = sh("content query --uri content://media/external/images/media "
             "--projection _id:_display_name:relative_path:is_pending:_size "
             "--where \"relative_path='%s'\"" % REL)
    return [l.strip() for l in out.splitlines() if l.startswith("Row:")]


def main():
    print("=== 1. 进 ShootActivity ===")
    for i in range(4):
        sh("am force-stop %s" % PKG)
        time.sleep(1.5)
        sh("am start -n %s/.MainActivity" % PKG)
        if wait_for(lambda p, a: a.endswith("ShootActivity"), 10, "ShootActivity", quiet=True):
            break
        print("   (第 %d 次：还没进，重试)" % (i + 1))
    pkg, act = top()
    print("   前台: %s/%s" % (pkg, act))
    if not act.endswith("ShootActivity"):
        return 1

    print("=== 2. 点 App 快门 (600,2455) ===")
    sh("input tap 600 2455")
    if not wait_for(lambda p, a: p.startswith(CAM), 20, "系统相机"):
        return 1
    print("   相机: %s" % top()[1])

    print("=== 3. 截图并找相机快门 ===")
    time.sleep(3.5)
    if top()[0] != CAM:
        print("   !! 相机已经不在前台了")
        return 1
    os.makedirs("build", exist_ok=True)
    sh('screencap -p "%s"' % os.path.abspath(SHOT_PNG))
    if not os.path.exists(SHOT_PNG):
        print("   !! 截图失败")
        return 1
    found = find_shutter(SHOT_PNG)
    if not found:
        print("   !! 没找到快门，退回 (600,2451)")
        sx, sy = 600, 2451
    else:
        sx, sy, sw = found
        print("   找到快门 @(%d,%d) 宽=%d" % (sx, sy, sw))

    print("=== 4. 点相机快门 ===")
    sh("input tap %d %d" % (sx, sy))
    ok = wait_for(lambda p, a: p == PKG, 25, "回到我们 App")
    print("   拍摄后前台: %s/%s  (自动返回=%s)" % (top()[0], top()[1], ok))

    print("=== 5. 目标文件夹 ===")
    rows = photos()
    for r in rows[-5:]:
        print("   " + r[:150])
    if not rows:
        print("   (空)")

    print("=== 6. App 决策日志 ===")
    for line in sh("logcat -d -v brief -s FolderCam").strip().splitlines()[-10:]:
        print("   " + line.strip()[:170])
    return 0 if rows else 1


if __name__ == "__main__":
    sys.exit(main())
