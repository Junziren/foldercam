#!/usr/bin/env python3
"""按坐标操控 Chrome（截图 -> 目视定位 -> 点击）。

为什么不用 uiautomator：宿主聊天 App 是悬浮窗，uiautomator dump 只能看到
悬浮窗自己的节点（实测 81 个全是 com.androidharness.app），Chrome 的界面读不到。
所以只能截图 + 按屏幕坐标点。

屏幕是 1200x2608。截图也是这个尺寸，看到的图是按比例缩小的，
换算：真实坐标 = 图中坐标 * (1200 / 图宽)。

子命令：
  tap X Y            点击真实屏幕坐标
  key CODE           按键（如 4=返回, 66=回车, 111=ESC）
  swipe X1 Y1 X2 Y2  滑动
  shot [名字]         截图
  text STR           输入 ASCII 文本（空格用 %s）
"""
import os
import re
import struct
import subprocess
import sys
import time
import zlib

SHOTS = "build/chrome"
W, H = 1200, 2608


def sh(cmd, timeout=90):
    if isinstance(cmd, str):
        cmd = ["/system/bin/sh", "-c", cmd]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (p.stdout or "") + (p.stderr or "")
    except Exception as e:
        return "[sh error] %s" % e


def png_size(path):
    try:
        d = open(path, "rb").read(33)
        return struct.unpack(">II", d[16:24])
    except Exception:
        return (0, 0)


def shot(name="now"):
    os.makedirs(SHOTS, exist_ok=True)
    p = os.path.abspath(os.path.join(SHOTS, name + ".png"))
    if os.path.exists(p):
        os.remove(p)
    sh('screencap -p "%s"' % p)
    if not os.path.exists(p):
        print("  截图失败")
        return None
    w, h = png_size(p)
    print("  截图 %s (%dx%d)" % (p, w, h))
    return p


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    cmd = sys.argv[1]
    a = sys.argv[2:]

    if cmd == "tap":
        x, y = int(a[0]), int(a[1])
        sh("input tap %d %d" % (x, y))
        print("  点击 (%d,%d)" % (x, y))
        time.sleep(float(a[2]) if len(a) > 2 else 1.8)

    elif cmd == "key":
        sh("input keyevent %d" % int(a[0]))
        print("  按键 %s" % a[0])
        time.sleep(1.2)

    elif cmd == "swipe":
        sh("input swipe %d %d %d %d %s" % (int(a[0]), int(a[1]), int(a[2]), int(a[3]),
                                           a[4] if len(a) > 4 else "300"))
        print("  滑动 (%s,%s)->(%s,%s)" % tuple(a[:4]))
        time.sleep(1.6)

    elif cmd == "shot":
        shot(a[0] if a else "now")

    elif cmd == "text":
        sh('input text "%s"' % a[0].replace(" ", "%s"))
        print("  输入 %s" % a[0])
        time.sleep(1.0)

    else:
        print(__doc__)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
