#!/usr/bin/env python3
"""判定实验：MIUI 相机认不认 file:// 形式的 EXTRA_OUTPUT。

已知：
  * 正常打开相机拍照 -> 存盘正常（.HEIC）
  * 通过 ACTION_IMAGE_CAPTURE 调用（content:// 的 EXTRA_OUTPUT）-> 照片丢失，
    相机日志显示它把 savePath 硬编码成 DCIM/Camera，且 DB 更新影响 0 行。

本实验：用 file:// 的 EXTRA_OUTPUT 再试一次，看相机是否按指定路径写。
  认 -> App 改用 file:// 输出（我们现在有 MANAGE_EXTERNAL_STORAGE，能直接建文件）
  不认 -> 改用「正常打开相机 + 事后把新照片搬进目标文件夹」
"""
import os
import re
import subprocess
import sys
import time

J = os.path.join
S = os.sep + J("storage", "emulated", "0")
TARGET = J(S, "DCIM", "Camera", "_extra_output_test.jpg")
OUTDIR = "build/exp3"


def sh(cmd, timeout=90):
    if isinstance(cmd, str):
        cmd = ["/system/bin/sh", "-c", cmd]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (p.stdout or "") + (p.stderr or "")
    except Exception as e:
        return "[sh error] %s" % e


def shot(name):
    os.makedirs(OUTDIR, exist_ok=True)
    p = os.path.abspath(J(OUTDIR, name))
    sh('screencap -p "%s"' % p)
    return p


def nodes():
    x = "/data/local/tmp/fc-exp3.xml"
    try:
        if os.path.exists(x):
            os.remove(x)
    except OSError:
        pass
    sh('uiautomator dump "%s" >/dev/null 2>&1' % x, timeout=30)
    try:
        xml = open(x, encoding="utf-8", errors="ignore").read()
    except OSError:
        return []
    out = []
    for m in re.finditer(r"<node\b([^>]*?)/?>", xml, re.S):
        a = dict(re.findall(r'([\w:-]+)="([^"]*)"', m.group(1)))
        b = re.match(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", a.get("bounds", ""))
        if not b:
            continue
        x1, y1, x2, y2 = (int(v) for v in b.groups())
        out.append({"text": (a.get("text") or "").strip(),
                    "desc": (a.get("content-desc") or "").strip(),
                    "pkg": a.get("package", ""),
                    "cx": (x1 + x2) // 2, "cy": (y1 + y2) // 2,
                    "w": x2 - x1, "h": y2 - y1})
    return out


def main():
    if os.path.exists(TARGET):
        os.remove(TARGET)
    print("目标文件: %s" % TARGET)
    print("预先存在: %s" % os.path.exists(TARGET))

    print("=== 1. 用 file:// 作为 EXTRA_OUTPUT 拉起相机 ===")
    sh("am force-stop com.android.camera")
    time.sleep(1)
    r = sh('am start -W -a android.media.action.IMAGE_CAPTURE '
           '--eu output "file://%s"' % TARGET)
    print("   " + (r.strip().splitlines() or [""])[-1][:120])
    time.sleep(6)
    print("   截图:", shot("x1_launch.png"))

    print("=== 2. 点快门 (600,1755) ===")
    sh("input tap 600 1755")
    time.sleep(5)
    print("   截图:", shot("x2_shutter.png"))

    print("=== 3. 看确认页上的按钮 ===")
    cam = [n for n in nodes() if n["pkg"].startswith("com.android.camera")]
    for n in cam[:14]:
        print("   %-22s @(%d,%d) %dx%d" % ((n["text"] or n["desc"])[:22],
                                          n["cx"], n["cy"], n["w"], n["h"]))

    print("=== 4. 点右下确认 ✓ (822,1755) ===")
    sh("input tap 822 1755")
    time.sleep(6)
    print("   截图:", shot("x3_confirm.png"))

    print("=== 5. 等 20 秒（相机可能是异步写盘）===")
    for i in range(4):
        time.sleep(5)
        if os.path.exists(TARGET):
            print("   ★ 第 %d 次检查：文件出现了！%d 字节" % (i + 1, os.path.getsize(TARGET)))
            break
        print("   第 %d 次检查：还没有" % (i + 1))

    print("=== 6. 最终结果 ===")
    if os.path.exists(TARGET) and os.path.getsize(TARGET) > 0:
        print("   ★★ 成功：相机认了 file:// 的 EXTRA_OUTPUT，%d 字节" % os.path.getsize(TARGET))
        print("   ==> 方案：App 改用 file:// 输出路径")
    else:
        print("   ✗ 失败：相机没有按 file:// 路径写")
        print("   ==> 方案：改成「正常打开相机拍照 + 事后搬文件」")

    print()
    print("=== 7. 相机保存路径日志 ===")
    lg = sh("logcat -d -v brief 2>/dev/null | grep -iE 'setShotSavePath|getThumbnailShotPath' | tail -4")
    print(lg.strip()[:700] or "   (无)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
