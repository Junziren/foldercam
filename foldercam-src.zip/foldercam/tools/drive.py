#!/usr/bin/env python3
"""FolderCam 端到端验收驱动。

关键教训：两次工具调用之间，宿主 App 会抢回前台，导致 `input tap` 打偏。
所以这里把「拉起 App -> 找元素 -> 点击 -> 校验」全部放进同一个进程里原子执行。

用法:
  python3 tools/drive.py newfolder <文件夹名>   # 建文件夹并进入拍摄页
  python3 tools/drive.py tap <文本>             # 点某个文本元素（限定在当前 App 内）
  python3 tools/drive.py dump                   # 打印当前界面的可点元素
  python3 tools/drive.py state                  # 打印当前前台 + 已建文件夹
"""
import os
import re
import subprocess
import sys
import time

PKG = "com.harness.foldercam"
UI_XML = "/data/local/tmp/foldercam-ui.xml"

NODE_RE = re.compile(r"<node\b([^>]*?)/?>", re.S)
ATTR_RE = re.compile(r'([\w:-]+)="([^"]*)"')


def sh(cmd, timeout=60):
    if isinstance(cmd, str):
        cmd = ["/system/bin/sh", "-c", cmd]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (p.stdout or "") + (p.stderr or "")
    except Exception as e:
        return "[sh error] %s" % e


def foreground():
    out = sh("dumpsys activity activities 2>/dev/null | grep -m1 ResumedActivity")
    m = re.search(r"u0 ([A-Za-z0-9_.]+)/", out)
    return m.group(1) if m else ""


def launch():
    """把 App 拉到前台并等到它真的在前台。"""
    sh("am start -n %s/.MainActivity" % PKG)
    for _ in range(20):
        time.sleep(0.4)
        if foreground() == PKG:
            time.sleep(0.8)   # 多等一会儿，让界面画完
            return True
    return False


def dump():
    try:
        if os.path.exists(UI_XML):
            os.remove(UI_XML)
    except OSError:
        pass
    sh('uiautomator dump "%s" >/dev/null 2>&1' % UI_XML, timeout=30)
    try:
        with open(UI_XML, encoding="utf-8", errors="ignore") as fh:
            xml = fh.read()
    except OSError:
        return []
    out = []
    for m in NODE_RE.finditer(xml):
        a = dict(ATTR_RE.findall(m.group(1)))
        bm = re.match(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", a.get("bounds", ""))
        if not bm:
            continue
        x1, y1, x2, y2 = (int(v) for v in bm.groups())
        out.append({
            "text": (a.get("text") or "").strip(),
            "desc": (a.get("content-desc") or "").strip(),
            "cls": a.get("class", ""),
            "pkg": a.get("package", ""),
            "clickable": a.get("clickable") == "true",
            "editable": a.get("class", "").endswith("EditText"),
            "cx": (x1 + x2) // 2,
            "cy": (y1 + y2) // 2,
        })
    return out


def label(n):
    return n["text"] or n["desc"]


def find(nodes, text, exact=False):
    for n in nodes:
        lab = label(n)
        if not lab:
            continue
        if (lab == text) if exact else (text in lab):
            return n
    return None


def tap_node(n):
    sh("input tap %d %d" % (n["cx"], n["cy"]))


def tap_text(text, exact=False, wait=1.2):
    """只在 App 处于前台时点，避免打到别的界面。"""
    if foreground() != PKG:
        sh("am start -n %s/.MainActivity" % PKG)
        time.sleep(1.5)
    nodes = dump()
    n = find(nodes, text, exact)
    if n is None:
        print("   !! 找不到元素: %r" % text)
        return False
    print("   [点击] %r @(%d,%d)" % (label(n), n["cx"], n["cy"]))
    tap_node(n)
    time.sleep(wait)
    return True


def cmd_newfolder(name):
    if not launch():
        print("!! App 没起来")
        return 1
    print("==> App 已在前台")

    if not tap_text("新建文件夹", wait=1.8):
        return 1

    # 输入框
    nodes = dump()
    edit = None
    for n in nodes:
        if n["editable"]:
            edit = n
            break
    if edit is None:
        print("!! 找不到输入框")
        return 1
    print("   [输入] %s" % name)
    tap_node(edit)
    time.sleep(0.4)
    # 先清空
    sh("input keyevent 123")
    for _ in range(30):
        sh("input keyevent 67")
    sh('input text "%s"' % name)
    time.sleep(0.8)

    if not tap_text("创建并开始拍", wait=2.5):
        return 1

    fg = foreground()
    print("==> 点击后前台: %s" % fg)
    return 0


def cmd_state():
    print("前台: %s" % foreground())
    print("已建文件夹:")
    for n in dump():
        if n["pkg"] == PKG and label(n):
            print("   %-24s clickable=%s" % (label(n)[:24], n["clickable"]))
    return 0


def cmd_dump():
    for n in dump():
        if n["pkg"] == PKG and label(n):
            print("   %-30s cls=%-28s clickable=%s @(%d,%d)"
                  % (label(n)[:30], n["cls"].split(".")[-1], n["clickable"], n["cx"], n["cy"]))
    return 0


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    cmd = sys.argv[1]
    if cmd == "newfolder":
        return cmd_newfolder(sys.argv[2] if len(sys.argv) > 2 else "testA")
    if cmd == "tap":
        return 0 if tap_text(sys.argv[2]) else 1
    if cmd == "state":
        return cmd_state()
    if cmd == "dump":
        return cmd_dump()
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main())
