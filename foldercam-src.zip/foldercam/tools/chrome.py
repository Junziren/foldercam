#!/usr/bin/env python3
"""用 ADB 输入注入操控 Chrome（跟驱动相机、点安装弹窗同一套办法）。

约束（踩过的坑）：
  * 宿主聊天 App 是悬浮窗，一直浮在最上层，会挡住页面中间区域，
    所以截图里的内容要挑没被挡的部分看，必要时滚动页面把目标挪出来。
  * 绝对不能杀 com.androidharness.app —— 那就是 harness 自己。
  * 两次工具调用之间前台会被抢走，所以一整套操作要在同一个进程里跑完。
"""
import os
import re
import subprocess
import sys
import time

CHROME = "com.android.chrome"
SHOTS = "build/chrome"


def sh(cmd, timeout=90):
    if isinstance(cmd, str):
        cmd = ["/system/bin/sh", "-c", cmd]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (p.stdout or "") + (p.stderr or "")
    except Exception as e:
        return "[sh error] %s" % e


def top():
    out = sh("dumpsys activity activities 2>/dev/null | grep -m1 ResumedActivity")
    m = re.search(r"u0 ([A-Za-z0-9_.]+)/([A-Za-z0-9_.$]+)", out)
    if not m:
        return "", ""
    pkg, act = m.group(1), m.group(2)
    return pkg, (pkg + act if act.startswith(".") else act)


def shot(name):
    os.makedirs(SHOTS, exist_ok=True)
    p = os.path.abspath(os.path.join(SHOTS, name))
    if os.path.exists(p):
        os.remove(p)
    sh('screencap -p "%s"' % p)
    return p if os.path.exists(p) else None


def open_url(url, wait=7):
    """用系统默认浏览器打开 URL。"""
    sh('am start -a android.intent.action.VIEW -d "%s"' % url)
    time.sleep(wait)


def tap(x, y, wait=1.5):
    sh("input tap %d %d" % (x, y))
    time.sleep(wait)


def text(s, wait=1.0):
    # input text 不支持空格，要用 %s；中文也传不进去，只能 ASCII
    esc = s.replace(" ", "%s")
    sh('input text "%s"' % esc)
    time.sleep(wait)


def scroll(direction="down", amount=600):
    # swipe 反向：要往下滚内容，手指从下往上滑
    if direction == "down":
        sh("input swipe 600 1800 600 %d 300" % (1800 - amount))
    else:
        sh("input swipe 600 %d 600 1800 300" % (1800 - amount))
    time.sleep(1.5)


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    cmd = sys.argv[1]

    if cmd == "open":
        url = sys.argv[2]
        open_url(url)
        print("前台:", top())
        print("截图:", shot("open.png"))

    elif cmd == "shot":
        print("前台:", top())
        print("截图:", shot(sys.argv[2] if len(sys.argv) > 2 else "now.png"))

    elif cmd == "top":
        print("前台:", top())

    else:
        print(__doc__)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
