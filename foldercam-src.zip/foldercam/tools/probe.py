#!/usr/bin/env python3
"""快速判断一个 APK 能不能被系统的 PackageManager 解析。

背景：本机 MIUI 把 `pm install` 堵死了，而且 MIUI 的安装器在解析失败时
只会写一行 "Failure to parse package archive" 到 logcat、然后在界面上
显示 "package info is null"。这里就抓这行日志来判断解析成功与否。

用法: python3 tools/probe.py <apk路径>
返回: 0 = 解析成功, 1 = 解析失败
"""
import os
import subprocess
import sys
import time

APK = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else None


def sh(cmd, timeout=60):
    if isinstance(cmd, str):
        cmd = ["/system/bin/sh", "-c", cmd]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (p.stdout or "") + (p.stderr or "")
    except Exception as e:
        return "[sh error] %s" % e


def main():
    if not APK or not os.path.isfile(APK):
        print("找不到 APK: %s" % APK)
        return 2

    sh("am force-stop com.miui.packageinstaller")
    sh("am force-stop com.miui.securitycenter")
    sh("logcat -c")
    time.sleep(0.5)

    sh('am start -a android.intent.action.VIEW -d "file://%s" '
       '-t application/vnd.android.package-archive' % APK)
    time.sleep(6)

    log = sh("logcat -d -v brief")
    lines = [l for l in log.splitlines()
             if any(k in l for k in ("Failure to parse", "RealScanner", "AndroidAppInfo",
                                     "MIUIPI_InstallStart", "PackageManager: Failure"))]
    for l in lines[:12]:
        print("   " + l.strip()[:190])

    failed = "Failure to parse" in log
    # MIUI 的 RealScanner 能吐出包信息，就说明系统解析成功了
    scanned = "Scan result" in log and "AndroidAppInfo" in log

    # 收尾：不管成败都把安装器收掉，免得残留窗口影响下一次
    sh("am force-stop com.miui.packageinstaller")
    sh("am force-stop com.miui.securitycenter")

    if failed and not scanned:
        print("==> 解析失败 (PackageManager 拒绝了这个 APK)")
        return 1
    if scanned:
        print("==> 解析成功 (MIUI 已经能读出包信息)")
        return 0
    print("==> 结果不明：既没看到失败也没看到扫描结果")
    return 3


if __name__ == "__main__":
    sys.exit(main())
