#!/usr/bin/env python3
"""判定实验：不传 EXTRA_OUTPUT 时，MIUI 相机能不能正常存照片。

已知：
  * 传 EXTRA_OUTPUT 时，MIUI 相机把它当耳旁风（savePath 硬编码 DCIM/Camera），
    而且 MediaStore 记录没建起来（update count 0），照片在内存里处理完就丢了。
  * 正常用相机 App 拍照是好的（DCIM/Camera 里一堆历史照片）。

所以这里测：完全不带 EXTRA_OUTPUT 拉相机，看照片会不会正常落到 DCIM/Camera。
  → 会落地：那就改用「让相机按自己习惯存，我们事后再把新照片搬进目标文件夹」
  → 不落地：那是 MIUI 对第三方调用相机的限制，得换完全不同的方案

流程全在一次进程内完成，因为跨工具调用时前台会被宿主 App 抢走。
"""
import os
import subprocess
import sys
import time

J = os.path.join
S = os.sep + J("storage", "emulated", "0")
CAMDIR = J(S, "DCIM", "Camera")
OUTDIR = "build/exp"
UI_XML = "/data/local/tmp/fc-exp.xml"


def sh(cmd, timeout=90):
    if isinstance(cmd, str):
        cmd = ["/system/bin/sh", "-c", cmd]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (p.stdout or "") + (p.stderr or "")
    except Exception as e:
        return "[sh error] %s" % e


def snapshot():
    if not os.path.isdir(CAMDIR):
        return {}
    out = {}
    for f in os.listdir(CAMDIR):
        fp = J(CAMDIR, f)
        if os.path.isfile(fp):
            try:
                out[f] = (os.path.getsize(fp), os.path.getmtime(fp))
            except OSError:
                pass
    return out


def shot(name):
    os.makedirs(OUTDIR, exist_ok=True)
    p = os.path.abspath(J(OUTDIR, name))
    sh('screencap -p "%s"' % p)
    return p


def dump():
    try:
        if os.path.exists(UI_XML):
            os.remove(UI_XML)
    except OSError:
        pass
    sh('uiautomator dump "%s" >/dev/null 2>&1' % UI_XML, timeout=30)
    try:
        xml = open(UI_XML, encoding="utf-8", errors="ignore").read()
    except OSError:
        return []
    import re
    out = []
    for m in re.finditer(r"<node\b([^>]*?)/?>", xml, re.S):
        a = dict(re.findall(r'([\w:-]+)="([^"]*)"', m.group(1)))
        b = re.match(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", a.get("bounds", ""))
        if not b:
            continue
        x1, y1, x2, y2 = (int(v) for v in b.groups())
        out.append({"text": (a.get("text") or "").strip(),
                    "desc": (a.get("content-desc") or "").strip(),
                    "pkg": a.get("package", ""),
                    "cx": (x1 + x2) // 2, "cy": (y1 + y2) // 2})
    return out


def main():
    before = snapshot()
    print("实验前 DCIM/Camera 文件数: %d" % len(before))

    print("=== 拉起相机（不带 EXTRA_OUTPUT）===")
    sh("am force-stop com.android.camera")
    time.sleep(1)
    r = sh("am start -W -a android.media.action.IMAGE_CAPTURE")
    print("   " + r.strip().splitlines()[-1][:120] if r.strip() else "   (无输出)")
    time.sleep(6)
    print("   截图:", shot("e1_launch.png"))

    print("=== 点快门 (600,1755) ===")
    sh("input tap 600 1755")
    time.sleep(4)
    p = shot("e2_after_shutter.png")
    print("   截图:", p)

    print("=== 看看有没有确认页 ===")
    nodes = [n for n in dump() if n["pkg"].startswith("com.android.camera")]
    for n in nodes[:12]:
        print("   %-24s @(%d,%d)" % ((n["text"] or n["desc"])[:24], n["cx"], n["cy"]))

    print("=== 如果底部右侧有确认按钮，点它 ===")
    # 确认页一般是 左下×  右下✓
    sh("input tap 822 1755")
    time.sleep(5)
    print("   截图:", shot("e3_after_confirm.png"))

    print("=== 检查 DCIM/Camera 有没有新文件 ===")
    after = snapshot()
    new = [f for f in after if f not in before]
    if new:
        for f in new:
            print("   ★ 新文件: %-42s %10d 字节" % (f, after[f][0]))
        print("==> 结论：不带 EXTRA_OUTPUT 时相机能正常存盘")
    else:
        print("   (没有新文件)")
        changed = [f for f in after if f in before and after[f][1] != before[f][1]]
        for f in changed:
            print("   ~ 有变化: %s" % f)
        print("==> 结论：相机没有存盘")

    print()
    print("=== 相机这次的 savePath 日志 ===")
    lg = sh("logcat -d -v brief 2>/dev/null | grep -iE 'setShotSavePath|getThumbnailShotPath' | tail -6")
    print(lg.strip()[:900] or "   (无)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
