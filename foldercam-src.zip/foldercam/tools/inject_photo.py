#!/usr/bin/env python3
"""分开验证「读」和「写」两条路径。

用户反馈「拍完照照片不能在 App 里访问」，这可能是两种完全不同的毛病：
  A) 读路径坏了：照片在文件夹里，但 App 列表里不显示
  B) 写路径坏了：相机压根没把照片写进文件夹
本脚本把一张真实照片直接放进目标文件夹（绕过相机），专门验证 A。

用法: python3 tools/inject_photo.py
"""
import os
import re
import shutil
import subprocess
import sys
import time

PKG = "com.harness.foldercam"
FOLDER = "workA"
J = os.path.join
S = os.sep + J("storage", "emulated", "0")
DIR = J(S, "Pictures", "FolderCam", FOLDER)
SRC = J(S, "DCIM", "Camera", "IMG_20220911_210205.jpg")
NAME = "IMG_TEST_0001.jpg"


def sh(cmd, timeout=90):
    if isinstance(cmd, str):
        cmd = ["/system/bin/sh", "-c", cmd]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (p.stdout or "") + (p.stderr or "")
    except Exception as e:
        return "[sh error] %s" % e


def query():
    out = sh("content query --uri content://media/external/images/media "
             "--projection _id:_display_name:relative_path:_size "
             "--where \"relative_path='Pictures/FolderCam/%s/'\"" % FOLDER)
    return [l.strip() for l in out.splitlines() if l.startswith("Row:")]


def main():
    if not os.path.isfile(SRC):
        print("源文件不存在:", SRC)
        return 1
    os.makedirs(DIR, exist_ok=True)
    dst = J(DIR, NAME)
    shutil.copy2(SRC, dst)
    print("==> 已放入: %s (%d 字节)" % (dst, os.path.getsize(dst)))

    print("==> 触发媒体扫描")
    sh('am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE '
       '-d "file://%s"' % dst)
    # 兼容新版本：直接让 MediaProvider 扫
    sh('cmd media_provider scan "%s" 2>/dev/null' % dst)
    time.sleep(2)

    rows = query()
    print("==> MediaStore 里的记录 (%d 条):" % len(rows))
    for r in rows:
        print("   " + r[:150])
    if not rows:
        print("   !! MediaStore 没收录 —— App 查不到就是这个原因（读路径依赖 MediaStore）")

    print("==> 启动 App 看它列不列得出来")
    sh("am force-stop %s" % PKG)
    time.sleep(1.5)
    sh("am start -n %s/.MainActivity" % PKG)
    time.sleep(4)
    out = sh("dumpsys activity activities 2>/dev/null | grep -m1 ResumedActivity")
    print("   前台:", out.strip()[:110])

    os.makedirs("build", exist_ok=True)
    sh('screencap -p "%s"' % os.path.abspath("build/listed.png"))
    print("   截图: build/listed.png")
    return 0


if __name__ == "__main__":
    sys.exit(main())
