#!/usr/bin/env python3
"""测量 MIUI 相机快门在屏幕上的真实坐标（纯 python 解 PNG，不依赖 PIL）。

背景：我之前凭截图目测把相机快门坐标当成 (600,1898)，结果点了半天没反应。
这里直接扫描截图像素，用「白色圆环」定位快门的真实位置。
"""
import struct
import zlib
import sys


def load_png(path):
    d = open(path, "rb").read()
    if d[:8] != b"\x89PNG\r\n\x1a\n":
        raise SystemExit("不是 PNG")
    pos, w, h, ct = 8, 0, 0, 0
    idat = b""
    while pos < len(d):
        ln = struct.unpack(">I", d[pos:pos + 4])[0]
        tag = d[pos + 4:pos + 8]
        body = d[pos + 8:pos + 8 + ln]
        if tag == b"IHDR":
            w, h = struct.unpack(">II", body[:8])
            ct = body[9]
        elif tag == b"IDAT":
            idat += body
        pos += 12 + ln
    raw = zlib.decompress(idat)
    ch = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}[ct]
    stride = w * ch
    rows = []
    prev = bytearray(stride)
    p = 0
    for _ in range(h):
        f = raw[p]
        p += 1
        line = bytearray(raw[p:p + stride])
        p += stride
        if f == 1:
            for i in range(ch, stride):
                line[i] = (line[i] + line[i - ch]) & 255
        elif f == 2:
            for i in range(stride):
                line[i] = (line[i] + prev[i]) & 255
        elif f == 3:
            for i in range(stride):
                a = line[i - ch] if i >= ch else 0
                line[i] = (line[i] + ((a + prev[i]) >> 1)) & 255
        elif f == 4:
            for i in range(stride):
                a = line[i - ch] if i >= ch else 0
                b = prev[i]
                c = prev[i - ch] if i >= ch else 0
                pa, pb, pc = abs(b - c), abs(a - c), abs(a + b - 2 * c)
                pr = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
                line[i] = (line[i] + pr) & 255
        rows.append(bytes(line))
        prev = line
    return w, h, ch, rows


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "build/cam2.png"
    w, h, ch, rows = load_png(path)
    print("截图: %s  尺寸 %dx%d  通道 %d" % (path, w, h, ch))
    print("(屏幕实际: 1200x2608)")

    # 只扫下方 45%，快门是很亮的白色圆环
    y0 = int(h * 0.55)
    counts = []
    for y in range(y0, h):
        line = rows[y]
        n = 0
        for x in range(0, w, 2):
            i = x * ch
            if line[i] > 225 and line[i + 1] > 225 and line[i + 2] > 225:
                n += 1
        counts.append((n, y))
    counts.sort(reverse=True)

    print()
    print("最亮的 8 行（白像素数, y）:")
    for n, y in counts[:8]:
        print("   %5d @ y=%d" % (n, y))

    top_y = counts[0][1]
    band = sorted(y for n, y in counts if abs(y - top_y) < 130)
    ymid = int((band[0] + band[-1]) / 2)
    line = rows[ymid]
    xs = [x for x in range(w)
          if line[x * ch] > 225 and line[x * ch + 1] > 225 and line[x * ch + 2] > 225]
    if not xs:
        print("该行没找到白像素")
        return 1
    cx = int((min(xs) + max(xs)) / 2)
    print()
    print("=== 快门真实位置 ===")
    print("   y 区间: %d .. %d   -> 中心 y = %d" % (band[0], band[-1], ymid))
    print("   x 区间: %d .. %d   -> 中心 x = %d" % (min(xs), max(xs), cx))
    print()
    print("   我之前点的: (600, 1898)")
    print("   实际应该在: (%d, %d)" % (cx, ymid))
    return 0


if __name__ == "__main__":
    sys.exit(main())
