#!/usr/bin/env python3
"""把 classes.dex 打进 aapt2 产出的 base.apk，并保证 4 字节对齐。

Android 上本机没有 zip / zipalign，所以自己实现一个最小对齐打包器：
  * 以 aapt2 link 的产物为底（里面的 resources.arsc 已由 aapt2 对齐，原样保留）
  * 追加 classes.dex（STORED 不压缩）
  * 对需要对齐的条目补一个 ZIP extra field，使数据段落在 4 字节边界上

用法: pack.py <base.apk> <out.apk> <dex...>
"""
import os
import shutil
import struct
import sys
import zipfile

# 需要 4 字节对齐的条目（resources.arsc 必须不压缩且对齐；dex 对齐是 DEX 加载的要求）
ALIGN_ENTRIES = {"resources.arsc"}
ALIGN_SUFFIXES = (".dex",)
ALIGN_EXTRA_ID = 0xD935  # zipalign 用的 Android alignment extra field id


def needs_align(name: str) -> bool:
    return name in ALIGN_ENTRIES or name.endswith(ALIGN_SUFFIXES)


def align_extra(data_offset: int) -> bytes:
    """返回若干字节的 extra field，使数据段起点 4 字节对齐。"""
    pad = (-data_offset) % 4
    if pad == 0:
        return b""
    # ZIP extra field 是 TLV 结构，至少占 4 字节，所以凑成 pad+4（模 4 等价）
    payload = pad
    return struct.pack("<HH", ALIGN_EXTRA_ID, payload) + b"\x00" * payload


def main() -> int:
    if len(sys.argv) < 4:
        print(__doc__)
        return 2
    base, out = sys.argv[1], sys.argv[2]
    dexes = sys.argv[3:]

    for path in dexes:
        if not os.path.isfile(path):
            print("缺少 dex 文件: %s" % path)
            return 1

    with zipfile.ZipFile(base) as src:
        entries = [(i, src.read(i.filename)) for i in src.infolist()]

    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, allowZip64=True) as dst:
        for info, blob in entries:
            # 只改压缩方式相关的字段，其余（时间戳/权限位）保留
            info.extra = b""
            info.flag_bits &= ~0x08  # 数据描述符：重写时不需要
            if info.compress_type == zipfile.ZIP_DEFLATED and info.filename == "resources.arsc":
                info.compress_type = zipfile.ZIP_STORED
            if info.compress_type == zipfile.ZIP_STORED:
                header = 30 + len(info.filename.encode("utf-8")) + len(info.extra)
                info.extra += align_extra(dst.fp.tell() + header)
            dst.writestr(info, blob)

        for dex in dexes:
            with open(dex, "rb") as fh:
                blob = fh.read()
            info = zipfile.ZipInfo("classes.dex" if dexes.index(dex) == 0
                                   else "classes%d.dex" % (dexes.index(dex) + 1))
            info.compress_type = zipfile.ZIP_STORED
            info.create_system = 0
            info.external_attr = 0o644 << 16
            info.extra = align_extra(dst.fp.tell() + 30 + len(info.filename))
            dst.writestr(info, blob)

    size = os.path.getsize(out)
    print("打包完成: %s (%.2f MB)" % (out, size / 1048576.0))
    return 0


if __name__ == "__main__":
    sys.exit(main())
