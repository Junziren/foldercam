#!/usr/bin/env python3
"""定位 MIUI 相机「确认界面」上的 × 和 ✓ 两个圆按钮。

背景（血泪教训）：
  ACTION_IMAGE_CAPTURE 在 MIUI 上会走 OneShotImageCapture，拍完不是直接返回，
  而是先弹一个确认页（应用仅可获取本次拍摄完成的照片…），
  左下 × = 取消（照片丢弃，调用方收到 RESULT_CANCELED=0）
  右下 ✓ = 确认（照片写入 EXTRA_OUTPUT，调用方收到 RESULT_OK=-1）
  我之前瞎点，正好点中 ×，所以日志里一直是 result=0、
  「相机会话没有产生数据」，看起来就像「照片没进 App」。

这两个圆是深灰底 + 白字，在深色背景上，用「中心对称的白字 + 周围一圈较亮」
不好自动识别，所以这里用固定的相对坐标（按 1200x2608 屏推算），
再用截图人工复核一次即可。
"""
import os
import struct
import sys
import zlib

SHOT = "build/steps/s2_camera.png"


def load_png(path):
    d = open(path, "rb").read()
    pos, w, h, ct = 8, 0, 0, 0
    idat = b""
    while pos < len(d):
        ln = struct.unpack(">I", d[pos:pos + 4])[0]
        tag = d[pos + 4:pos + 8]
        body = d[pos + 8:pos + 8 + ln]
        if tag == b"IHDR":
            w, h = struct.unpack(">II", body[:8])
            ct = body[9]
        elif tag == b"IDAT":
            idat += body
        pos += 12 + ln
    raw = zlib.decompress(idat)
    ch = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}[ct]
    stride = w * ch
    rows, prev, p = [], bytearray(stride), 0
    for _ in range(h):
        f = raw[p]
        p += 1
        line = bytearray(raw[p:p + stride])
        p += stride
        if f == 1:
            for i in range(ch, stride):
                line[i] = (line[i] + line[i - ch]) & 255
        elif f == 2:
            for i in range(stride):
                line[i] = (line[i] + prev[i]) & 255
        elif f == 3:
            for i in range(stride):
                a = line[i - ch] if i >= ch else 0
                line[i] = (line[i] + ((a + prev[i]) >> 1)) & 255
        elif f == 4:
            for i in range(stride):
                a = line[i - ch] if i >= ch else 0
                b = prev[i]
                c = prev[i - ch] if i >= ch else 0
                pa, pb, pc = abs(b - c), abs(a - c), abs(a + b - 2 * c)
                pr = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
                line[i] = (line[i] + pr) & 255
        rows.append(bytes(line))
        prev = line
    return w, h, ch, rows


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else SHOT
    if not os.path.exists(path):
        print("没有截图:", path)
        return 1
    w, h, ch, rows = load_png(path)
    print("截图 %dx%d" % (w, h))

    # 在下方 60%~80% 区域找「深灰圆按钮」：像素接近 (58,58,58) 左右
    y0, y1 = int(h * 0.62), int(h * 0.78)
    cols = {}
    for y in range(y0, y1, 2):
        line = rows[y]
        for x in range(0, w, 2):
            i = x * ch
            r, g, b = line[i], line[i + 1], line[i + 2]
            if 45 <= r <= 80 and abs(r - g) < 8 and abs(g - b) < 8:
                cols[x] = cols.get(x, 0) + 1

    if not cols:
        print("没找到深灰圆按钮，请人工看截图确认坐标")
        return 1

    xs = sorted(cols)
    # 把相邻的 x 聚成簇
    clusters, cur = [], [xs[0]]
    for x in xs[1:]:
        if x - cur[-1] <= 30:
            cur.append(x)
        else:
            clusters.append(cur)
            cur = [x]
    clusters.append(cur)

    print("找到 %d 个候选簇:" % len(clusters))
    best = []
    for c in clusters:
        total = sum(cols[x] for x in c)
        if total < 20:
            continue
        cx = (c[0] + c[-1]) // 2
        # 找该簇的 y 范围
        ys = [y for y in range(y0, y1, 2)
              for x in range(max(0, cx - 40), min(w, cx + 40), 2)
              if (lambda i: 45 <= rows[y][i] <= 80)(x * ch)]
        cy = (min(ys) + max(ys)) // 2 if ys else 0
        best.append((cx, cy, total))
        print("   x=%4d y=%4d 覆盖=%d" % (cx, cy, total))

    if len(best) >= 2:
        best.sort()
        left, right = best[0], best[-1]
        print()
        print("=== 推定 ===")
        print("   × 取消 : (%d, %d)" % (left[0], left[1]))
        print("   ✓ 确认 : (%d, %d)" % (right[0], right[1]))
        print()
        print("   >>> 要返回照片给 App，必须点右边的 ✓: (%d, %d)" % (right[0], right[1]))
        with open("build/confirm_buttons.txt", "w") as fh:
            fh.write("%d %d\n" % (right[0], right[1]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
