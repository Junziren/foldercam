#!/usr/bin/env python3
"""从截图里找 GitHub 的按钮（浅灰描边 + 白底 + 深色文字），给出精确坐标。

为什么要这么做：宿主悬浮窗让 uiautomator 读不到 Chrome 的节点，
只能靠像素。GitHub 默认按钮的边框色约 #d0d7de，在纯白背景上很好认。

用法: python3 tools/find_button.py build/chrome/xxx.png [搜索起始y]
"""
import struct
import sys
import zlib

BORDER = (0xD0, 0xD7, 0xDE)
TOL = 26


def load_png(path):
    d = open(path, "rb").read()
    pos, w, h, ct = 8, 0, 0, 0
    idat = b""
    while pos < len(d):
        ln = struct.unpack(">I", d[pos:pos + 4])[0]
        tag = d[pos + 4:pos + 8]
        body = d[pos + 8:pos + 8 + ln]
        if tag == b"IHDR":
            w, h = struct.unpack(">II", body[:8])
            ct = body[9]
        elif tag == b"IDAT":
            idat += body
        pos += 12 + ln
    raw = zlib.decompress(idat)
    ch = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}[ct]
    stride = w * ch
    rows, prev, p = [], bytearray(stride), 0
    for _ in range(h):
        f = raw[p]
        p += 1
        line = bytearray(raw[p:p + stride])
        p += stride
        if f == 1:
            for i in range(ch, stride):
                line[i] = (line[i] + line[i - ch]) & 255
        elif f == 2:
            for i in range(stride):
                line[i] = (line[i] + prev[i]) & 255
        elif f == 3:
            for i in range(stride):
                a = line[i - ch] if i >= ch else 0
                line[i] = (line[i] + ((a + prev[i]) >> 1)) & 255
        elif f == 4:
            for i in range(stride):
                a = line[i - ch] if i >= ch else 0
                b = prev[i]
                c = prev[i - ch] if i >= ch else 0
                pa, pb, pc = abs(b - c), abs(a - c), abs(a + b - 2 * c)
                pr = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
                line[i] = (line[i] + pr) & 255
        rows.append(bytes(line))
        prev = line
    return w, h, ch, rows


def is_border(px):
    return all(abs(px[i] - BORDER[i]) <= TOL for i in range(3))


def main():
    path = sys.argv[1]
    y_from = int(sys.argv[2]) if len(sys.argv) > 2 else 0
    w, h, ch, rows = load_png(path)
    print("图 %dx%d，从 y=%d 往下找" % (w, h, y_from))

    # 找「一条连续的水平浅灰线」——按钮的上/下边框就是这样
    cands = []
    for y in range(y_from, h - 2):
        line = rows[y]
        run = 0
        start = 0
        for x in range(0, w):
            i = x * ch
            if is_border((line[i], line[i + 1], line[i + 2])):
                if run == 0:
                    start = x
                run += 1
            else:
                if run > 150:          # 按钮宽度足够长
                    cands.append((y, start, start + run - 1, run))
                run = 0
        if run > 150:
            cands.append((y, start, w - 1, run))

    if not cands:
        print("没找到按钮边框（换个起始 y 或调容差）")
        return 1

    # 把成对的上下边框合成一个按钮
    print("找到 %d 条候选横线，前 12 条：" % len(cands))
    for y, x1, x2, ln in cands[:12]:
        print("   y=%-5d x=%d..%d  宽=%d  中心x=%d" % (y, x1, x2, ln, (x1 + x2) // 2))

    # 假设第一条是最靠上的按钮的上边框，找它下面最近的另一条 → 下边框
    y1, x1a, x2a, _ = cands[0]
    y2 = None
    for y, x1, x2, ln in cands[1:]:
        if y - y1 > 40:
            y2 = y
            break
    if y2 is None:
        print("只看到一条边，可能是别的元素；直接把中心按 60 高估算")
        cy = y1 + 30
    else:
        cy = (y1 + y2) // 2
    cx = (x1a + x2a) // 2
    print()
    print("==> 建议点击 (cx=%d, cy=%d)" % (cx, cy))
    return 0


if __name__ == "__main__":
    sys.exit(main())
