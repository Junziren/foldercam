#!/system/bin/sh
# 通过 Shizuku(adb shell 权限) 安装并启动 FolderCam，无需手点系统安装界面。
set -e

FC_ROOT=$(cd "$(dirname "$0")/.." && pwd)
APK="$FC_ROOT/out/FolderCam.apk"
PKG=com.harness.foldercam

[ -f "$APK" ] || { echo "错误: 找不到 $APK，先跑 tools/build.sh" >&2; exit 1; }

echo "==> 安装 $APK"
pm install -r -t "$APK"
# pm install 的输出形如 "Success"；如果不是，下面会打印出来

echo "==> 启动主界面"
am start -n "$PKG/.MainActivity" >/dev/null
echo "已启动 $PKG/.MainActivity"
