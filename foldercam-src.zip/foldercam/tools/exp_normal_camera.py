#!/usr/bin/env python3
"""决定性测试：从桌面正常打开相机 App 拍照，能不能存盘？

对比三条路径：
  A) 我们的 App 调 ACTION_IMAGE_CAPTURE + EXTRA_OUTPUT  -> 照片消失（已知）
  B) shell 调 ACTION_IMAGE_CAPTURE（无 EXTRA_OUTPUT）    -> 照片消失（已知）
  C) 正常从桌面打开相机 App 拍照                          -> ？

如果 C 也失败，说明相机本身存盘坏了（跟第三方调用无关）。
如果 C 成功，说明问题出在「被第三方调起」这条路径上。
"""
import os
import re
import subprocess
import sys
import time

J = os.path.join
S = os.sep + J("storage", "emulated", "0")
CAMDIR = J(S, "DCIM", "Camera")
OUTDIR = "build/exp2"


def sh(cmd, timeout=90):
    if isinstance(cmd, str):
        cmd = ["/system/bin/sh", "-c", cmd]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (p.stdout or "") + (p.stderr or "")
    except Exception as e:
        return "[sh error] %s" % e


def snap():
    if not os.path.isdir(CAMDIR):
        return {}
    out = {}
    for f in os.listdir(CAMDIR):
        fp = J(CAMDIR, f)
        if os.path.isfile(fp):
            try:
                out[f] = os.path.getsize(fp)
            except OSError:
                pass
    return out


def shot(name):
    os.makedirs(OUTDIR, exist_ok=True)
    p = os.path.abspath(J(OUTDIR, name))
    sh('screencap -p "%s"' % p)
    return p


def main():
    print("=== 相机主 Activity ===")
    r = sh("cmd package resolve-activity --brief com.android.camera")
    print("   " + r.strip()[:120])

    before = snap()
    print("=== 实验前 DCIM/Camera 文件数: %d ===" % len(before))

    print("=== A. 从桌面正常打开相机 ===")
    sh("am force-stop com.android.camera")
    time.sleep(1)
    r = sh("am start -W -a android.intent.action.MAIN "
           "-c android.intent.category.LAUNCHER com.android.camera")
    print("   " + (r.strip().splitlines() or [""])[-1][:120])
    time.sleep(6)
    print("   截图:", shot("c1_open.png"))

    print("=== B. 找快门位置（截图上的人工确认点）===")
    # 主相机的快门在底部居中，通常在 y≈2400
    for y in (2400, 2455, 2350):
        pass

    print("=== C. 点快门（主相机用底部居中）===")
    # 先试探性点两处，然后截图看有没有拍
    print("   点 (600,2400)")
    sh("input tap 600 2400")
    time.sleep(6)
    print("   截图:", shot("c2_shot1.png"))

    after = snap()
    new = [f for f in after if f not in before]
    if not new:
        print("=== 没拍到，试第二个位置 (600,2455) ===")
        sh("input tap 600 2455")
        time.sleep(6)
        print("   截图:", shot("c3_shot2.png"))
        after = snap()
        new = [f for f in after if f not in before]

    print("=== D. 结果 ===")
    if new:
        for f in new:
            print("   ★ 新文件: %-44s %10d 字节" % (f, after[f]))
        print("==> 结论：正常打开相机拍照【可以】存盘")
    else:
        print("   (DCIM/Camera 没有新文件)")
        print("==> 结论：正常打开相机也存不了 —— 相机本身这次没拍成功，")
        print("         或者快门坐标不对（看截图确认）")

    print()
    print("=== E. 相机这次的 savePath ===")
    lg = sh("logcat -d -v brief 2>/dev/null | grep -iE 'setShotSavePath' | tail -4")
    print(lg.strip()[:600] or "   (无)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
