#!/usr/bin/env python3
"""完整拍摄流程（含 MIUI 确认页）。

真实流程（终于搞清楚了）：
  1. 点 App 快门 -> 拉起 com.android.camera/.OneShotImageCapture
  2. 点相机快门 (600,2451) -> 拍照
  3. 【关键】MIUI 弹出确认页：
        左下 × = 取消 -> 照片丢弃，App 收到 RESULT_CANCELED(0)
        右下 ✓ = 确认 -> 照片写入 EXTRA_OUTPUT，App 收到 RESULT_OK(-1)
     之前一直点错（点到 × 那一带），所以日志永远说「相机会话没有产生数据」。
  4. 点 ✓ -> 相机返回 App -> 照片落进 Pictures/FolderCam/<文件夹>/
"""
import os
import subprocess
import sys
import time

PKG = "com.harness.foldercam"
REL = "Pictures/FolderCam/workA/"
OUTDIR = "build/steps"

APP_SHUTTER = (600, 2455)
# 【重要】OneShotImageCapture 的取景界面布局（实测，1200x2608）：
#     × 取消 (182,1755)    ○ 快门 (600,1755)    ⟳ 翻转 (1018,1755)
# 之前一直用 (600,2451) 是错的 —— 低了 700 像素，点在空白区，
# 所以相机从来没真正拍过照。
CAM_SHUTTER = (600, 1755)
# 拍完后 MIUI 的确认页： × 取消 (357,1755)   ✓ 确认 (822,1755)
CONFIRM_OK = (822, 1755)
# CONFIRM_CANCEL = (357, 1755)  # 千万别点这个，点了照片就丢


def sh(cmd, timeout=90):
    if isinstance(cmd, str):
        cmd = ["/system/bin/sh", "-c", cmd]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (p.stdout or "") + (p.stderr or "")
    except Exception as e:
        return "[sh error] %s" % e


def shot(name):
    os.makedirs(OUTDIR, exist_ok=True)
    p = os.path.abspath(os.path.join(OUTDIR, name))
    sh('screencap -p "%s"' % p)
    return p


def tap(pt, wait=1.0, label=""):
    print("   点击 %s (%d,%d)" % (label or "", pt[0], pt[1]))
    sh("input tap %d %d" % pt)
    time.sleep(wait)


def photos():
    out = sh("content query --uri content://media/external/images/media "
             "--projection _id:_display_name:relative_path:is_pending:_size "
             "--where \"relative_path='%s'\"" % REL)
    return [l.strip() for l in out.splitlines() if l.startswith("Row:")]


def main():
    print("=== 0. 干净启动 App ===")
    sh("am force-stop %s" % PKG)
    time.sleep(1.5)
    sh("logcat -c")
    sh("am start -n %s/.MainActivity" % PKG)
    time.sleep(5)
    print("   截图:", shot("f1_app.png"))

    print("=== 1. 点 App 快门 ===")
    tap(APP_SHUTTER, wait=6, label="App快门")
    print("   截图:", shot("f2_camera.png"))

    print("=== 2. 点相机快门 ===")
    tap(CAM_SHUTTER, wait=5, label="相机快门")
    p = shot("f3_confirm.png")
    print("   截图:", p, "(应看到确认页 × / ✓)")

    print("=== 3. 点 ✓ 确认 ===")
    tap(CONFIRM_OK, wait=6, label="确认✓")
    print("   截图:", shot("f4_back.png"))

    print("=== 4. 目标文件夹 ===")
    rows = photos()
    for r in rows[-5:]:
        print("   " + r[:150])
    if not rows:
        print("   (空)")

    print("=== 5. App 决策日志 ===")
    for line in sh("logcat -d -v brief -s FolderCam").strip().splitlines()[-10:]:
        print("   " + line.strip()[:170])
    return 0 if rows else 1


if __name__ == "__main__":
    sys.exit(main())
