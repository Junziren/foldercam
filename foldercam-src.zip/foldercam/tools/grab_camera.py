#!/usr/bin/env python3
"""原子操作：进入 ShootActivity -> 点我们App的快门 -> 等到系统相机 -> 截图。

必须一次进程内做完：跨工具调用的话宿主 App 会抢前台，相机随时被切走。
"""
import os
import re
import subprocess
import sys
import time

PKG = "com.harness.foldercam"
CAM = "com.android.camera"
FOLDER = "workA"
UI_XML = "/data/local/tmp/fc-grab.xml"
OUT = "build/cam_now.png"


def sh(cmd, timeout=90):
    if isinstance(cmd, str):
        cmd = ["/system/bin/sh", "-c", cmd]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (p.stdout or "") + (p.stderr or "")
    except Exception as e:
        return "[sh error] %s" % e


def top():
    out = sh("dumpsys activity activities 2>/dev/null | grep -m1 ResumedActivity")
    m = re.search(r"u0 ([A-Za-z0-9_.]+)/([A-Za-z0-9_.$]+)", out)
    if not m:
        return "", ""
    pkg, act = m.group(1), m.group(2)
    return pkg, (pkg + act if act.startswith(".") else act)


def wait_for(pred, seconds, label):
    end = time.time() + seconds
    while time.time() < end:
        if pred(*top()):
            return True
        time.sleep(0.4)
    print("   !! 等待超时: %s (当前 %s/%s)" % (label, *top()))
    return False


def dump():
    try:
        if os.path.exists(UI_XML):
            os.remove(UI_XML)
    except OSError:
        pass
    sh('uiautomator dump "%s" >/dev/null 2>&1' % UI_XML, timeout=30)
    try:
        xml = open(UI_XML, encoding="utf-8", errors="ignore").read()
    except OSError:
        return []
    out = []
    for m in re.finditer(r"<node\b([^>]*?)/?>", xml, re.S):
        a = dict(re.findall(r'([\w:-]+)="([^"]*)"', m.group(1)))
        b = re.match(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", a.get("bounds", ""))
        if not b:
            continue
        x1, y1, x2, y2 = (int(v) for v in b.groups())
        out.append({"text": (a.get("text") or "").strip(),
                    "pkg": a.get("package", ""),
                    "cx": (x1 + x2) // 2, "cy": (y1 + y2) // 2})
    return out


def main():
    print("=== 进入 ShootActivity ===")
    for attempt in range(1, 4):
        sh("am force-stop %s" % PKG)
        time.sleep(1.5)
        sh("am start -n %s/.MainActivity" % PKG)
        if wait_for(lambda p, a: a.endswith("ShootActivity"), 8, "ShootActivity"):
            break
        for n in dump():
            if n["pkg"] == PKG and FOLDER in n["text"]:
                sh("input tap %d %d" % (n["cx"], n["cy"]))
                time.sleep(2.5)
                break
        if wait_for(lambda p, a: a.endswith("ShootActivity"), 6, "ShootActivity"):
            break
    else:
        return 1
    print("   ", top()[1])

    print("=== 点 App 快门 (600,2455) ===")
    sh("input tap 600 2455")
    if not wait_for(lambda p, a: p.startswith(CAM), 15, "系统相机"):
        return 1
    print("   相机就绪:", top()[1])

    # 等相机界面画完
    time.sleep(3.0)
    os.makedirs("build", exist_ok=True)
    sh('screencap -p "%s"' % os.path.abspath(OUT))
    print("   已截图:", OUT, os.path.exists(OUT))
    return 0


if __name__ == "__main__":
    sys.exit(main())
