#!/usr/bin/env python3
"""取证：照片到底是「相机没写」还是「我们自己的清理逻辑删掉了」。

重点怀疑：
  CameraLauncher.onActivityResult 里做 size 校验，如果读到 0 就
  contentResolver.delete(uri) —— 这会连磁盘上的照片一起删掉！
  如果 MediaStore 的 _size 有延迟 / getStatSize 返回 0，
  就会出现「相机明明拍了，照片却消失」。
"""
import os
import re
import subprocess

J = os.path.join
S = os.sep + J("storage", "emulated", "0")


def sh(cmd, timeout=120):
    if isinstance(cmd, str):
        cmd = ["/system/bin/sh", "-c", cmd]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (p.stdout or "") + (p.stderr or "")
    except Exception as e:
        return "[sh error] %s" % e


def main():
    print("=== A. 我们 App 自己的全部日志（FolderCam tag）===")
    lg = sh("logcat -d -v time -s FolderCam")
    lines = [l for l in lg.splitlines() if l.strip()]
    if lines:
        for l in lines[-25:]:
            print("   " + l.strip()[:190])
    else:
        print("   (logcat 缓冲里已经没有了)")

    print()
    print("=== B. 所有已授予的 URI 权限（看相机有没有拿到我们的授权）===")
    d = sh("dumpsys activity uri-permissions 2>/dev/null | head -60")
    print(d.strip()[:2000] or "   (读不到)")

    print()
    print("=== C. UriGrants 相关的完整异常 ===")
    lg2 = sh("logcat -d -v time 2>/dev/null | grep -B6 'checkUriPermission' | tail -40")
    print(lg2.strip()[:2200] or "   (无)")

    print()
    print("=== D. 相机进程对 MediaProvider / 我们 App 的访问痕迹 ===")
    lg3 = sh("logcat -d -v time 2>/dev/null | grep -iE "
             "'folder[cC]am|external_primary|MediaProvider' "
             "| grep -viE 'Agent Use|harness' | tail -25")
    print(lg3.strip()[:2000] or "   (无)")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
