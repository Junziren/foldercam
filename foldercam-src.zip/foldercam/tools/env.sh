#!/system/bin/sh
# FolderCam 构建环境探测：定位工具链、JDK、android.jar、r8/d8。
# 由 build.sh / install.sh 以 `. tools/env.sh` 方式加载。
# 注意：Android 上没有 /bin/bash，本文件只能被 POSIX sh / 工具链 bash source。

FC_ROOT=$(cd "$(dirname "$0")/.." && pwd)

# --- 工具链 prefix（aapt2 所在目录的上一级）---
AAPT2_BIN=$(command -v aapt2 2>/dev/null)
if [ -z "$AAPT2_BIN" ]; then
  echo "错误: PATH 里没有 aapt2。请先 pkg_install aapt2。" >&2
  return 1 2>/dev/null || exit 1
fi
PREFIX=$(cd "$(dirname "$AAPT2_BIN")/.." && pwd)

# --- JDK：PATH 里通常没有 java，去 prefix/lib/jvm 里找 ---
JDK=""
for d in "$PREFIX"/lib/jvm/java-17-openjdk "$PREFIX"/lib/jvm/java-21-openjdk "$PREFIX"/lib/jvm/*; do
  if [ -x "$d/bin/javac" ]; then JDK="$d"; break; fi
done
if [ -z "$JDK" ]; then
  echo "错误: 找不到 JDK。请先 pkg_install openjdk-17。" >&2
  return 1 2>/dev/null || exit 1
fi
JAVA_HOME="$JDK"
export JAVA_HOME
PATH="$JDK/bin:$PREFIX/bin:$PATH"
export PATH

# --- Android SDK 组件（下载在可执行暂存区，不进共享存储）---
SCRATCH=${HARNESS_SCRATCH:-/data/local/tmp/androidharness-scratch}
ANDROID_JAR=${ANDROID_JAR:-$SCRATCH/sdk/platform37/android-37.0/android.jar}
R8_JAR=${R8_JAR:-$SCRATCH/dl/r8-9.4.24.jar}

for f in "$ANDROID_JAR" "$R8_JAR"; do
  if [ ! -f "$f" ]; then
    echo "错误: 缺少 $f" >&2
    return 1 2>/dev/null || exit 1
  fi
done

# --- 签名密钥（首次自动生成，仅本地调试用）---
KEYSTORE=${KEYSTORE:-$SCRATCH/foldercam-debug.keystore}
KS_PASS=android
KS_ALIAS=foldercam

# --- apksigner ---
# 注意: $PREFIX/bin/apksigner 是个 wrapper，里面写死了 termux 的 jar 路径，
# 在本机跑不通。直接用 java -jar 调用真正的 jar。
APKSIGNER_JAR=$PREFIX/share/java/apksigner.jar
if [ ! -f "$APKSIGNER_JAR" ]; then
  echo "错误: 找不到 $APKSIGNER_JAR。请先 pkg_install apksigner。" >&2
  return 1 2>/dev/null || exit 1
fi
apksigner() { java -jar "$APKSIGNER_JAR" "$@"; }

