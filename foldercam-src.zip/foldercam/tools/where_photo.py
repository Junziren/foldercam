#!/usr/bin/env python3
"""照片去哪儿了：相机总说「scheduleMigrateToCameraDirectoryWithWorkManager」，
说明它把照片写进了自己的目录，而不是我们给的 EXTRA_OUTPUT。

（文件名也不敢用，自己起名 IMG_日期_序号.jpg。）
这里全盘找一下刚才那张照片，确定它到底落在哪。
"""
import os
import subprocess
import time

J = os.path.join
S = os.sep + J("storage", "emulated", "0")


def sh(cmd, timeout=90):
    if isinstance(cmd, str):
        cmd = ["/system/bin/sh", "-c", cmd]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (p.stdout or "") + (p.stderr or "")
    except Exception as e:
        return "[sh error] %s" % e


def main():
    print("=== A. 直接按名字找 IMG_20260924_1006*.jpg ===")
    for base in (J(S, "DCIM"), J(S, "Pictures"), J(S, "Download"), J(S, "Pictures", "FolderCam")):
        if not os.path.isdir(base):
            continue
        for dirpath, dirnames, filenames in os.walk(base):
            for f in filenames:
                if "20260924_1006" in f:
                    fp = J(dirpath, f)
                    print("   %-62s %10d" % (fp.replace(S, "内部存储"), os.path.getsize(fp)))

    print()
    print("=== B. DCIM/Camera 全部文件（按时间倒序前 12）===")
    d = J(S, "DCIM", "Camera")
    if os.path.isdir(d):
        fs = sorted(((os.path.getmtime(J(d, f)), f) for f in os.listdir(d)), reverse=True)[:12]
        for mt, f in fs:
            print("   %-46s %10d  %s" % (f, os.path.getsize(J(d, f)),
                                         time.strftime("%m-%d %H:%M:%S", time.localtime(mt))))
    else:
        print("   (没有此目录)")

    print()
    print("=== C. 全盘最近 20 分钟的新文件（找 .jpg/.heic/.dng）===")
    now = time.time()
    n = 0
    for dirpath, dirnames, filenames in os.walk(S):
        if "/Agent Use" in dirpath or "/Android/data" in dirpath or "/Android/obb" in dirpath:
            dirnames[:] = []
            continue
        for f in filenames:
            low = f.lower()
            if not (low.endswith(".jpg") or low.endswith(".heic") or low.endswith(".dng")):
                continue
            fp = J(dirpath, f)
            try:
                if os.path.getmtime(fp) > now - 1200:
                    print("   %-62s %10d  %s" % (
                        fp.replace(S, "内部存储"), os.path.getsize(fp),
                        time.strftime("%H:%M:%S", time.localtime(os.path.getmtime(fp)))))
                    n += 1
            except OSError:
                pass
    if n == 0:
        print("   (最近 20 分钟没有新的图片文件)")

    print()
    print("=== D. MediaStore 里刚才那两张 ===")
    q = sh("content query --uri content://media/external/images/media "
           "--projection _id:_display_name:relative_path:_size:is_pending "
           "--where \"_display_name LIKE 'IMG_20260924_1006%'\"")
    print(q.strip()[:900] or "   (MediaStore 里没有)")

    print()
    print("=== E. 相机的工作队列（延迟写盘）===")
    lg = sh("logcat -d -v brief 2>/dev/null | grep -iE "
            "'PhotoDeferredWriter|WorkManager|MigrateToCamera|PendingMedia' | tail -15")
    print(lg.strip()[:1500] or "   (无)")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
