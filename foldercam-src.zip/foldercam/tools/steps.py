#!/usr/bin/env python3
"""分阶段截图驱动，一次进程内跑完，每一步都留证据。

关键认知（之前踩了很久的坑）：
  宿主聊天 App 是以「悬浮窗」形式浮在其它 App 上面的，
  所以 `dumpsys activity | grep ResumedActivity` 会一直报宿主 App 在前台，
  让人误以为我们的 App 没起来 / 相机没起来 —— 实际上它们都在正常显示。
  因此这里不再用前台判断流程，改为「每步截图，用眼睛确认」。

流程: 起 App -> 点快门 -> 截图1(看相机是否起来)
      -> 点相机快门 -> 截图2 -> 校验文件
"""
import os
import struct
import subprocess
import sys
import time
import zlib

PKG = "com.harness.foldercam"
REL = "Pictures/FolderCam/workA/"
OUTDIR = "build/steps"


def sh(cmd, timeout=90):
    if isinstance(cmd, str):
        cmd = ["/system/bin/sh", "-c", cmd]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (p.stdout or "") + (p.stderr or "")
    except Exception as e:
        return "[sh error] %s" % e


def shot(name):
    os.makedirs(OUTDIR, exist_ok=True)
    p = os.path.abspath(os.path.join(OUTDIR, name))
    if os.path.exists(p):
        os.remove(p)
    sh('screencap -p "%s"' % p)
    return p if os.path.exists(p) else None


def photos():
    out = sh("content query --uri content://media/external/images/media "
             "--projection _id:_display_name:relative_path:is_pending:_size "
             "--where \"relative_path='%s'\"" % REL)
    return [l.strip() for l in out.splitlines() if l.startswith("Row:")]


def load_png(path):
    d = open(path, "rb").read()
    pos, w, h, ct = 8, 0, 0, 0
    idat = b""
    while pos < len(d):
        ln = struct.unpack(">I", d[pos:pos + 4])[0]
        tag = d[pos + 4:pos + 8]
        body = d[pos + 8:pos + 8 + ln]
        if tag == b"IHDR":
            w, h = struct.unpack(">II", body[:8])
            ct = body[9]
        elif tag == b"IDAT":
            idat += body
        pos += 12 + ln
    raw = zlib.decompress(idat)
    ch = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}[ct]
    stride = w * ch
    rows, prev, p = [], bytearray(stride), 0
    for _ in range(h):
        f = raw[p]
        p += 1
        line = bytearray(raw[p:p + stride])
        p += stride
        if f == 1:
            for i in range(ch, stride):
                line[i] = (line[i] + line[i - ch]) & 255
        elif f == 2:
            for i in range(stride):
                line[i] = (line[i] + prev[i]) & 255
        elif f == 3:
            for i in range(stride):
                a = line[i - ch] if i >= ch else 0
                line[i] = (line[i] + ((a + prev[i]) >> 1)) & 255
        elif f == 4:
            for i in range(stride):
                a = line[i - ch] if i >= ch else 0
                b = prev[i]
                c = prev[i - ch] if i >= ch else 0
                pa, pb, pc = abs(b - c), abs(a - c), abs(a + b - 2 * c)
                pr = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
                line[i] = (line[i] + pr) & 255
        rows.append(bytes(line))
        prev = line
    return w, h, ch, rows


def find_bright_blob(path, y_from_frac=0.55):
    """在下半屏找最宽的白亮横块（相机快门是白色大圆环）。"""
    w, h, ch, rows = load_png(path)
    best = None
    for y in range(int(h * y_from_frac), h, 3):
        line = rows[y]
        run, start = 0, 0
        for x in range(0, w, 3):
            i = x * ch
            white = line[i] > 215 and line[i + 1] > 215 and line[i + 2] > 215
            if white:
                if run == 0:
                    start = x
                run += 1
            else:
                if run >= 8:
                    width = run * 3
                    score = width + y * 0.3
                    if best is None or score > best[0]:
                        best = (score, int(start + width / 2), y, width)
                run = 0
        if run >= 8:
            width = run * 3
            score = width + y * 0.3
            if best is None or score > best[0]:
                best = (score, int(start + width / 2), y, width)
    if not best:
        return None
    return best[1], best[2], best[3]


def main():
    print("=== 0. 干净启动 ===")
    sh("am force-stop %s" % PKG)
    time.sleep(1.5)
    sh("am start -n %s/.MainActivity" % PKG)
    time.sleep(4.5)
    print("   截图:", shot("s1_app.png"))

    print("=== 1. 点 App 快门 (600,2455) ===")
    sh("input tap 600 2455")
    time.sleep(6)
    p = shot("s2_camera.png")
    print("   截图:", p)

    print("=== 2. 从截图里找相机快门 ===")
    found = find_bright_blob(p) if p else None
    if found:
        cx, cy, cw = found
        print("   找到亮块 @(%d,%d) 宽=%d" % (cx, cy, cw))
        print("=== 3. 点它 ===")
        sh("input tap %d %d" % (cx, cy))
        time.sleep(7)
        print("   截图:", shot("s3_after.png"))
    else:
        print("   !! 没在截图里找到快门（相机可能没起来）")

    print("=== 4. 目标文件夹 ===")
    rows = photos()
    for r in rows[-5:]:
        print("   " + r[:150])
    if not rows:
        print("   (空)")

    print("=== 5. App 决策日志 ===")
    for line in sh("logcat -d -v brief -s FolderCam").strip().splitlines()[-10:]:
        print("   " + line.strip()[:170])
    return 0


if __name__ == "__main__":
    sys.exit(main())
