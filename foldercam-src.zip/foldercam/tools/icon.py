#!/usr/bin/env python3
"""生成 App 图标（白文件夹 + 蓝色镜头）。纯 python 光栅化 + 3x 超采样抗锯齿。

用法: python3 tools/icon.py
产出: app/res/mipmap-{xxhdpi,xxxhdpi}/ic_launcher.png
"""
import math
import os
import struct
import sys
import zlib

SS = 3  # 每个像素再细分 SS*SS 次
BG = (0x16, 0x18, 0x1D)
FOLDER = (0xFF, 0xFF, 0xFF)
LENS = (0x2F, 0x6B, 0xFF)
DOT = (0xFF, 0xFF, 0xFF)


def in_round_rect(x, y, x0, y0, x1, y1, r):
    if x < x0 or x > x1 or y < y0 or y > y1:
        return False
    cx = min(max(x, x0 + r), x1 - r)
    cy = min(max(y, y0 + r), y1 - r)
    dx, dy = x - cx, y - cy
    return dx * dx + dy * dy <= r * r


def in_circle(x, y, cx, cy, r):
    dx, dy = x - cx, y - cy
    return dx * dx + dy * dy <= r * r


def sample(u, v):
    """u,v 是 0..1 的归一化坐标，返回该点颜色。"""
    # 圆角方形底
    if not in_round_rect(u, v, 0.045, 0.045, 0.955, 0.955, 0.20):
        return None  # 透明

    col = BG

    # 文件夹：上盖 + 主体
    tab = in_round_rect(u, v, 0.195, 0.295, 0.475, 0.405, 0.035)
    body = in_round_rect(u, v, 0.195, 0.355, 0.805, 0.735, 0.055)
    if tab or body:
        col = FOLDER

    # 镜头
    if in_circle(u, v, 0.545, 0.545, 0.175):
        col = LENS
    if in_circle(u, v, 0.545, 0.545, 0.062):
        col = DOT

    return col


def render(size):
    n = size * SS
    rows = []
    for py in range(size):
        row = bytearray()
        for px in range(size):
            r = g = b = a = 0
            for sy in range(SS):
                for sx in range(SS):
                    u = (px * SS + sx + 0.5) / n
                    v = (py * SS + sy + 0.5) / n
                    c = sample(u, v)
                    if c is None:
                        continue
                    r += c[0]
                    g += c[1]
                    b += c[2]
                    a += 255
            total = SS * SS
            if a == 0:
                row += bytes((0, 0, 0, 0))
            else:
                # 预乘后再除，边缘才不会有黑边
                cover = a / (255.0 * total)
                row += bytes((int(r / (a / 255.0) + 0.5),
                              int(g / (a / 255.0) + 0.5),
                              int(b / (a / 255.0) + 0.5),
                              int(cover * 255 + 0.5)))
        rows.append(bytes(row))
    return rows


def write_png(path, size, rows):
    raw = b"".join(b"\x00" + r for r in rows)

    def chunk(tag, data):
        return (struct.pack(">I", len(data)) + tag + data
                + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))

    png = b"\x89PNG\r\n\x1a\n"
    png += chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0))
    png += chunk(b"IDAT", zlib.compress(raw, 9))
    png += chunk(b"IEND", b"")
    with open(path, "wb") as fh:
        fh.write(png)


def main():
    root = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
    targets = [("xxhdpi", 144), ("xxxhdpi", 192)]
    for bucket, size in targets:
        out_dir = os.path.join(root, "app", "res", "mipmap-" + bucket)
        os.makedirs(out_dir, exist_ok=True)
        out = os.path.join(out_dir, "ic_launcher.png")
        write_png(out, size, render(size))
        print("生成 %s (%dx%d, %d 字节)" % (out, size, size, os.path.getsize(out)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
