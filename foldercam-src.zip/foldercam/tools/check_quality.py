#!/usr/bin/env python3
"""验证 App 里的缩略图质量：截图 + 读照片真实分辨率。

用一次进程内完成，避免跨调用的前台抢占问题。
"""
import os
import re
import struct
import subprocess
import sys
import time

PKG = "com.harness.foldercam"
J = os.path.join
S = os.sep + J("storage", "emulated", "0")
DIR = J(S, "Pictures", "FolderCam", "workA")
OUT = "build/quality"


def sh(cmd, timeout=90):
    if isinstance(cmd, str):
        cmd = ["/system/bin/sh", "-c", cmd]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (p.stdout or "") + (p.stderr or "")
    except Exception as e:
        return "[sh error] %s" % e


def jpeg_size(path):
    """从 JPEG 的 SOF 段读出真实像素尺寸。"""
    with open(path, "rb") as f:
        d = f.read(400000)
    i = 2
    while i < len(d) - 9:
        if d[i] != 0xFF:
            i += 1
            continue
        m = d[i + 1]
        if m in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
                 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
            h, w = struct.unpack(">HH", d[i + 5:i + 9])
            return w, h
        if m in (0xD8, 0xD9) or 0xD0 <= m <= 0xD7:
            i += 2
            continue
        ln = struct.unpack(">H", d[i + 2:i + 4])[0]
        i += 2 + ln
    return None


def shot(name):
    os.makedirs(OUT, exist_ok=True)
    p = os.path.abspath(J(OUT, name))
    sh('screencap -p "%s"' % p)
    return p


def main():
    print("=== 文件夹里的照片 ===")
    if os.path.isdir(DIR):
        for f in sorted(os.listdir(DIR)):
            fp = J(DIR, f)
            if not os.path.isfile(fp):
                continue
            size = os.path.getsize(fp)
            dim = jpeg_size(fp) if f.lower().endswith((".jpg", ".jpeg")) else None
            print("   %-40s %9d 字节  %s" % (f, size,
                  ("%dx%d 像素" % dim) if dim else "(非 JPEG)"))

    print()
    print("=== 打开 App 看缩略图 ===")
    sh("am force-stop %s" % PKG)
    time.sleep(1.5)
    sh("am start -n %s/.MainActivity" % PKG)
    time.sleep(6)
    print("   截图:", shot("grid.png"))

    print("=== 进入大图页（点第一张）===")
    sh("input tap 200 600")
    time.sleep(4)
    print("   截图:", shot("viewer.png"))

    print()
    print("=== App 的缩略图解码日志（看有没有走原图解码）===")
    lg = sh("logcat -d -v brief 2>/dev/null | grep -iE 'FolderCam' | tail -6")
    print(lg.strip()[:600] or "   (无)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
