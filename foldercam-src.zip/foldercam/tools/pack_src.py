#!/usr/bin/env python3
"""把源码打成一个 zip，方便直接分享/上传（不含构建产物和 git 历史）。

用法: python3 tools/pack_src.py
产出: ../dist/foldercam-src.zip
"""
import os
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))          # .../foldercam/tools
ROOT = os.path.dirname(HERE)                                # .../foldercam
DIST = os.path.join(os.path.dirname(ROOT), "dist")          # .../dist

SKIP_DIRS = {"build", "out", ".git", "__pycache__", "dist"}
SKIP_EXT = (".pyc", ".apk", ".idsig")


def main():
    os.makedirs(DIST, exist_ok=True)
    out = os.path.join(DIST, "foldercam-src.zip")
    n = 0
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for dp, dn, fn in os.walk(ROOT):
            dn[:] = [d for d in dn if d not in SKIP_DIRS]
            for f in fn:
                if f.endswith(SKIP_EXT):
                    continue
                p = os.path.join(dp, f)
                rel = os.path.relpath(p, os.path.dirname(ROOT))
                z.write(p, rel)
                n += 1
    print("打包 %d 个文件" % n)
    print("-> %s (%.1f KB)" % (out, os.path.getsize(out) / 1024.0))
    return 0


if __name__ == "__main__":
    sys.exit(main())
