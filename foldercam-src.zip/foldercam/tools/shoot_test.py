#!/usr/bin/env python3
"""一次进程内跑完「进入文件夹 -> 拍一张 -> 校验落盘」。

必须原子执行的原因：两次工具调用之间宿主 App 会抢回前台，
任何跨调用的 input tap 都会打偏，且相机随时可能被切走。

入口用 MainActivity（exported=true）。ShootActivity 是 exported=false，
shell 无权直接启动：SecurityException: not exported from uid。
MainActivity 在冷启动时会自动进入上次用的文件夹。
"""
import os
import re
import subprocess
import sys
import time

PKG = "com.harness.foldercam"
CAM = "com.android.camera"
FOLDER = "workA"
REL = "Pictures/FolderCam/" + FOLDER + "/"
UI_XML = "/data/local/tmp/fc-drive.xml"

NODE_RE = re.compile(r"<node\b([^>]*?)/?>", re.S)
ATTR_RE = re.compile(r'([\w:-]+)="([^"]*)"')


def sh(cmd, timeout=90):
    if isinstance(cmd, str):
        cmd = ["/system/bin/sh", "-c", cmd]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (p.stdout or "") + (p.stderr or "")
    except Exception as e:
        return "[sh error] %s" % e


def top():
    out = sh("dumpsys activity activities 2>/dev/null | grep -m1 ResumedActivity")
    m = re.search(r"u0 ([A-Za-z0-9_.]+)/([A-Za-z0-9_.$]+)", out)
    if not m:
        return "", ""
    pkg, act = m.group(1), m.group(2)
    return pkg, (pkg + act if act.startswith(".") else act)


def dump():
    try:
        if os.path.exists(UI_XML):
            os.remove(UI_XML)
    except OSError:
        pass
    sh('uiautomator dump "%s" >/dev/null 2>&1' % UI_XML, timeout=30)
    try:
        xml = open(UI_XML, encoding="utf-8", errors="ignore").read()
    except OSError:
        return []
    out = []
    for m in NODE_RE.finditer(xml):
        a = dict(ATTR_RE.findall(m.group(1)))
        b = re.match(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", a.get("bounds", ""))
        if not b:
            continue
        x1, y1, x2, y2 = (int(v) for v in b.groups())
        out.append({
            "text": (a.get("text") or "").strip(),
            "desc": (a.get("content-desc") or "").strip(),
            "pkg": a.get("package", ""),
            "clickable": a.get("clickable") == "true",
            "cx": (x1 + x2) // 2, "cy": (y1 + y2) // 2,
            "w": x2 - x1, "h": y2 - y1,
        })
    return out


def tap(x, y, wait=1.0):
    sh("input tap %d %d" % (x, y))
    time.sleep(wait)


def wait_for(pred, seconds, label):
    end = time.time() + seconds
    while time.time() < end:
        if pred(*top()):
            return True
        time.sleep(0.4)
    print("   !! 超时等待 %s（当前 %s/%s）" % (label, *top()))
    return False


def photos():
    out = sh("content query --uri content://media/external/images/media "
             "--projection _id:_display_name:relative_path:is_pending:_size "
             "--where \"relative_path='%s'\"" % REL)
    return [l.strip() for l in out.splitlines() if l.startswith("Row:")]


def enter_shoot():
    """进入 ShootActivity。前台会被宿主 App 抢走，所以重试几次。"""
    for attempt in range(1, 4):
        if attempt > 1:
            print("   (第 %d 次尝试)" % attempt)
        sh("am force-stop %s" % PKG)
        time.sleep(1.5)
        sh("am start -n %s/.MainActivity" % PKG)
        if wait_for(lambda p, a: a.endswith("ShootActivity"), 8, "ShootActivity"):
            return True
        for n in dump():
            if n["pkg"] == PKG and FOLDER in n["text"]:
                tap(n["cx"], n["cy"], wait=2.5)
                break
        if wait_for(lambda p, a: a.endswith("ShootActivity"), 6, "ShootActivity"):
            return True
    return False


def main():
    print("=== 1. 进入 ShootActivity ===")
    if not enter_shoot():
        return 1
    print("   已进入: %s" % top()[1])

    print("=== 2. 点我们的快门 ===")
    # 快门是自定义 View（Ui.Shutter），没有文本/描述，uiautomator dump 里抓不到；
    # 而左右两侧的「选择」「换文件夹」是宽按钮，用「宽高>120」筛会先命中它们（踩过）。
    # 布局上快门在底部栏水平正中：x=600，y 与两侧按钮同一行 = 2455。
    print("   快门坐标 (600,2455)")
    tap(600, 2455, wait=2)

    print("=== 3. 等系统相机 ===")
    if not wait_for(lambda p, a: p.startswith(CAM), 15, "系统相机"):
        pkg, act = top()
        print("   当前 %s/%s" % (pkg, act))
        return 1
    print("   相机就绪: %s" % top()[1])

    print("=== 4. 点相机快门 ===")
    time.sleep(2.0)
    best = None
    for n in dump():
        if n["pkg"].startswith(CAM) and n["clickable"] \
                and n["w"] > 150 and n["h"] > 150 and n["cy"] > 1400:
            score = n["cy"] - abs(n["cx"] - 600)
            if best is None or score > best[0]:
                best = (score, n)
    if best:
        n = best[1]
        print("   快门 @(%d,%d) %dx%d" % (n["cx"], n["cy"], n["w"], n["h"]))
        tap(n["cx"], n["cy"], wait=2)
    else:
        print("   UI 里没有明显快门，用兜底坐标 (600,1898)")
        tap(600, 1898, wait=2)

    print("=== 5. 等回到 App ===")
    wait_for(lambda p, a: p == PKG, 25, "回到 FolderCam")
    print("   前台: %s/%s" % top())

    print("=== 6. 目标文件夹内容 ===")
    rows = photos()
    for r in rows[-6:]:
        print("   " + r[:150])
    if not rows:
        print("   (空)")

    print("=== 7. App 自己的决策日志 ===")
    for line in sh("logcat -d -v brief -s FolderCam").strip().splitlines()[-12:]:
        print("   " + line.strip()[:170])

    return 0 if rows else 1


if __name__ == "__main__":
    sys.exit(main())
