#!/system/bin/sh
# FolderCam 构建脚本 —— 不用 Gradle，手工构建链:
#   aapt2 compile -> aapt2 link -> javac -> d8 -> pack.py -> apksigner
# 用法: bash tools/build.sh   （在 foldercam/ 目录下执行）
set -e

FC_ROOT=$(cd "$(dirname "$0")/.." && pwd)
. "$FC_ROOT/tools/env.sh"

APP="$FC_ROOT/app"
SRC="$FC_ROOT/src"
BUILD="$FC_ROOT/build"
OUT="$FC_ROOT/out"

# 可以用环境变量覆盖，用来做二分排查
MANIFEST=${MANIFEST:-$APP/AndroidManifest.xml}
OUT_APK=${OUT_APK:-$OUT/FolderCam.apk}
RES_DIR=${RES_DIR:-$APP/res}
SRC_DIR=${SRC_DIR:-$SRC}
PKG_SOURCES=${PKG_SOURCES:-$BUILD/gen}

VERSION_CODE=8
VERSION_NAME=1.7
MIN_SDK=29
TARGET_SDK=37

echo "==> 工具链"
echo "    PREFIX = $PREFIX"
echo "    JDK    = $JDK ($(javac -version 2>&1))"

rm -rf "$BUILD"
mkdir -p "$BUILD/res" "$BUILD/gen" "$BUILD/classes" "$BUILD/dex" "$OUT"

echo "==> 1/6 编译资源 (aapt2 compile)"
aapt2 compile --dir "$RES_DIR" -o "$BUILD/res.zip"

echo "==> 2/6 链接资源 (aapt2 link)"
aapt2 link \
  -o "$BUILD/base.apk" \
  -I "$ANDROID_JAR" \
  --manifest "$MANIFEST" \
  --java "$BUILD/gen" \
  --min-sdk-version $MIN_SDK \
  --target-sdk-version $TARGET_SDK \
  --version-code $VERSION_CODE \
  --version-name "$VERSION_NAME" \
  --auto-add-overlay \
  "$BUILD/res.zip"

echo "==> 3/6 编译 Java (javac)"
echo "    注意: -source 8 是为了能用 -bootclasspath android.jar 严格按 Android API 编译；"
echo "          JDK 17 不允许 -source 17 与 -bootclasspath 同时出现。"
find "$SRC_DIR" "$PKG_SOURCES" -name '*.java' | sed 's/^/"/; s/$/"/' > "$BUILD/sources.txt"
echo "    java 文件数: $(wc -l < "$BUILD/sources.txt")"
javac -encoding UTF-8 -source 8 -target 8 \
  -bootclasspath "$ANDROID_JAR" -classpath "$ANDROID_JAR" \
  -nowarn -Xlint:-options \
  -d "$BUILD/classes" \
  @"$BUILD/sources.txt"

echo "==> 4/6 转 dex (d8)"
# 注意: 不能把 class 文件列表展开成参数——工作区路径里有空格会被拆开。
# 这个 d8 也不吃「class 目录」，所以先打成 jar 再喂给它。
(cd "$BUILD/classes" && jar cf "$BUILD/classes.jar" .)
java -Xmx1500m -cp "$R8_JAR" com.android.tools.r8.D8 \
  --min-api $MIN_SDK --release --lib "$ANDROID_JAR" \
  --output "$BUILD/dex" "$BUILD/classes.jar"

echo "==> 5/6 打包并对齐 (pack.py)"
python3 "$FC_ROOT/tools/pack.py" "$BUILD/base.apk" "$BUILD/unsigned.apk" "$BUILD/dex/classes.dex"

echo "==> 6/6 签名 (apksigner)"
if [ ! -f "$KEYSTORE" ]; then
  echo "    生成调试密钥库 $KEYSTORE"
  keytool -genkeypair -keystore "$KEYSTORE" -storepass android -keypass android \
    -alias foldercam -keyalg RSA -keysize 2048 -validity 10000 \
    -dname "CN=FolderCam, O=Harness, C=CN" >/dev/null 2>&1
fi
apksigner sign --ks "$KEYSTORE" --ks-pass pass:android --key-pass pass:android \
  --v1-signing-enabled true --v2-signing-enabled true \
  --out "$OUT_APK" "$BUILD/unsigned.apk"
apksigner verify --print-certs "$OUT_APK" | head -1

# 注意：不要去 chmod 工作区里的产物。
# 共享存储是 FUSE，chmod 会返回成功但权限根本没变；而且目录是 2770、
# 属主是 App 的 uid，MIUI 安装器（另一个 uid）根本进不去，会表现为
# "解析软件包时出现问题 (33) / packageInfo is null"。
# 真正要做的是把 APK 暂存到 /data/local/tmp（真 ext4，chmod 生效），
# 这件事由 tools/uinstall.py 的 stage() 负责。

echo
echo "构建成功 -> $OUT_APK ($(wc -c < "$OUT_APK") 字节)"
