#!/usr/bin/env python3
"""FolderCam 功能验收驱动。

核心约束（踩过的坑）：
  * 宿主聊天 App 是悬浮窗，会一直浮在最上层，`dumpsys ResumedActivity` 不可信；
    所以流程控制改用「dump 界面元素 + 截图」，不靠前台判断。
  * 两次工具调用之间前台会被抢走 -> 每个场景必须在「一个进程内」跑完。

子命令：
  onboard        走完首次引导页
  folder <名字>   建文件夹并进入拍摄页
  select         进多选、全选、再取消（验证「取消」出口）
  sort           切排序方式
  pack           全选后打包（验证 zip 生成）
  rename <名字>   给第一张照片改名
  zoom           进大图页并双击放大
  folderops      长按文件夹 -> 重命名 / 删除
  shot           完整拍一张（含相机确认页）
"""
import os
import re
import subprocess
import sys
import time

PKG = "com.harness.foldercam"
J = os.path.join
S = os.sep + J("storage", "emulated", "0")
STEPS = "build/flow"
UI = "/data/local/tmp/fc-flow.xml"


def sh(cmd, timeout=90):
    if isinstance(cmd, str):
        cmd = ["/system/bin/sh", "-c", cmd]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (p.stdout or "") + (p.stderr or "")
    except Exception as e:
        return "[sh error] %s" % e


def dump(retries=3):
    """取界面元素树。uiautomator 会间歇性返回空，所以失败要重试。"""
    for attempt in range(retries):
        try:
            if os.path.exists(UI):
                os.remove(UI)
        except OSError:
            pass
        sh('uiautomator dump "%s" >/dev/null 2>&1' % UI, timeout=30)
        try:
            xml = open(UI, encoding="utf-8", errors="ignore").read()
        except OSError:
            xml = ""
        if "<node" in xml:
            out = []
            for m in re.finditer(r"<node\b([^>]*?)/?>", xml, re.S):
                a = dict(re.findall(r'([\w:-]+)="([^"]*)"', m.group(1)))
                b = re.match(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", a.get("bounds", ""))
                if not b:
                    continue
                x1, y1, x2, y2 = (int(v) for v in b.groups())
                out.append({
                    "text": (a.get("text") or "").strip(),
                    "desc": (a.get("content-desc") or "").strip(),
                    "cls": a.get("class", ""),
                    "pkg": a.get("package", ""),
                    "clickable": a.get("clickable") == "true",
                    "cx": (x1 + x2) // 2, "cy": (y1 + y2) // 2,
                    "w": x2 - x1, "h": y2 - y1,
                })
            if out:
                return out
        time.sleep(1.2)
    return []


def label(n):
    return n["text"] or n["desc"]


def find(text, exact=False, pkg=None):
    for n in dump():
        lab = label(n)
        if not lab:
            continue
        if pkg and not n["pkg"].startswith(pkg):
            continue
        if (lab == text) if exact else (text in lab):
            return n
    return None


def tap(x, y, wait=1.2):
    sh("input tap %d %d" % (x, y))
    time.sleep(wait)


def tap_node(n, wait=1.2):
    tap(n["cx"], n["cy"], wait)


def tap_text(text, wait=1.5, exact=False, pkg=None):
    n = find(text, exact=exact, pkg=pkg)
    if n is None:
        print("   !! 找不到 %r" % text)
        return False
    print("   [点击] %r @(%d,%d)" % (label(n)[:30], n["cx"], n["cy"]))
    tap_node(n, wait)
    return True


def shot(name):
    os.makedirs(STEPS, exist_ok=True)
    p = os.path.abspath(J(STEPS, name))
    sh('screencap -p "%s"' % p)
    return p


def launch(reset=False):
    if reset:
        sh("am force-stop %s" % PKG)
        time.sleep(1.5)
    sh("am start -n %s/.MainActivity" % PKG)
    time.sleep(4)


def texts():
    return [label(n) for n in dump() if n["pkg"].startswith(PKG) and label(n)]


# ---------------------------------------------------------------- 场景

def sc_onboard():
    launch(reset=True)
    print("   当前界面:", texts()[:6])
    if not tap_text("去开启权限", wait=3):
        if not tap_text("稍后再说", wait=3):
            print("   (没有引导页，可能已经看过)")
    print("   引导后界面:", texts()[:6])
    print("   截图:", shot("onboard.png"))
    return 0


def sc_folder(name):
    launch(reset=False)
    if not tap_text("新建文件夹", wait=2):
        return 1
    # 找一个可输入的框
    edit = None
    for n in dump():
        if n["cls"].endswith("EditText"):
            edit = n
            break
    if edit is None:
        print("   !! 没有输入框")
        return 1
    tap_node(edit, 0.5)
    sh("input keyevent 123")
    for _ in range(30):
        sh("input keyevent 67")
    sh('input text "%s"' % name)
    time.sleep(0.8)
    if not tap_text("创建并开始拍", wait=3):
        return 1
    print("   界面:", texts()[:6])
    print("   截图:", shot("folder.png"))
    return 0


def sc_select():
    """多选：全选 -> 看计数 -> 取消（验证有出口）。"""
    launch(reset=False)
    if not tap_text("选择", wait=1.5):
        return 1
    print("   多选界面:", texts()[:8])
    print("   截图:", shot("select1.png"))
    if tap_text("全选", wait=1.5):
        print("   全选后:", [t for t in texts() if "已选" in t or "张" in t][:4])
        print("   截图:", shot("select2.png"))
    if not tap_text("取消", wait=2):
        print("   !! 取消按钮点不到")
        return 1
    after = texts()
    print("   取消后界面:", after[:6])
    print("   截图:", shot("select3.png"))
    ok = any("选择" in t for t in after)
    print("   ==> 退出多选:", "成功" if ok else "失败")
    return 0 if ok else 1


def sc_sort():
    launch(reset=False)
    if not tap_text("⋯", wait=1.5, exact=True):
        return 1
    print("   ⋯菜单:", texts()[:9])
    if not tap_text("排序方式", wait=1.5):
        return 1
    print("   排序选项:", texts()[:6])
    tap_text("文件大的在前", wait=2)
    print("   排序后:", [t for t in texts() if "张" in t][:3])
    print("   截图:", shot("sort.png"))
    return 0


def sc_pack():
    """全选 -> 打包 -> 用 logcat 验证 zip 真的生成了（shell 读不到 App 私有目录）。"""
    sh("logcat -c")
    launch(reset=False)
    if not tap_text("选择", wait=1.5):
        return 1
    if not tap_text("全选", wait=1.5):
        return 1
    if not tap_text("打包", wait=2):
        return 1

    # 等打包结束（进度框消失 / 分享面板出现）
    for i in range(24):
        time.sleep(1.5)
        ts = texts()
        if not any("正在打包" in t for t in ts):
            break
    print("   打包后界面:", ts[:8])
    print("   截图:", shot("pack.png"))

    print("   --- App 的打包日志 ---")
    lg = sh("logcat -d -v brief -s FolderCam")
    ok = False
    for line in lg.strip().splitlines():
        s = line.strip()
        if "打包" in s or "zip" in s.lower():
            print("   " + s[:180])
            if "打包完成" in s:
                ok = True
    if not ok:
        print("   !! 没有看到「打包完成」")
        # 看看有没有别的问题
        for line in lg.strip().splitlines()[-6:]:
            print("   | " + line.strip()[:170])
    print("   ==> 打包:", "成功" if ok else "失败")

    # 把分享面板关掉，恢复干净状态
    sh("input keyevent 4")
    time.sleep(1)
    return 0 if ok else 1


def sc_listzip():
    """看 App 私有目录里到底有没有 zip（用 logcat 里报的路径 stat）。"""
    lg = sh("logcat -d -v brief -s FolderCam")
    paths = []
    for line in lg.splitlines():
        m = re.search(r"打包完成:\s*(\S+)", line)
        if m:
            paths.append(m.group(1))
    if not paths:
        print("   (没有打包记录)")
        return 1
    for p in set(paths):
        out = sh("stat -c '%%s %%n' '%s' 2>&1" % p)
        print("   " + out.strip())
    return 0


def sc_rename(newname):
    launch(reset=False)
    # 点第一张进大图页
    tap(200, 700, 3)
    print("   大图页:", texts()[:8])
    print("   截图:", shot("viewer.png"))
    if not tap_text("改名", wait=2):
        return 1
    edit = None
    for n in dump():
        if n["cls"].endswith("EditText"):
            edit = n
            break
    if edit is None:
        print("   !! 改名对话框没有输入框")
        return 1
    tap_node(edit, 0.5)
    sh("input keyevent 123")
    for _ in range(40):
        sh("input keyevent 67")
    sh('input text "%s"' % newname)
    time.sleep(0.8)
    tap_text("确定", wait=2.5)
    print("   改名后:", texts()[:6])
    print("   截图:", shot("renamed.png"))

    # 磁盘上验证
    d = J(S, "Pictures", "FolderCam", "workA")
    if os.path.isdir(d):
        print("   文件夹内容:", sorted(os.listdir(d)))
    return 0


def sc_zoom():
    launch(reset=False)
    tap(200, 700, 3)   # 进大图
    print("   大图页:", texts()[:5])
    # 双击放大
    sh("input tap 600 1200")
    time.sleep(0.15)
    sh("input tap 600 1200")
    time.sleep(2)
    print("   双击放大后截图:", shot("zoom_in.png"))
    # 拖动
    sh("input swipe 600 1400 500 1000 400")
    time.sleep(1)
    print("   拖动后截图:", shot("zoom_pan.png"))
    # 双击还原
    sh("input tap 600 1200")
    time.sleep(0.15)
    sh("input tap 600 1200")
    time.sleep(2)
    print("   还原后截图:", shot("zoom_out.png"))
    return 0


def sc_folderops():
    launch(reset=False)
    # 长按第一行文件夹
    n = None
    for x in dump():
        if x["pkg"].startswith(PKG) and x["cy"] > 350 and x["cy"] < 700:
            n = x
            break
    if n is None:
        print("   !! 找不到文件夹行")
        return 1
    print("   长按文件夹行 @(%d,%d)" % (n["cx"], n["cy"]))
    sh("input swipe %d %d %d %d 900" % (n["cx"], n["cy"], n["cx"], n["cy"]))
    time.sleep(2)
    print("   长按菜单:", texts()[:9])
    print("   截图:", shot("folderops.png"))
    return 0


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    cmd = sys.argv[1]
    arg = sys.argv[2] if len(sys.argv) > 2 else None
    fn = {
        "onboard": lambda: sc_onboard(),
        "folder": lambda: sc_folder(arg or "workA"),
        "select": sc_select,
        "sort": sc_sort,
        "pack": sc_pack,
        "listzip": sc_listzip,
        "rename": lambda: sc_rename(arg or "重命名测试"),
        "zoom": sc_zoom,
        "folderops": sc_folderops,
    }.get(cmd)
    if fn is None:
        print(__doc__)
        return 2
    return fn()


if __name__ == "__main__":
    sys.exit(main())
