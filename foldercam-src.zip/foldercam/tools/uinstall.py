#!/usr/bin/env python3
"""在 MIUI/HyperOS 上自动安装 APK。

为什么需要这个脚本（踩过的坑，都验证过）：

1. `pm install` 在这台机器上永远失败。MIUI 在 PackageManagerServiceImpl 里挂钩
   verifyInstallFromShell，只回一句 INSTALL_FAILED_USER_RESTRICTED。
   （注意：这条路能用来判断 APK 是否可解析 —— 报 "Failed to parse APK file"
   才是真解析失败，报 USER_RESTRICTED 说明解析是好的。）

2. 所以只能把 APK 以 file:// 交给系统安装器（com.miui.packageinstaller），
   再一路点过它的弹窗。

3. 【最坑的一条】APK 所在的目录必须让安装器进得去。
   工作区在 /storage/emulated/0/... 上，目录权限是 2770、属主是 App 的 uid，
   而安装器是另一个 uid、也不在 media_rw 组里 —— 于是
   VerityUtils: Failed to measure fs-verity, errno 13 (EACCES)
   -> getPackageArchiveInfo() 返回 null
   -> 界面上就是「解析软件包时出现问题。(33) / packageInfo is null」。
   FUSE 层还会忽略 chmod，所以改工作区里的权限没用。
   解决：把 APK 复制到 /data/local/tmp 下的暂存目录（真 ext4，chmod 生效），
   并且父目录也要 o+rx，安装器才穿得进去。

4. 点击必须限定在安装器的窗口里。否则安装器没起来时，脚本会对着
   当前前台（可能是聊天界面）乱点 —— 这个 bug 真发生过。

用法: python3 tools/uinstall.py [apk路径]
"""
import os
import re
import shutil
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
APK = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else \
    os.path.abspath(os.path.join(HERE, "..", "out", "FolderCam.apk"))
PKG = "com.harness.foldercam"
INSTALLER = "com.miui.packageinstaller"

SCRATCH = os.environ.get("HARNESS_SCRATCH", "/data/local/tmp/androidharness-scratch")
# 【关键】暂存目录必须放在 /data/local/tmp 直下，不能放在 $HARNESS_SCRATCH 里面。
# 因为 $HARNESS_SCRATCH 的权限是 drwx------（而且会被周期性重置回 0700），
# MIUI 安装器是另一个 uid，压根穿不进这一层，结果就是
#   MIUIPI_Installer: open failed: EACCES (Permission denied)
#   -> 界面上显示「安装失败(-999)」
# /data/local/tmp 本身是 drwxrwx--x（other 有 x，可穿透），放在它下面才读得到。
STAGE_DIR = os.path.join(os.path.dirname(SCRATCH.rstrip("/")), "foldercam-stage")
STAGE_APK = os.path.join(STAGE_DIR, "install.apk")
UI_XML = "/data/local/tmp/foldercam-ui.xml"

NODE_RE = re.compile(r"<node\b([^>]*?)/?>", re.S)
ATTR_RE = re.compile(r'([\w:-]+)="([^"]*)"')

# 复选框：点一次就够（重复点会来回切）
CHECKBOX_HINTS = ("记住我的选择", "已了解此应用未经安全")
# 按钮：ICP 弹窗 -> 安全提醒页 -> 最终安装，可能依次出现
BUTTON_HINTS = ("允许", "继续安装", "安装", "确定", "同意")


def sh(cmd, timeout=60):
    """Android 上没有 /bin/sh，subprocess 的 shell=True 会静默失败。"""
    if isinstance(cmd, str):
        cmd = ["/system/bin/sh", "-c", cmd]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (p.stdout or "") + (p.stderr or "")
    except Exception as e:
        return "[sh error] %s" % e


def installed():
    return ("package:%s" % PKG) in sh("pm list packages %s" % PKG)


def foreground():
    out = sh("dumpsys activity activities 2>/dev/null | grep -m1 ResumedActivity")
    m = re.search(r"u0 ([A-Za-z0-9_.]+)/", out)
    return m.group(1) if m else ""


def stage():
    """把 APK 放到安装器读得到的地方，并校验整条路径都能被「其他用户」穿透。

    返回 (apk路径, 校验信息)；路径不可读时抛 RuntimeError —— 宁可立刻报错，
    也不要让安装器在那里转圈然后给一个笼统的 -999。
    """
    os.makedirs(STAGE_DIR, exist_ok=True)
    shutil.copy2(APK, STAGE_APK)
    sh('chmod 755 "%s"' % STAGE_DIR)
    sh('chmod 644 "%s"' % STAGE_APK)

    # 逐级检查：目录需要 o+x（可穿透），文件需要 o+r（可读）
    parts = []
    path = STAGE_APK
    while True:
        parts.append(path)
        parent = os.path.dirname(path)
        if parent == path or parent in ("", "/"):
            break
        path = parent
    parts.reverse()

    bad = []
    lines = []
    for p in parts:
        info = sh('stat -c "%%A %%U %%G" "%s"' % p).strip()
        mode = info.split()[0] if info else "????"
        is_dir = os.path.isdir(p)
        ok = ("x" in mode[7:10]) if is_dir else ("r" in mode[7:10])
        lines.append("   %s %s  %s" % ("OK " if ok else "BAD", mode, p))
        if not ok:
            bad.append(p)
    report = "\n".join(lines)
    if bad:
        raise RuntimeError("这些路径安装器读不到（other 权限不足）:\n  " + "\n  ".join(bad)
                           + "\n" + report)
    return report


def dump_nodes():
    try:
        if os.path.exists(UI_XML):
            os.remove(UI_XML)
    except OSError:
        pass
    sh('uiautomator dump "%s" >/dev/null 2>&1' % UI_XML, timeout=30)
    try:
        with open(UI_XML, encoding="utf-8", errors="ignore") as fh:
            xml = fh.read()
    except OSError:
        return []
    nodes = []
    for m in NODE_RE.finditer(xml):
        a = dict(ATTR_RE.findall(m.group(1)))
        bm = re.match(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", a.get("bounds", ""))
        if not bm:
            continue
        x1, y1, x2, y2 = (int(v) for v in bm.groups())
        nodes.append({
            "text": (a.get("text") or "").strip(),
            "desc": (a.get("content-desc") or "").strip(),
            "pkg": a.get("package", ""),
            "clickable": a.get("clickable") == "true",
            "cx": (x1 + x2) // 2,
            "cy": (y1 + y2) // 2,
        })
    return nodes


def label(n):
    return n["text"] or n["desc"]


def tap(n):
    sh("input tap %d %d" % (n["cx"], n["cy"]))


def find_button(nodes, exact):
    """先找可点的；部分 ROM 的按钮本身不标 clickable，就退回文本匹配。"""
    fallback = None
    for n in nodes:
        if label(n) != exact or n["pkg"] != INSTALLER:
            continue
        if n["clickable"]:
            return n
        if fallback is None:
            fallback = n
    return fallback


def main():
    if not os.path.isfile(APK):
        print("找不到 APK: %s" % APK)
        return 1

    # 注意：默认不卸载。
    # 反复「卸载再装」会抹掉用户数据和文件夹清单，而且每次都要重走全网关。
    # 装同签名的包时系统安装器会走「更新」路径，直接覆盖即可。
    # 需要干净重装时才加 --fresh。
    fresh = "--fresh" in sys.argv
    if installed():
        if fresh:
            print("==> --fresh: 先卸载（会清掉 App 数据）")
            sh("pm uninstall %s" % PKG)
            time.sleep(1)
        else:
            print("==> 已安装：走更新安装，保留数据")

    print("==> 暂存 APK 到安装器读得到的位置")
    try:
        print(stage())
    except RuntimeError as e:
        print("!! 暂存失败: %s" % e)
        return 1

    print("==> 唤醒屏幕并交给系统安装器")
    sh("input keyevent 224")
    time.sleep(0.5)
    sh('am start -a android.intent.action.VIEW -d "file://%s" '
       '-t application/vnd.android.package-archive' % STAGE_APK)

    tapped_boxes = set()
    clicks = {}
    waited = 0
    deadline = time.time() + 180

    while time.time() < deadline:
        time.sleep(2.0)
        if installed():
            print("==> 安装成功: %s" % PKG)
            return 0

        fg = foreground()
        if fg != INSTALLER:
            # 关键：只在安装器在前台时才去点，绝不碰其他界面
            waited += 1
            if waited in (1, 4, 10, 20):
                print("   ...安装器还没到前台（当前前台: %s），等待中"
                      % (fg or "未知"))
            continue

        nodes = dump_nodes()
        if not nodes:
            continue

        # 1) 勾复选框（每个只勾一次）
        done = False
        for h in CHECKBOX_HINTS:
            for n in nodes:
                lab = label(n)
                if h in lab and lab not in tapped_boxes and n["pkg"] == INSTALLER:
                    print("   [勾选] %s" % lab)
                    tap(n)
                    tapped_boxes.add(lab)
                    done = True
                    break
            if done:
                break
        if done:
            continue

        # 2) 点按钮
        for h in BUTTON_HINTS:
            n = find_button(nodes, h)
            if n is not None and clicks.get(h, 0) < 4:
                clicks[h] = clicks.get(h, 0) + 1
                print("   [点击] %s  @(%d,%d)" % (h, n["cx"], n["cy"]))
                tap(n)
                done = True
                break
        if done:
            continue

        # 3) 没有可点的：多半在等指纹/身份验证（那个窗口带 FLAG_SECURE，读不到）
        waited += 1
        if waited in (1, 5, 12, 25):
            labels = [label(n) for n in nodes if label(n)]
            print("   ...等待中（可能在等你按指纹 / 验证身份）当前: %s"
                  % (" / ".join(labels[:5]) if labels else "（读不到，可能是安全窗口）"))

    print("==> 超时：请看看手机上是否还有没处理的弹窗（尤其指纹验证）")
    return 1


if __name__ == "__main__":
    sys.exit(main())
