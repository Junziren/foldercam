# 文件夹相机 (FolderCam)

> 拍完的照片直接落进你指定的文件夹，按文件夹管理素材，不再被相册的时间线绑架。

## 这个 App 做什么

系统相册只能按时间线浏览。拍素材时（"某产品 10 张"、"某场景 20 张"）前后混在一起，
后期挑图很痛苦。FolderCam 只做一件事：**把相机拍出来的原图，直接放进你指定的文件夹里**。

- **拍照完全交给本机相机**：HDR、夜景、人像、滤镜、变焦、水印全部用系统相机自带的，
  本 App 一行相机代码都不写（`ACTION_IMAGE_CAPTURE` + `EXTRA_OUTPUT`）
- **照片落在真实目录**：`Pictures/FolderCam/<文件夹名>/`，文件管理器 / USB / 微信都能直接用
- **按文件夹浏览**，不受系统相册时间线影响

## 功能

| 功能 | 说明 |
|------|------|
| 新建文件夹 | 输入名字即创建，例如 `产品A-白底` |
| 指定文件夹拍照 | 按快门 → 系统相机 → 拍完点 ✓ → 原图落进该文件夹 |
| 素材墙 | 缩略图按拍摄顺序排列，可选时间 / 大小 / 名称排序 |
| 大图查看 | 双指缩放、双击放大、拖动看细节、左右滑动翻页 |
| 单张改名 | 保留扩展名，同文件夹内防重名 |
| 批量操作 | 多选后：分享 / 打包 zip / 移动 / 删除 |
| 打包分享 | 把一批照片打成 zip 整包发出（微信、QQ、网盘都认） |
| 文件夹菜单 | 长按：进入拍摄 / 复制路径 / 打包分享 / 重命名 / 删除 |
| 记住上次文件夹 | 冷启动直达该文件夹的拍摄页 |
| 显示完整路径 | 每张照片的真实路径，点一下复制 |

## 目录结构

```
foldercam/
├─ app/
│  ├─ AndroidManifest.xml
│  └─ res/values/{strings,colors,styles}.xml
│  └─ res/mipmap-*/ic_launcher.png      # python 生成
├─ src/com/harness/foldercam/
│  ├─ MainActivity.java       文件夹列表、新建、设置、新手引导
│  ├─ ShootActivity.java      拍摄页：快门 + 素材墙 + 多选 + 排序
│  ├─ ViewerActivity.java     大图页：缩放、改名、分享、删除
│  ├─ CameraLauncher.java     ACTION_IMAGE_CAPTURE 封装
│  ├─ Media.java              MediaStore 增删查改、移动、重命名
│  ├─ FolderStore.java        文件夹清单 / 上次文件夹 / 设置
│  ├─ Thumbs.java             缩略图线程池 + LruCache
│  ├─ ZoomImageView.java      双指缩放 / 双击放大 / 拖动
│  ├─ Zip.java                打包分享
│  ├─ LocalFileProvider.java  极简 FileProvider（不依赖 AndroidX）
│  └─ Ui.java                 尺寸、圆角、toast、自绘快门
├─ tools/
│  ├─ build.sh                编译打包（aapt2 → javac → d8 → apksigner）
│  ├─ env.sh                  工具链探测
│  ├─ install.sh              安装并启动
│  ├─ uinstall.py             MIUI 上的自动安装（见下）
│  ├─ pack.py                 zip 对齐打包器（本机没有 zipalign）
│  ├─ icon.py                 生成图标
│  └─ *.py                    各种验收 / 诊断脚本
└─ out/FolderCam.apk
```

零第三方依赖：纯 Java + framework 控件，没有 AndroidX，所以能手工构建，不必上 Gradle。

## 构建（本机无 Android Studio 也能构建）

```sh
cd foldercam
bash tools/build.sh          # 产出 out/FolderCam.apk
```

工具链：`openjdk-17` + `aapt2` + `apksigner`（`pkg_install` 安装），
`android.jar`(SDK 37) 与 `r8`(d8) 解压在 `$HARNESS_SCRATCH`。
细节见 `tools/env.sh`。

## 安装

```sh
python3 tools/uinstall.py out/FolderCam.apk
```

**这台机器上 `pm install` 永远失败**，因为 MIUI 在 `verifyInstallFromShell` 里挂钩，
只回一句 `INSTALL_FAILED_USER_RESTRICTED`。所以只能把 APK 交给系统安装器、
再点过它的几道弹窗。`uinstall.py` 处理了这些，但有一个**必须用户本人做**的动作：
MIUI 对未上架/未备案的 App 会弹**指纹验证**，脚本会停下来提示。

### 两个坑（都踩过，记下来省时间）

1. **APK 暂存位置**：必须放在 `/data/local/tmp/foldercam-stage` 这类让安装器读得到的地方。
   工作区在 `/storage/emulated/0` 上、目录权限是 `2770` 且属主是 App 的 uid，
   MIUI 安装器是另一个 uid，读不到 → `getPackageArchiveInfo()` 返回 null →
   界面上显示「解析软件包时出现问题 (33) / packageInfo is null」。
   而且共享存储是 FUSE，`chmod` 会返回成功但权限不变。

2. **版本号必须递增**：同 versionCode 覆盖安装会被 MIUI 拒绝（-999）。

## 权限说明

| 权限 | 为什么需要 |
|------|-----------|
| `MANAGE_EXTERNAL_STORAGE` | **必需**。见下面「MIUI 相机的坑」 |
| `READ_MEDIA_IMAGES` | 可选。开着才能看到外部拷进来的照片；不开也能正常拍照和管理自拍素材 |

`MANAGE_EXTERNAL_STORAGE` 需要手动或用 Shizuku 开一次：

```sh
uid=$(pm list packages -U | grep com.harness.foldercam | grep -oE 'uid:[0-9]+' | cut -d: -f2)
cmd appops set --uid $uid MANAGE_EXTERNAL_STORAGE allow
# 生效标志：appops get 出现 "Uid mode: MANAGE_EXTERNAL_STORAGE: allow"
```

## ★ MIUI 相机的坑（本项目最花时间的地方）

**MIUI(HyperOS) 的相机只认 `file://` 形式的 `EXTRA_OUTPUT`，不认 `content://`。**

传 `content://` 时（MediaStore pending 行那种）：
- 相机日志：`setShotSavePath: /storage/emulated/0/DCIM/Camera/IMG_xxx.jpg`
  —— 它把自己的保存路径**硬编码成 DCIM/Camera**，无视我们给的 URI
- `DbItemSaveTask: updateFinalImageState ... update count 0` —— MediaStore 记录没建起来
- 结果：照片在内存里确实拍出来了（`mOutputSize=4096x3072`），但**磁盘上什么都不留**
- 调用方收到 `result=0`，或者 `result=-1` 但文件是 0 字节
- 表现就非常像「App 有 bug，照片没保存」

换 `file://` 之后立刻正常，实测 3.5MB / 4.6MB 原图都能落盘。
代价是需要 `MANAGE_EXTERNAL_STORAGE`，这也是为什么这个 App 必须申请它 ——
**不是偷窥用户文件，是因为 Android 要求往公共目录写 file:// 路径就得有这个权限。**

其他两个配套的点：
- 必须在 Manifest 里**声明** `MANAGE_EXTERNAL_STORAGE`，否则 `appops set` 会返回成功
  但值是 `default`（没地方落地，看起来像被 MIUI 拦了）
- `file://` 会被 StrictMode 判 `FileUriExposed` 抛异常，要在 `onCreate` 里
  `StrictMode.setVmPolicy(new VmPolicy.Builder().build())` 放行

## 验证脚本

| 脚本 | 用途 |
|------|------|
| `tools/feature_test.py` | 功能验收：onboard/folder/select/sort/pack/rename/zoom/folderops |
| `tools/full_flow.py` | 完整拍摄流程（含相机确认页） |
| `tools/where_photo.py` | 照片丢了？全盘搜它在哪 |
| `tools/exp_no_output.py` | 实验：不传 EXTRA_OUTPUT 时相机行为 |
| `tools/exp_file_uri.py` | 实验：file:// vs content:// 对比 |
| `tools/diag.py` | 抓 App 决策日志与 URI 授权异常 |

### 自动化时的注意事项

- **宿主聊天 App 是悬浮窗**，一直浮在最上层。
  `dumpsys activity | grep ResumedActivity` 会永远报宿主在前台，
  千万别用它判断「我们的 App / 相机有没有起来」—— 会被彻底误导。
  用「截图 + 看像素」或者 dump 界面元素。
- 两次工具调用之间前台会被抢走 → UI 自动化必须写在**一个脚本进程内**原子执行，
  跨工具调用的 `input tap` 一定打偏。
- `uiautomator dump` 处理不了带空格的路径（会写到错的地方），要 dump 到 `/data/local/tmp/`。
- `uiautomator dump` 会间歇性返回空，要重试。

## MIUI 相机界面坐标（1200x2608，仅供自动化参考）

```
取景页：  × 取消 (182,1755)    ○ 快门 (600,1755)    ⟳ 翻转 (1018,1755)
确认页：  × 取消 (357,1755)    ✓ 确认 (822,1755)      <-- 必须点 ✓，点 × 照片就丢
```
