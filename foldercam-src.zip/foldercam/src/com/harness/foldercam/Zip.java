package com.harness.foldercam;

import android.content.Context;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * 把一批照片打包成一个 zip，方便整包分享（微信/网盘/邮件都认）。
 *
 * 不依赖 AndroidX，只用 java.util.zip；照片可能很大，所以是流式边读边写，
 * 不会把整张图塞进内存。
 */
final class Zip {

    private static final String TAG = "FolderCam";
    private static final String DIR = "share";

    private Zip() {
    }

    static File shareDir(Context ctx) {
        File d = new File(ctx.getFilesDir(), DIR);
        if (!d.exists() && !d.mkdirs()) return null;
        return d;
    }

    /** 清掉上次打包残留，避免缓存目录无限长大。 */
    static void cleanOld(Context ctx) {
        File d = shareDir(ctx);
        if (d == null) return;
        File[] fs = d.listFiles();
        if (fs == null) return;
        long cutoff = System.currentTimeMillis() - 6L * 3600 * 1000; // 留 6 小时
        for (File f : fs) {
            if (f.isFile() && f.lastModified() < cutoff) {
                //noinspection ResultOfMethodCallIgnored
                f.delete();
            }
        }
    }

    interface Progress {
        void onProgress(int done, int total);
    }

    /**
     * 把 shots 打成一个 zip。
     *
     * @param zipName 压缩包文件名（不含路径）
     * @return 生成的文件；失败返回 null
     */
    static File pack(Context ctx, String zipName, List<Media.Shot> shots, Progress cb) {
        File dir = shareDir(ctx);
        if (dir == null) return null;
        cleanOld(ctx);

        File out = new File(dir, zipName);
        ZipOutputStream zos = null;
        try {
            zos = new ZipOutputStream(new FileOutputStream(out));
            zos.setLevel(6);
            int done = 0;
            java.util.Set<String> used = new java.util.HashSet<>();
            for (Media.Shot s : shots) {
                String entry = uniqueEntry(used, s.name == null ? "IMG.jpg" : s.name);
                InputStream in = open(ctx, s);
                if (in == null) continue;
                try {
                    zos.putNextEntry(new ZipEntry(entry));
                    byte[] buf = new byte[64 * 1024];
                    int n;
                    while ((n = in.read(buf)) > 0) zos.write(buf, 0, n);
                    zos.closeEntry();
                } finally {
                    try {
                        in.close();
                    } catch (Exception ignored) {
                    }
                }
                done++;
                if (cb != null) cb.onProgress(done, shots.size());
            }
            zos.finish();
            zos.close();
            zos = null;
            Log.i(TAG, "打包完成: " + out.getAbsolutePath() + " (" + out.length() + " 字节, "
                    + done + " 张)");
            return out;
        } catch (Exception e) {
            Log.w(TAG, "打包失败: " + e);
            //noinspection ResultOfMethodCallIgnored
            out.delete();
            return null;
        } finally {
            if (zos != null) {
                try {
                    zos.close();
                } catch (Exception ignored) {
                }
            }
        }
    }

    private static InputStream open(Context ctx, Media.Shot s) {
        try {
            File f = s.file;
            if (f == null) f = Media.publicFilePath(ctx, s.rel, s.name);
            if (f != null && f.exists()) return new FileInputStream(f);
            if (s.uri != null) return ctx.getContentResolver().openInputStream(s.uri);
        } catch (Exception ignored) {
        }
        return null;
    }

    /** 同一个压缩包里不允许重名。 */
    private static String uniqueEntry(java.util.Set<String> used, String name) {
        String base = name;
        int dot = name.lastIndexOf('.');
        String stem = dot > 0 ? name.substring(0, dot) : name;
        String ext = dot > 0 ? name.substring(dot) : "";
        String cand = base;
        int i = 1;
        while (!used.add(cand.toLowerCase(Locale.US))) {
            cand = stem + "_" + i + ext;
            i++;
        }
        return cand;
    }

    /** 给压缩包起个带时间戳的名字，避免覆盖。 */
    static String defaultName(String folder, int count) {
        java.text.SimpleDateFormat f =
                new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US);
        String safe = folder == null ? "相册" : folder.replaceAll("[\\\\/:*?\"<>|]", "_");
        return String.format(Locale.US, "%s_%d张_%s.zip", safe, count, f.format(new java.util.Date()));
    }
}
