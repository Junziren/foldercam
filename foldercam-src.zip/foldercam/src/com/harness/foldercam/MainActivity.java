package com.harness.foldercam;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** 文件夹列表：新建、进入拍摄、重命名、删除、设置根目录。 */
public class MainActivity extends Activity {

    private FolderStore store;
    private ListView list;
    private View emptyView;
    private TextView hintView;
    private TextView rootChip;
    private final List<Row> rows = new ArrayList<>();
    private RowAdapter adapter;
    private boolean launchedDirectly;

    private static final int REQ_PERM = 0x11;

    private static final class Row {
        String name;
        String rel;
        int count;
        Media.Shot cover;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.edgeToEdge(getWindow());
        store = new FolderStore(this);
        setContentView(buildUi());

        if (b == null) {
            // 首次启动：先解释清楚为什么需要「所有文件访问」，再谈别的
            if (!store.onboarded()) {
                showOnboarding();
            } else {
                String last = store.last();
                if (last != null) {
                    launchedDirectly = true;
                    openShoot(last);
                }
            }
        }
        maybeAskPermission();
    }

    /**
     * 首次启动引导。
     *
     * 必须解释「所有文件访问」这个看起来很吓人的权限，否则用户会以为是流氓 App：
     * 真实原因是 MIUI 的相机不认 content:// 的输出路径，只认 file://，
     * 而用 file:// 往公共目录写文件就需要这个权限。
     */
    private void showOnboarding() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        Ui.padding(box, this, 24, 6, 24, 6);

        String[][] points = {
                {"拍照交给本机相机", "HDR、夜景、人像、滤镜、变焦全都用系统相机自带的，本 App 一行相机代码都不写。"},
                {"拍完直接进你的文件夹", "选一个文件夹再按快门，照片就落在 Pictures/FolderCam/<文件夹名>/ 里，不混时间线。"},
                {"为什么要「所有文件访问」", "这台手机的相机只认 file:// 形式的保存路径。要往公共相册目录写这种路径，"
                        + "Android 就要求 App 拿到「所有文件访问」。不给的话，相机不会把照片存进你指定的文件夹（拍了也白拍）。"},
                {"随时可以撤销", "在 系统设置 → 应用 → 文件夹相机 → 所有文件访问 里关掉即可。"},
        };
        for (String[] p : points) {
            TextView t = Ui.bold(Ui.text(this, "· " + p[0], 14.5f, Ui.INK));
            box.addView(t);
            TextView d = Ui.text(this, p[1], 12.5f, Ui.INK2);
            d.setLineSpacing(Ui.dp(this, 4), 1f);
            box.addView(d);
            Ui.margin(d, this, 0, 5, 0, 14);
        }

        android.widget.ScrollView scroller = new android.widget.ScrollView(this);
        scroller.addView(box);

        AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("欢迎使用 文件夹相机")
                .setView(scroller)
                .setCancelable(false)
                .setNegativeButton("稍后再说", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        store.setOnboarded();
                    }
                })
                .setPositiveButton("去开启权限 →", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        store.setOnboarded();
                        requestAllFilesAccess();
                    }
                })
                .create();
        dlg.show();
    }

    /** 跳到系统的「所有文件访问」设置页。 */
    private void requestAllFilesAccess() {
        if (Build.VERSION.SDK_INT < 30) return;
        try {
            Intent i = new Intent(
                    android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
            i.setData(android.net.Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(
                        android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
            } catch (Exception e2) {
                Ui.toast(this, "请到 系统设置 → 应用 → 文件夹相机 里开启「所有文件访问」");
            }
        }
    }

    // ------------------------------------------------------------ UI

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        Ui.padding(root, this, 0, 0, 0, 0);

        // 头部
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.VERTICAL);
        Ui.padding(head, this, 20, 14, 20, 10);

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = Ui.bold(Ui.text(this, "文件夹相机", 24, Ui.INK));
        titleRow.addView(title, Ui.lpw(1f, ViewGroup.LayoutParams.WRAP_CONTENT));

        // 保存位置做成看得见的开关，不用钻到设置里去改
        rootChip = Ui.text(this, "", 12, Ui.ACCENT);
        rootChip.setBackground(Ui.roundStroke(0x142F6BFF, Ui.ACCENT, 1, 20, this));
        Ui.padding(rootChip, this, 12, 7, 12, 7);
        rootChip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askRoot();
            }
        });
        titleRow.addView(rootChip);
        head.addView(titleRow);

        TextView sub = Ui.text(this, "拍进指定文件夹，按文件夹找素材", 12.5f, Ui.INK3);
        head.addView(sub);
        Ui.margin(sub, this, 0, 5, 0, 0);
        root.addView(head);

        // 权限提示条（只在没授权时出现）
        hintView = Ui.text(this, "", 11.5f, Ui.WARN_FG);
        hintView.setBackground(Ui.round(Ui.WARN_BG, 10, this));
        Ui.padding(hintView, this, 12, 9, 12, 9);
        hintView.setVisibility(View.GONE);
        hintView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestReadPermission();
            }
        });
        root.addView(hintView);
        Ui.margin(hintView, this, 16, 2, 16, 6);

        // 列表 + 空态
        FrameLayout mid = new FrameLayout(this);
        LinearLayout.LayoutParams midLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        root.addView(mid, midLp);

        list = new ListView(this);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setSelector(new android.graphics.drawable.ColorDrawable(0x00000000));
        list.setCacheColorHint(0);
        list.setClipToPadding(false);
        Ui.padding(list, this, 0, 0, 0, 8);
        adapter = new RowAdapter();
        list.setAdapter(adapter);
        mid.addView(list, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        emptyView = buildEmpty();
        mid.addView(emptyView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        emptyView.setVisibility(View.GONE);

        // 底部：新建
        LinearLayout foot = new LinearLayout(this);
        foot.setOrientation(LinearLayout.VERTICAL);
        Ui.padding(foot, this, 16, 8, 16, 12);

        TextView add = Ui.bold(Ui.text(this, "＋  新建文件夹", 15.5f, 0xFFFFFFFF));
        add.setGravity(Gravity.CENTER);
        add.setBackground(Ui.round(Ui.ACCENT, 14, this));
        add.setClickable(true);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askNewFolder();
            }
        });
        foot.addView(add, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dpi(this, 50)));

        TextView settings = Ui.text(this, "设置与关于", 12, Ui.INK3);
        settings.setGravity(Gravity.CENTER);
        settings.setPadding(0, Ui.dpi(this, 11), 0, 0);
        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSettings();
            }
        });
        foot.addView(settings);
        root.addView(foot);

        Ui.applyInsets(root, true, true);
        return root;
    }

    private View buildEmpty() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setGravity(Gravity.CENTER);
        v.setPadding(Ui.dpi(this, 40), 0, Ui.dpi(this, 40), Ui.dpi(this, 40));
        TextView t = Ui.bold(Ui.text(this, "还没有文件夹", 17, Ui.INK));
        t.setGravity(Gravity.CENTER);
        v.addView(t);
        TextView s = Ui.text(this, "先建一个，比如「产品A-白底」\n之后每次拍照都会直接落进这个文件夹", 13, Ui.INK3);
        s.setGravity(Gravity.CENTER);
        s.setLineSpacing(Ui.dp(this, 5), 1f);
        v.addView(s);
        Ui.margin(s, this, 0, 10, 0, 0);
        return v;
    }

    // ------------------------------------------------------------ 数据

    @Override
    protected void onResume() {
        super.onResume();
        if (!launchedDirectly) refresh();
        launchedDirectly = false;
    }

    private void refresh() {
        rows.clear();
        String root = store.root();
        Map<String, List<Media.Shot>> snap = Media.snapshot(this, root);

        // 顺手把「在外部创建/拷进来的文件夹」补进清单
        Set<String> known = new LinkedHashSet<>(store.folders());
        Set<String> discovered = new LinkedHashSet<>();
        for (String rel : snap.keySet()) {
            if (!rel.startsWith(root + "/")) continue;
            String tail = rel.substring(root.length() + 1);
            if (tail.endsWith("/")) tail = tail.substring(0, tail.length() - 1);
            int slash = tail.indexOf('/');
            if (slash >= 0) tail = tail.substring(0, slash); // 只认一层
            if (tail.length() > 0 && !known.contains(tail)) discovered.add(tail);
        }
        for (String d : discovered) store.add(d);

        List<String> names = store.folders();
        for (String n : names) {
            Row r = new Row();
            r.name = n;
            r.rel = FolderStore.relPath(root, n);
            List<Media.Shot> shots = snap.get(r.rel);
            r.count = shots == null ? 0 : shots.size();
            if (shots != null && !shots.isEmpty()) r.cover = shots.get(shots.size() - 1);
            rows.add(r);
        }

        adapter.notifyDataSetChanged();
        boolean none = rows.isEmpty();
        emptyView.setVisibility(none ? View.VISIBLE : View.GONE);
        list.setVisibility(none ? View.GONE : View.VISIBLE);

        boolean granted = hasReadPermission();
        if (!granted) {
            hintView.setText("只显示本 App 拍摄的素材 · 点此允许读取相册，可看到外部拷入的照片");
            hintView.setVisibility(View.VISIBLE);
        } else {
            hintView.setVisibility(View.GONE);
        }

        if (rootChip != null) {
            rootChip.setText((FolderStore.ROOT_DCIM.equals(root) ? "存到 DCIM ▾" : "存到 Pictures ▾"));
        }
    }

    // ------------------------------------------------------------ 列表适配器

    private final class RowAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return rows.size();
        }

        @Override
        public Object getItem(int i) {
            return rows.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View reuse, ViewGroup parent) {
            Holder h;
            if (reuse == null) {
                LinearLayout wrap = new LinearLayout(MainActivity.this);
                wrap.setOrientation(LinearLayout.VERTICAL);
                wrap.setBackgroundColor(Ui.BG);

                LinearLayout line = new LinearLayout(MainActivity.this);
                line.setOrientation(LinearLayout.HORIZONTAL);
                line.setGravity(Gravity.CENTER_VERTICAL);
                Ui.padding(line, MainActivity.this, 16, 12, 16, 12);
                wrap.addView(line);

                ImageView cover = new ImageView(MainActivity.this);
                cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
                cover.setBackground(Ui.round(Ui.SURFACE, 12, MainActivity.this));
                cover.setClipToOutline(true);
                cover.setOutlineProvider(new android.view.ViewOutlineProvider() {
                    @Override
                    public void getOutline(View v, android.graphics.Outline o) {
                        o.setRoundRect(0, 0, v.getWidth(), v.getHeight(),
                                Ui.dp(MainActivity.this, 12));
                    }
                });
                line.addView(cover, Ui.lp(Ui.dpi(MainActivity.this, 54), Ui.dpi(MainActivity.this, 54)));

                LinearLayout texts = new LinearLayout(MainActivity.this);
                texts.setOrientation(LinearLayout.VERTICAL);
                line.addView(texts, Ui.lpw(1f, ViewGroup.LayoutParams.WRAP_CONTENT));
                Ui.margin(texts, MainActivity.this, 14, 0, 8, 0);

                TextView name = Ui.bold(Ui.text(MainActivity.this, "", 16, Ui.INK));
                texts.addView(name);
                TextView path = Ui.text(MainActivity.this, "", 10.5f, Ui.INK3);
                path.setSingleLine(true);
                path.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
                texts.addView(path);
                Ui.margin(path, MainActivity.this, 0, 4, 0, 0);

                TextView count = Ui.text(MainActivity.this, "", 12, Ui.INK2);
                count.setGravity(Gravity.CENTER_VERTICAL);
                count.setMinWidth(Ui.dpi(MainActivity.this, 34));
                line.addView(count);

                View sep = new View(MainActivity.this);
                sep.setBackgroundColor(Ui.LINE);
                wrap.addView(sep, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, 1));

                h = new Holder();
                h.cover = cover;
                h.name = name;
                h.path = path;
                h.count = count;
                wrap.setTag(h);
                reuse = wrap;
            } else {
                h = (Holder) reuse.getTag();
            }

            final Row r = rows.get(i);
            h.name.setText(r.name);
            h.path.setText(FolderStore.displayPath(store.root(), r.name));
            h.count.setText(r.count > 0 ? r.count + " 张" : "空");
            h.count.setTextColor(r.count > 0 ? Ui.INK2 : Ui.INK3);
            if (r.cover != null) {
                Thumbs.into(h.cover, r.cover, Ui.dpi(MainActivity.this, 62));
            } else {
                h.cover.setTag(null);
                h.cover.setImageDrawable(null);
            }

            reuse.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openShoot(r.name);
                }
            });
            reuse.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    folderMenu(r);
                    return true;
                }
            });
            return reuse;
        }
    }

    private static final class Holder {
        ImageView cover;
        TextView name;
        TextView path;
        TextView count;
    }

    // ------------------------------------------------------------ 动作

    private void openShoot(String folder) {
        store.setLast(folder);
        Intent i = new Intent(this, ShootActivity.class);
        i.putExtra(ShootActivity.EXTRA_FOLDER, folder);
        startActivity(i);
    }

    private void askNewFolder() {
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setHint("例如：产品A-白底");
        input.setTextSize(15);
        input.setSingleLine(true);
        FrameLayout box = new FrameLayout(this);
        Ui.padding(box, this, 8, 0, 8, 0);
        box.addView(input);
        input.requestFocus();

        final AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("新建文件夹")
                .setView(box)
                .setNegativeButton("取消", null)
                .setPositiveButton("创建并开始拍", null)
                .create();
        dlg.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface d) {
                dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String name = FolderStore.sanitize(input.getText().toString());
                        if (name == null) {
                            input.setError("文件夹名不能为空");
                            return;
                        }
                        String err = store.add(name);
                        if (err != null) {
                            input.setError(err);
                            return;
                        }
                        dlg.dismiss();
                        Ui.toast(MainActivity.this, "已创建：" + name);
                        refresh();
                        openShoot(name);
                    }
                });
            }
        });
        dlg.getWindow().setSoftInputMode(
                android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        dlg.show();
    }

    private void folderMenu(final Row r) {
        String[] items = {
                "进入拍摄",
                "复制文件夹路径",
                r.count > 0 ? "打包分享（zip）" : "还没有照片",
                "重命名文件夹",
                "删除文件夹（不动里面的照片）",
        };
        new AlertDialog.Builder(this)
                .setTitle(r.name + "  ·  " + r.count + " 张")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        switch (which) {
                            case 0:
                                openShoot(r.name);
                                break;
                            case 1:
                                copyPath(r.name);
                                break;
                            case 2:
                                if (r.count > 0) packFolder(r.name);
                                break;
                            case 3:
                                askRename(r);
                                break;
                            case 4:
                                askDelete(r);
                                break;
                            default:
                                break;
                        }
                    }
                })
                .show();
    }

    /** 长按文件夹 -> 打包分享整个文件夹。 */
    private void packFolder(final String name) {
        final String rel = FolderStore.relPath(store.root(), name);
        final List<Media.Shot> list = Media.listIn(this, store.root(), rel);
        if (list.isEmpty()) {
            Ui.toast(this, "这个文件夹还没有照片");
            return;
        }
        final AlertDialog progress = new AlertDialog.Builder(this)
                .setTitle("正在打包 " + list.size() + " 张…")
                .setCancelable(false)
                .create();
        progress.show();

        new Thread(new Runnable() {
            @Override
            public void run() {
                final File zip;
                try {
                    zip = Zip.pack(MainActivity.this, Zip.defaultName(name, list.size()), list, null);
                } catch (Throwable t) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            progress.dismiss();
                            Ui.toast(MainActivity.this, "打包失败");
                        }
                    });
                    return;
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        progress.dismiss();
                        if (zip == null || !zip.exists() || zip.length() == 0) {
                            Ui.toast(MainActivity.this, "打包失败");
                            return;
                        }
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType("application/zip");
                        i.putExtra(Intent.EXTRA_STREAM, LocalFileProvider.shareUri(zip));
                        i.putExtra(Intent.EXTRA_SUBJECT, zip.getName());
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        try {
                            startActivity(Intent.createChooser(i, "分享压缩包 "
                                    + zip.getName() + "（" + Media.humanSize(zip.length()) + "）"));
                        } catch (Exception e) {
                            Ui.toast(MainActivity.this, "没有可以接收压缩包的 App");
                        }
                    }
                });
            }
        }).start();
    }

    private void copyPath(String folder) {
        String path = FolderStore.displayPath(store.root(), folder);
        android.content.ClipboardManager cm =
                (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(android.content.ClipData.newPlainText("path", path));
        Ui.toast(this, "已复制：" + path);
    }

    private void askRename(final Row r) {
        final EditText input = new EditText(this);
        input.setText(r.name);
        input.setSingleLine(true);
        input.setTextSize(15);
        input.setSelection(r.name.length());
        FrameLayout box = new FrameLayout(this);
        Ui.padding(box, this, 8, 0, 8, 0);
        box.addView(input);

        final AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("重命名文件夹")
                .setMessage("只是改名字，不动照片文件。已拍的照片仍在原路径。")
                .setView(box)
                .setNegativeButton("取消", null)
                .setPositiveButton("确定", null)
                .create();
        dlg.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface d) {
                dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String err = store.rename(r.name, input.getText().toString());
                        if (err != null) {
                            input.setError(err);
                            return;
                        }
                        dlg.dismiss();
                        refresh();
                    }
                });
            }
        });
        dlg.show();
    }

    private void askDelete(final Row r) {
        String msg = r.count > 0
                ? "「" + r.name + "」里还有 " + r.count + " 张照片。\n删除只是把这个文件夹从列表里移走，照片文件不会删。"
                : "确定把「" + r.name + "」从列表里移走吗？";
        new AlertDialog.Builder(this)
                .setTitle("删除文件夹")
                .setMessage(msg)
                .setNegativeButton("取消", null)
                .setPositiveButton("移走", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        store.remove(r.name);
                        refresh();
                    }
                })
                .show();
    }

    private void openSettings() {
        boolean allFiles = Media.hasAllFilesAccess(this);
        final String[] options = {
                "保存位置：" + store.rootLabel(),
                "所有文件访问：" + (allFiles ? "已开启 ✓" : "未开启（拍照会失败）"),
                "读取相册权限：" + (hasReadPermission() ? "已允许 ✓" : "未允许"),
                "重新看一遍新手引导",
                "关于",
        };
        new AlertDialog.Builder(this)
                .setTitle("设置")
                .setItems(options, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        switch (which) {
                            case 0:
                                askRoot();
                                break;
                            case 1:
                                requestAllFilesAccess();
                                break;
                            case 2:
                                requestReadPermission();
                                break;
                            case 3:
                                store.setOnboarded(false);
                                showOnboarding();
                                break;
                            default:
                                about();
                                break;
                        }
                    }
                })
                .show();
    }

    private void askRoot() {
        final String[] opts = {
                "Pictures/FolderCam　（推荐，和相机照片分开）",
                "DCIM/FolderCam　（和相机照片放一起）",
        };
        int cur = FolderStore.ROOT_DCIM.equals(store.root()) ? 1 : 0;
        new AlertDialog.Builder(this)
                .setTitle("照片保存到哪")
                .setSingleChoiceItems(opts, cur, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        String root = which == 1 ? FolderStore.ROOT_DCIM : FolderStore.ROOT_PICTURES;
                        String old = store.root();
                        if (root.equals(old)) {
                            d.dismiss();
                            return;
                        }
                        store.setRoot(root);
                        store.setLast(null);
                        d.dismiss();
                        Thumbs.clear();
                        refresh();
                        Ui.toast(MainActivity.this,
                                "以后的照片存到 " + root + "；老照片还在原路径");
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void about() {
        new AlertDialog.Builder(this)
                .setTitle("关于 文件夹相机")
                .setMessage("拍照完全交给本机相机 App（ACTION_IMAGE_CAPTURE），"
                        + "所以 HDR、夜景、人像、滤镜、变焦这些原生能力一个都不少。\n\n"
                        + "本 App 只做一件事：把相机拍出来的原图，直接放进你指定的文件夹里。\n\n"
                        + "照片真实路径：\n" + store.root() + "/<文件夹名>/\n\n"
                        + "文件夹清单：" + store.folders().size() + " 个")
                .setPositiveButton("好", null)
                .show();
    }

    // ------------------------------------------------------------ 权限

    private boolean hasReadPermission() {
        String p = Build.VERSION.SDK_INT >= 33
                ? "android.permission.READ_MEDIA_IMAGES"
                : "android.permission.READ_EXTERNAL_STORAGE";
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private void maybeAskPermission() {
        if (Build.VERSION.SDK_INT <= 29) {
            // Android 10 及以下：往公共目录写照片必须拿到这个权限，缺了拍照会直接失败，
            // 所以这里一定要问，不能像 READ 那样可选。
            if (checkSelfPermission(Media.legacyWritePermission())
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Media.legacyWritePermission()}, REQ_PERM);
            }
            return;
        }
        if (hasReadPermission()) return;
        // Android 11+：只是看不到「外部拷进来」的照片，核心功能不受影响，所以不拦着用户
        requestReadPermission();
    }

    private void requestReadPermission() {
        if (Build.VERSION.SDK_INT <= 29) {
            requestPermissions(new String[]{Media.legacyWritePermission()}, REQ_PERM);
            return;
        }
        String p = Build.VERSION.SDK_INT >= 33
                ? "android.permission.READ_MEDIA_IMAGES"
                : "android.permission.READ_EXTERNAL_STORAGE";
        requestPermissions(new String[]{p}, REQ_PERM);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == REQ_PERM) {
            Thumbs.clear();
            refresh();
        }
    }
}
