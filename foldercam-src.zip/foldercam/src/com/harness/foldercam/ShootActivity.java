package com.harness.foldercam;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** 拍摄页：一个文件夹 + 大快门 + 这个文件夹里的素材墙。 */
public class ShootActivity extends Activity implements CameraLauncher.Sink {

    // 排序方式
    private static final int SORT_TIME_ASC = 0;   // 拍摄顺序（默认，最常用）
    private static final int SORT_TIME_DESC = 1;
    private static final int SORT_SIZE_DESC = 2;
    private static final int SORT_NAME = 3;

    private int sortMode = SORT_TIME_ASC;

    static final String EXTRA_FOLDER = "folder";

    private FolderStore store;
    private String folder;
    private String rel;

    private CameraLauncher launcher;
    private final List<Media.Shot> shots = new ArrayList<>();
    /** 本文件夹里已存在的文件名（小写），用来保证新照片不重名。 */
    private final Set<String> takenNames = new HashSet<>();
    private GridAdapter adapter;

    private TextView titleView;
    private TextView pathView;
    private TextView banner;
    private View emptyView;
    private GridView grid;
    private View normalBar;
    private View selectBar;
    private TextView selectCount;

    private boolean selecting;
    private final Set<Long> selected = new HashSet<>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        // 我们用 file:// 作为相机的 EXTRA_OUTPUT（MIUI 相机只认这种形式），
        // 这会被 StrictMode 判定为 FileUriExposure 并抛异常，所以要放行。
        // 只影响本 App 自己的策略检查，不改变系统实际权限。
        try {
            android.os.StrictMode.setVmPolicy(
                    new android.os.StrictMode.VmPolicy.Builder().build());
        } catch (Throwable ignored) {
        }
        Ui.edgeToEdge(getWindow());
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        store = new FolderStore(this);
        folder = getIntent().getStringExtra(EXTRA_FOLDER);
        if (folder == null) {
            finish();
            return;
        }
        rel = FolderStore.relPath(store.root(), folder);
        launcher = new CameraLauncher(this, this);
        setContentView(buildUi());
        store.setLast(folder);
    }

    // ------------------------------------------------------------ UI

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);

        root.addView(buildTopBar());

        banner = Ui.text(this, "", 11.5f, Ui.WARN_FG);
        banner.setBackground(Ui.round(Ui.WARN_BG, 10, this));
        Ui.padding(banner, this, 12, 9, 12, 9);
        banner.setVisibility(View.GONE);
        banner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!Media.hasAllFilesAccess(ShootActivity.this)) {
                    requestAllFilesAccess();
                } else {
                    exportPrivate();
                }
            }
        });
        root.addView(banner);
        Ui.margin(banner, this, 14, 4, 14, 4);

        FrameLayout mid = new FrameLayout(this);
        root.addView(mid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        grid = new GridView(this);
        grid.setNumColumns(3);
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setHorizontalSpacing(Ui.dpi(this, 3));
        grid.setVerticalSpacing(Ui.dpi(this, 3));
        grid.setPadding(Ui.dpi(this, 3), Ui.dpi(this, 3), Ui.dpi(this, 3), Ui.dpi(this, 3));
        grid.setClipToPadding(false);
        grid.setSelector(new android.graphics.drawable.ColorDrawable(0x00000000));
        grid.setCacheColorHint(0);
        adapter = new GridAdapter();
        grid.setAdapter(adapter);
        mid.addView(grid, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        emptyView = buildEmpty();
        mid.addView(emptyView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        emptyView.setVisibility(View.GONE);

        root.addView(buildBottom());

        Ui.applyInsets(root, true, true);
        return root;
    }

    private View buildTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        Ui.padding(bar, this, 6, 6, 6, 6);

        TextView back = Ui.action(this, "←", Ui.INK);
        back.setTextSize(22);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        bar.addView(back, Ui.lp(Ui.dpi(this, 46), Ui.dpi(this, 46)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        bar.addView(texts, Ui.lpw(1f, ViewGroup.LayoutParams.WRAP_CONTENT));
        Ui.margin(texts, this, 2, 0, 0, 0);

        titleView = Ui.bold(Ui.text(this, folder, 18, Ui.INK));
        titleView.setSingleLine(true);
        titleView.setEllipsize(TextUtils.TruncateAt.END);
        texts.addView(titleView);

        pathView = Ui.text(this, FolderStore.displayPath(store.root(), folder), 10.5f, Ui.INK3);
        pathView.setSingleLine(true);
        pathView.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        pathView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                copyPath();
            }
        });
        texts.addView(pathView);
        Ui.margin(pathView, this, 0, 3, 0, 0);

        TextView more = Ui.action(this, "⋯", Ui.INK);
        more.setTextSize(20);
        more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                folderMenu();
            }
        });
        bar.addView(more, Ui.lp(Ui.dpi(this, 46), Ui.dpi(this, 46)));
        return bar;
    }

    private View buildEmpty() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setGravity(Gravity.CENTER);
        v.setPadding(Ui.dpi(this, 40), 0, Ui.dpi(this, 40), Ui.dpi(this, 60));
        TextView t = Ui.bold(Ui.text(this, "这个文件夹还是空的", 17, Ui.INK));
        t.setGravity(Gravity.CENTER);
        v.addView(t);
        TextView s = Ui.text(this, "按下面的大圆点，会用你的本机相机拍\n拍完原图直接落进这个文件夹", 13, Ui.INK3);
        s.setGravity(Gravity.CENTER);
        s.setLineSpacing(Ui.dp(this, 5), 1f);
        v.addView(s);
        Ui.margin(s, this, 0, 10, 0, 0);
        return v;
    }

    private View buildBottom() {
        FrameLayout holder = new FrameLayout(this);

        // ---- 普通模式：选择 / 快门 / 换文件夹
        LinearLayout normal = new LinearLayout(this);
        normal.setOrientation(LinearLayout.HORIZONTAL);
        normal.setGravity(Gravity.CENTER_VERTICAL);
        Ui.padding(normal, this, 14, 8, 14, 14);

        TextView sel = Ui.action(this, "选择", Ui.INK);
        sel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSelecting(true);
            }
        });
        normal.addView(sel, Ui.lpw(1f, Ui.dpi(this, 48)));

        Ui.Shutter shutter = new Ui.Shutter(this);
        shutter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                takePhoto();
            }
        });
        LinearLayout.LayoutParams shLp =
                new LinearLayout.LayoutParams(Ui.dpi(this, 74), Ui.dpi(this, 74));
        normal.addView(shutter, shLp);

        TextView swap = Ui.action(this, "换文件夹", Ui.INK);
        swap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchFolder();
            }
        });
        normal.addView(swap, Ui.lpw(1f, Ui.dpi(this, 48)));
        normalBar = normal;
        holder.addView(normal, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ---- 多选模式：取消 / 分享 / 打包 / 移动 / 删除
        LinearLayout selWrap = new LinearLayout(this);
        selWrap.setOrientation(LinearLayout.VERTICAL);

        // 第一行：已选数量 + 明确的「取消」出口
        LinearLayout selHead = new LinearLayout(this);
        selHead.setOrientation(LinearLayout.HORIZONTAL);
        selHead.setGravity(Gravity.CENTER_VERTICAL);
        Ui.padding(selHead, this, 10, 8, 10, 0);

        selectCount = Ui.text(this, "", 13, Ui.INK2);
        selHead.addView(selectCount, Ui.lpw(1f, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView all = Ui.action(this, "全选", Ui.INK2);
        all.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectAll();
            }
        });
        selHead.addView(all);

        // 【必须有】不然误触进多选后就出不来了，只能杀 App
        TextView cancel = Ui.action(this, "取消", Ui.INK);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSelecting(false);
            }
        });
        selHead.addView(cancel);
        selWrap.addView(selHead);

        LinearLayout selBar = new LinearLayout(this);
        selBar.setOrientation(LinearLayout.HORIZONTAL);
        selBar.setGravity(Gravity.CENTER_VERTICAL);
        Ui.padding(selBar, this, 6, 0, 6, 14);

        TextView share = Ui.action(this, "分享", Ui.INK);
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doShare();
            }
        });
        selBar.addView(share, Ui.lpw(1f, Ui.dpi(this, 48)));

        TextView zip = Ui.action(this, "打包", Ui.ACCENT);
        zip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doPack();
            }
        });
        selBar.addView(zip, Ui.lpw(1f, Ui.dpi(this, 48)));

        TextView move = Ui.action(this, "移动", Ui.ACCENT);
        move.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doMove();
            }
        });
        selBar.addView(move, Ui.lpw(1f, Ui.dpi(this, 48)));

        TextView del = Ui.action(this, "删除", Ui.DANGER);
        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doDelete();
            }
        });
        selBar.addView(del, Ui.lpw(1f, Ui.dpi(this, 48)));

        selWrap.addView(selBar);
        selectBar = selWrap;
        selectBar.setVisibility(View.GONE);
        // 注意：加给 holder 的必须是 selWrap（整块），不是里面那一行 selBar。
        // 一个 View 只能有一个父容器，重复 addView 会抛 IllegalStateException。
        holder.addView(selWrap, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return holder;
    }

    // ------------------------------------------------------------ 数据

    @Override
    protected void onResume() {
        super.onResume();
        reload();
    }

    private void reload() {
        shots.clear();
        takenNames.clear();
        shots.addAll(Media.listIn(this, store.root(), rel));
        applySort();
        for (Media.Shot s : shots) {
            if (s.name != null) takenNames.add(s.name.toLowerCase(Locale.US));
        }
        adapter.notifyDataSetChanged();

        boolean none = shots.isEmpty();
        emptyView.setVisibility(none ? View.VISIBLE : View.GONE);
        grid.setVisibility(none ? View.GONE : View.VISIBLE);

        int priv = 0;
        for (Media.Shot s : shots) if (s.isPrivate()) priv++;
        if (priv > 0) {
            banner.setText("有 " + priv + " 张没写进相册目录，暂存在 App 私有空间 · 点此导出到 "
                    + store.root() + "/" + folder + "/");
            banner.setVisibility(View.VISIBLE);
        } else if (!Media.hasAllFilesAccess(this)) {
            // 没这个权限时，相机不会按我们给的路径写（MIUI 只认 file:// 输出），
            // 所以必须提醒用户去开，否则拍照会一直失败。
            banner.setText("还差一步：需要在系统设置里给本 App 开「所有文件访问」，"
                    + "否则相机不会把照片存进指定文件夹 · 点此去开启");
            banner.setVisibility(View.VISIBLE);
        } else {
            banner.setVisibility(View.GONE);
        }

        titleView.setText(selecting ? ("已选 " + selected.size() + " 张") : folder);
        if (!selecting) {
            selected.clear();
            selectCountUpdate();
        }
    }

    // ------------------------------------------------------------ 网格

    private static final class SquareCell extends FrameLayout {
        SquareCell(Context c) {
            super(c);
        }

        @Override
        protected void onMeasure(int w, int h) {
            super.onMeasure(w, w);
            setMeasuredDimension(getMeasuredWidth(), getMeasuredWidth());
        }
    }

    private final class GridAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return shots.size();
        }

        @Override
        public Object getItem(int i) {
            return shots.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View reuse, ViewGroup parent) {
            Cell h;
            if (reuse == null) {
                SquareCell cell = new SquareCell(ShootActivity.this);
                ImageView img = new ImageView(ShootActivity.this);
                img.setScaleType(ImageView.ScaleType.CENTER_CROP);
                img.setBackgroundColor(Ui.SURFACE);
                cell.addView(img, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                img.setClipToOutline(true);
                img.setOutlineProvider(new android.view.ViewOutlineProvider() {
                    @Override
                    public void getOutline(View v, android.graphics.Outline o) {
                        o.setRoundRect(0, 0, v.getWidth(), v.getHeight(),
                                Ui.dp(ShootActivity.this, 8));
                    }
                });

                final View dim = new View(ShootActivity.this);
                dim.setBackgroundColor(0x33000000);
                dim.setVisibility(View.GONE);
                cell.addView(dim, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

                TextView check = Ui.bold(Ui.text(ShootActivity.this, "✓", 13, 0xFFFFFFFF));
                check.setGravity(Gravity.CENTER);
                check.setBackground(Ui.round(Ui.ACCENT, 20, ShootActivity.this));
                check.setVisibility(View.GONE);
                FrameLayout.LayoutParams clp =
                        new FrameLayout.LayoutParams(Ui.dpi(ShootActivity.this, 22),
                                Ui.dpi(ShootActivity.this, 22));
                clp.gravity = Gravity.TOP | Gravity.END;
                clp.topMargin = Ui.dpi(ShootActivity.this, 6);
                clp.rightMargin = Ui.dpi(ShootActivity.this, 6);
                cell.addView(check, clp);

                h = new Cell();
                h.img = img;
                h.dim = dim;
                h.check = check;
                cell.setTag(h);
                reuse = cell;
            } else {
                h = (Cell) reuse.getTag();
            }

            final Media.Shot s = shots.get(i);
            Thumbs.into(h.img, s, Ui.dpi(ShootActivity.this, 320));

            boolean on = s.id != 0 ? selected.contains(s.id)
                    : selected.contains(-(long) (s.name == null ? 0 : s.name.hashCode()));
            h.dim.setVisibility(selecting && on ? View.VISIBLE : View.GONE);
            h.check.setVisibility(selecting && on ? View.VISIBLE : View.GONE);

            reuse.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (selecting) toggle(s);
                    else openViewer(s);
                }
            });
            reuse.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    if (!selecting) setSelecting(true);
                    toggle(s);
                    return true;
                }
            });
            return reuse;
        }
    }

    private static final class Cell {
        ImageView img;
        View dim;
        TextView check;
    }

    private long keyOf(Media.Shot s) {
        return s.id != 0 ? s.id : -(long) (s.name == null ? 0 : s.name.hashCode());
    }

    private void toggle(Media.Shot s) {
        long k = keyOf(s);
        if (!selected.remove(k)) selected.add(k);
        adapter.notifyDataSetChanged();
        titleView.setText("已选 " + selected.size() + " 张");
        selectCountUpdate();
    }

    private void selectCountUpdate() {
        if (selectBar != null) {
            selectBar.setVisibility(selecting ? View.VISIBLE : View.GONE);
            normalBar.setVisibility(selecting ? View.GONE : View.VISIBLE);
        }
        if (selectCount != null) {
            int n = selected.size();
            int total = shots.size();
            if (n == 0) {
                selectCount.setText("点照片选择 · 本文件夹共 " + total + " 张");
            } else {
                selectCount.setText("已选 " + n + " / " + total + " 张 · "
                        + Media.humanSize(selectedBytes()));
            }
        }
    }

    /** 选中照片的总字节数，选之前先知道包里大概多大。 */
    private long selectedBytes() {
        long n = 0;
        for (Media.Shot s : selectedShots()) n += s.size;
        return n;
    }

    /** 按当前排序方式重排（默认是拍摄顺序，不受系统相册时间线影响）。 */
    private void applySort() {
        Comparator<Media.Shot> c;
        switch (sortMode) {
            case SORT_TIME_DESC:
                c = new Comparator<Media.Shot>() {
                    @Override
                    public int compare(Media.Shot a, Media.Shot b) {
                        int r = Long.compare(b.dateAdded, a.dateAdded);
                        return r != 0 ? r : Long.compare(b.id, a.id);
                    }
                };
                break;
            case SORT_SIZE_DESC:
                c = new Comparator<Media.Shot>() {
                    @Override
                    public int compare(Media.Shot a, Media.Shot b) {
                        return Long.compare(b.size, a.size);
                    }
                };
                break;
            case SORT_NAME:
                c = new Comparator<Media.Shot>() {
                    @Override
                    public int compare(Media.Shot a, Media.Shot b) {
                        String x = a.name == null ? "" : a.name;
                        String y = b.name == null ? "" : b.name;
                        return x.compareToIgnoreCase(y);
                    }
                };
                break;
            case SORT_TIME_ASC:
            default:
                c = new Comparator<Media.Shot>() {
                    @Override
                    public int compare(Media.Shot a, Media.Shot b) {
                        int r = Long.compare(a.dateAdded, b.dateAdded);
                        return r != 0 ? r : Long.compare(a.id, b.id);
                    }
                };
                break;
        }
        Collections.sort(shots, c);
    }

    private String sortLabel() {
        switch (sortMode) {
            case SORT_TIME_DESC:
                return "最新在前";
            case SORT_SIZE_DESC:
                return "文件大的在前";
            case SORT_NAME:
                return "按文件名";
            case SORT_TIME_ASC:
            default:
                return "拍摄顺序";
        }
    }

    private void askSort() {
        final String[] items = {"拍摄顺序（推荐）", "最新在前", "文件大的在前", "按文件名"};
        new AlertDialog.Builder(this)
                .setTitle("排序方式")
                .setSingleChoiceItems(items, sortMode, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        sortMode = which;
                        d.dismiss();
                        applySort();
                        adapter.notifyDataSetChanged();
                        Ui.toast(ShootActivity.this, "已按「" + sortLabel() + "」排列");
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void setSelecting(boolean on) {
        selecting = on;
        if (!on) {
            selected.clear();
            titleView.setText(folder);
        } else {
            titleView.setText("已选 " + selected.size() + " 张");
        }
        selectCountUpdate();
        adapter.notifyDataSetChanged();
    }

    private List<Media.Shot> selectedShots() {
        List<Media.Shot> out = new ArrayList<>();
        for (Media.Shot s : shots) {
            if (selected.contains(keyOf(s))) out.add(s);
        }
        return out;
    }

    // ------------------------------------------------------------ 拍照

    private void takePhoto() {
        if (launcher.busy()) return;
        String name;
        int seq = 0;
        do {
            name = FolderStore.photoName(seq++);
        } while (takenNames.contains(name.toLowerCase(Locale.US)) && seq < 100);
        launcher.shoot(rel, name);
    }

    @Override
    public void onCaptured(Media.Shot shot, String relPath) {
        if (shot.name != null) takenNames.add(shot.name.toLowerCase(Locale.US));
        // 刚拍的照片可能刚被写进磁盘，MediaStore 索引是异步的，
        // 所以这里先立即刷新，再隔一会儿重查几次，确保新照片一定出现在墙上。
        reload();
        if (shot.pending || shot.isPublicFile()) {
            handler.removeCallbacksAndMessages(null);
            for (int delay : new int[]{700, 1800, 3500}) {
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!isFinishing()) reload();
                    }
                }, delay);
            }
        }
        Ui.toast(this, "已存到 " + shot.name);
    }

    private final android.os.Handler handler = new android.os.Handler(android.os.Looper.getMainLooper());

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
    }

    @Override
    public void onCancelled() {
        // 用户取消了拍摄，什么都不用做（占位文件已经清掉了）
    }

    @Override
    public void onFailed(String message) {
        new AlertDialog.Builder(this)
                .setTitle("没拍成")
                .setMessage(message + "\n\n可以试试：换个文件夹再拍一次，或者检查系统相机是否被停用。")
                .setPositiveButton("好", null)
                .show();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        launcher.onActivityResult(req, res, data);
    }

    // ------------------------------------------------------------ 文件夹操作

    private void copyPath() {
        String path = FolderStore.displayPath(store.root(), folder);
        android.content.ClipboardManager cm =
                (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(android.content.ClipData.newPlainText("path", path));
        Ui.toast(this, "已复制：" + path);
    }

    private void folderMenu() {
        final String[] items = {
                "复制这个文件夹的路径",
                "全选本文件夹素材",
                "排序方式（当前：" + sortLabel() + "）",
                "换一个文件夹拍",
                "重命名这个文件夹",
                "把这个文件夹打包分享",
        };
        new AlertDialog.Builder(this)
                .setTitle(folder + "　·　" + shots.size() + " 张")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        switch (which) {
                            case 0:
                                copyPath();
                                break;
                            case 1:
                                selectAll();
                                break;
                            case 2:
                                askSort();
                                break;
                            case 3:
                                switchFolder();
                                break;
                            case 4:
                                renameFolder();
                                break;
                            case 5:
                                packAll();
                                break;
                            default:
                                break;
                        }
                    }
                })
                .show();
    }

    /** 整包分享：把本文件夹全部照片打成 zip。 */
    private void packAll() {
        if (shots.isEmpty()) {
            Ui.toast(this, "这个文件夹还没有照片");
            return;
        }
        selecting = true;
        selected.clear();
        for (Media.Shot s : shots) selected.add(keyOf(s));
        adapter.notifyDataSetChanged();
        doPack();
    }

    private void selectAll() {
        selecting = true;
        selected.clear();
        for (Media.Shot s : shots) selected.add(keyOf(s));
        titleView.setText("已选 " + selected.size() + " 张");
        selectCountUpdate();
        adapter.notifyDataSetChanged();
    }

    private void renameFolder() {
        final EditText input = new EditText(this);
        input.setText(folder);
        input.setSingleLine(true);
        input.setTextSize(15);
        input.setSelection(folder.length());
        FrameLayout box = new FrameLayout(this);
        Ui.padding(box, this, 8, 0, 8, 0);
        box.addView(input);

        final AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("重命名文件夹")
                .setMessage("只改文件夹的名字，已经在里面的照片文件不会跟着改路径。")
                .setView(box)
                .setNegativeButton("取消", null)
                .setPositiveButton("确定", null)
                .create();
        dlg.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface d) {
                dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String err = store.rename(folder, input.getText().toString());
                        if (err != null) {
                            input.setError(err);
                            return;
                        }
                        dlg.dismiss();
                        folder = FolderStore.sanitize(input.getText().toString());
                        rel = FolderStore.relPath(store.root(), folder);
                        store.setLast(folder);
                        titleView.setText(folder);
                        pathView.setText(FolderStore.displayPath(store.root(), folder));
                        Ui.toast(ShootActivity.this, "已重命名；以后的照片会存到新名字下");
                    }
                });
            }
        });
        dlg.show();
    }

    private void switchFolder() {
        final List<String> names = store.folders();
        final String[] items = new String[names.size() + 1];
        items[0] = "＋ 新建文件夹…";
        for (int i = 0; i < names.size(); i++) items[i + 1] = names.get(i);
        new AlertDialog.Builder(this)
                .setTitle("换一个文件夹拍")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        if (which == 0) {
                            newFolderThenSwitch();
                        } else {
                            folder = names.get(which - 1);
                            rel = FolderStore.relPath(store.root(), folder);
                            store.setLast(folder);
                            setSelecting(false);
                            titleView.setText(folder);
                            pathView.setText(FolderStore.displayPath(store.root(), folder));
                            reload();
                        }
                    }
                })
                .show();
    }

    private void newFolderThenSwitch() {
        final EditText input = new EditText(this);
        input.setHint("例如：产品A-白底");
        input.setSingleLine(true);
        input.setTextSize(15);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        FrameLayout box = new FrameLayout(this);
        Ui.padding(box, this, 8, 0, 8, 0);
        box.addView(input);

        final AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("新建文件夹")
                .setView(box)
                .setNegativeButton("取消", null)
                .setPositiveButton("创建", null)
                .create();
        dlg.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface d) {
                dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String err = store.add(input.getText().toString());
                        if (err != null) {
                            input.setError(err);
                            return;
                        }
                        String clean = FolderStore.sanitize(input.getText().toString());
                        dlg.dismiss();
                        folder = clean;
                        rel = FolderStore.relPath(store.root(), clean);
                        store.setLast(clean);
                        setSelecting(false);
                        titleView.setText(folder);
                        pathView.setText(FolderStore.displayPath(store.root(), folder));
                        reload();
                    }
                });
            }
        });
        dlg.show();
    }

    // ------------------------------------------------------------ 批量操作

    private void doShare() {
        List<Media.Shot> sel = selectedShots();
        if (sel.isEmpty()) {
            Ui.toast(this, "先选几张");
            return;
        }
        ArrayList<Uri> uris = new ArrayList<>();
        for (Media.Shot s : sel) uris.add(s.uri);
        Intent i;
        if (uris.size() == 1) {
            i = new Intent(Intent.ACTION_SEND);
            i.putExtra(Intent.EXTRA_STREAM, uris.get(0));
        } else {
            i = new Intent(Intent.ACTION_SEND_MULTIPLE);
            i.putExtra(Intent.EXTRA_STREAM, uris);
        }
        i.setType("image/jpeg");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(Intent.createChooser(i, "分享 " + uris.size() + " 张"));
        } catch (Exception e) {
            Ui.toast(this, "没有可以接收图片的 App");
        }
    }

    /** 把选中的照片打成一个 zip 再分享（整包发出去，比一张张发省事）。 */
    private void doPack() {
        final List<Media.Shot> sel = selectedShots();
        if (sel.isEmpty()) {
            Ui.toast(this, "先选几张再打包");
            return;
        }
        final long bytes = selectedBytes();
        final AlertDialog progress = new AlertDialog.Builder(this)
                .setTitle("正在打包 " + sel.size() + " 张…")
                .setMessage("总共 " + Media.humanSize(bytes))
                .setCancelable(false)
                .create();
        progress.show();

        new Thread(new Runnable() {
            @Override
            public void run() {
                final File zip;
                try {
                    zip = Zip.pack(ShootActivity.this,
                            Zip.defaultName(folder, sel.size()), sel, null);
                } catch (Throwable t) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            progress.dismiss();
                            Ui.toast(ShootActivity.this, "打包失败");
                        }
                    });
                    return;
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        progress.dismiss();
                        if (zip == null || !zip.exists() || zip.length() == 0) {
                            Ui.toast(ShootActivity.this, "打包失败，换个方式分享试试");
                            return;
                        }
                        shareZip(zip);
                    }
                });
            }
        }).start();
    }

    private void shareZip(File zip) {
        Uri uri = LocalFileProvider.shareUri(zip);
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("application/zip");
        i.putExtra(Intent.EXTRA_STREAM, uri);
        i.putExtra(Intent.EXTRA_SUBJECT, zip.getName());
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(Intent.createChooser(i,
                    "分享压缩包 " + zip.getName() + "（" + Media.humanSize(zip.length()) + "）"));
        } catch (Exception e) {
            Ui.toast(this, "没有可以接收压缩包的 App");
        }
    }

    private void doMove() {
        if (selectedShots().isEmpty()) return;
        final List<String> names = new ArrayList<>(store.folders());
        names.remove(folder);
        final String[] items = new String[names.size() + 1];
        items[names.size()] = "＋ 新建文件夹并移过去…";
        for (int i = 0; i < names.size(); i++) items[i] = names.get(i);

        new AlertDialog.Builder(this)
                .setTitle("把 " + selected.size() + " 张移到")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        if (which == names.size()) {
                            newFolderForMove();
                        } else {
                            moveTo(names.get(which));
                        }
                    }
                })
                .show();
    }

    private void newFolderForMove() {
        final EditText input = new EditText(this);
        input.setHint("例如：产品A-白底");
        input.setSingleLine(true);
        input.setTextSize(15);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        FrameLayout box = new FrameLayout(this);
        Ui.padding(box, this, 8, 0, 8, 0);
        box.addView(input);

        final AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("新建文件夹")
                .setView(box)
                .setNegativeButton("取消", null)
                .setPositiveButton("创建并移动", null)
                .create();
        dlg.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface d) {
                dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String err = store.add(input.getText().toString());
                        if (err != null) {
                            input.setError(err);
                            return;
                        }
                        dlg.dismiss();
                        moveTo(FolderStore.sanitize(input.getText().toString()));
                    }
                });
            }
        });
        dlg.show();
    }

    private void moveTo(String target) {
        String destRel = FolderStore.relPath(store.root(), target);
        List<Media.Shot> sel = selectedShots();
        int ok = 0;
        for (Media.Shot s : sel) {
            String name = Media.uniqueName(this, destRel, s.name == null ? "IMG.jpg" : s.name);
            if (Media.move(this, s, destRel, name)) ok++;
        }
        setSelecting(false);
        reload();
        Ui.toast(this, "已移动 " + ok + "/" + sel.size() + " 张到「" + target + "」");
    }

    private void doDelete() {
        final List<Media.Shot> sel = selectedShots();
        if (sel.isEmpty()) return;
        new AlertDialog.Builder(this)
                .setTitle("删除 " + sel.size() + " 张照片")
                .setMessage("照片会从文件夹和系统相册里一起删掉，不能恢复。")
                .setNegativeButton("取消", null)
                .setPositiveButton("删除", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        int ok = 0;
                        for (Media.Shot s : sel) if (Media.remove(ShootActivity.this, s)) ok++;
                        setSelecting(false);
                        Thumbs.clear();
                        reload();
                        Ui.toast(ShootActivity.this, "已删除 " + ok + " 张");
                    }
                })
                .show();
    }

    private void exportPrivate() {
        int ok = 0;
        for (Media.Shot s : new ArrayList<>(shots)) {
            if (s.isPrivate() && Media.exportPrivate(this, s, rel)) ok++;
        }
        Thumbs.clear();
        reload();
        Ui.toast(this, ok > 0 ? ("已导出 " + ok + " 张到相册目录") : "导出失败");
    }

    /** 跳到系统的「所有文件访问」设置页；Android 10 及以下改为直接申请写权限。 */
    private void requestAllFilesAccess() {
        if (android.os.Build.VERSION.SDK_INT < 30) {
            // 这个版本没有「所有文件访问」，靠的是普通的存储写权限
            requestPermissions(new String[]{Media.legacyWritePermission()}, REQ_WRITE);
            return;
        }
        try {
            android.content.Intent i = new android.content.Intent(
                    android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
            i.setData(android.net.Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new android.content.Intent(
                        android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
            } catch (Exception e2) {
                Ui.toast(this, "请到 系统设置 → 应用 → 文件夹相机 里开启「所有文件访问」");
            }
        }
    }

    private static final int REQ_WRITE = 0x21;

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == REQ_WRITE) {
            reload();
            if (!Media.hasAllFilesAccess(this)) {
                Ui.toast(this, "没有存储权限的话，相机不会把照片存进指定文件夹");
            }
        }
    }

    private void openViewer(Media.Shot s) {
        Intent i = new Intent(this, ViewerActivity.class);
        i.putExtra(ViewerActivity.EXTRA_REL, rel);
        i.putExtra(ViewerActivity.EXTRA_INDEX, shots.indexOf(s));
        startActivity(i);
    }
}
