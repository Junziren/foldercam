package com.harness.foldercam;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * 单张大图：双指缩放 / 双击放大 / 拖动看细节，可翻页、改名、分享、删除。
 * 没放大时左右滑动 = 翻上一张/下一张；放大后滑动 = 看图，不会误翻页。
 */
public class ViewerActivity extends Activity {

    static final String EXTRA_REL = "rel";
    static final String EXTRA_INDEX = "index";

    private String rel;
    private int index;
    private List<Media.Shot> shots = new ArrayList<>();

    private ZoomImageView image;
    private TextView counter;
    private TextView info;
    private TextView pathView;
    private TextView hint;

    private float downX, downY;
    private boolean swiping;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.edgeToEdge(getWindow());
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        rel = getIntent().getStringExtra(EXTRA_REL);
        index = getIntent().getIntExtra(EXTRA_INDEX, 0);
        if (rel == null) {
            finish();
            return;
        }
        setContentView(buildUi());
        reload();
    }

    private View buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF0B0C0F);

        image = new ZoomImageView(this);
        image.setScaleType(android.widget.ImageView.ScaleType.MATRIX);
        FrameLayout.LayoutParams ilp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        root.addView(image, ilp);

        // 放大后提示可以拖动
        hint = Ui.text(this, "", 11.5f, 0xFFB9BEC7);
        hint.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams hlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hlp.gravity = Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM;
        hlp.bottomMargin = Ui.dpi(this, 190);
        root.addView(hint, hlp);
        hint.setVisibility(View.GONE);

        image.setOnZoomListener(new ZoomImageView.OnZoomListener() {
            @Override
            public void onZoomChanged(boolean zoomed) {
                hint.setText(zoomed ? "拖动看细节 · 双击还原" : "");
                hint.setVisibility(zoomed ? View.VISIBLE : View.GONE);
            }
        });

        // 左右滑动翻页（只在没放大时生效）
        root.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getX();
                        downY = e.getY();
                        swiping = false;
                        break;
                    case MotionEvent.ACTION_UP:
                        if (!image.isZoomed()) {
                            float dx = e.getX() - downX;
                            float dy = e.getY() - downY;
                            if (Math.abs(dx) > 90 && Math.abs(dx) > Math.abs(dy) * 1.6f) {
                                step(dx < 0 ? 1 : -1);
                            }
                        }
                        break;
                    default:
                        break;
                }
                return false;
            }
        });

        root.addView(buildTop());
        root.addView(buildBottom());
        return root;
    }

    private View buildTop() {
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        Ui.padding(top, this, 6, 6, 12, 6);

        TextView back = Ui.action(this, "←", 0xFFFFFFFF);
        back.setTextSize(22);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        top.addView(back, Ui.lp(Ui.dpi(this, 46), Ui.dpi(this, 46)));

        counter = Ui.text(this, "", 13, 0xFFB9BEC7);
        top.addView(counter, Ui.lpw(1f, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView rename = Ui.action(this, "改名", 0xFFFFFFFF);
        rename.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askRename();
            }
        });
        top.addView(rename);

        TextView share = Ui.action(this, "分享", 0xFFFFFFFF);
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                share();
            }
        });
        top.addView(share);

        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.gravity = Gravity.TOP;
        top.setLayoutParams(tlp);
        Ui.applyInsets(top, true, false);
        return top;
    }

    private View buildBottom() {
        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setBackgroundColor(0xCC0B0C0F);
        Ui.padding(bottom, this, 16, 12, 16, 12);

        info = Ui.bold(Ui.text(this, "", 14, 0xFFFFFFFF));
        bottom.addView(info);

        pathView = Ui.text(this, "", 11, 0xFF9AA1AC);
        pathView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                android.content.ClipboardManager cm =
                        (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(android.content.ClipData.newPlainText("path", pathView.getText()));
                Ui.toast(ViewerActivity.this, "已复制路径");
            }
        });
        bottom.addView(pathView);
        Ui.margin(pathView, this, 0, 5, 0, 0);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);

        TextView prev = Ui.action(this, "‹ 上一张", 0xFFFFFFFF);
        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                step(-1);
            }
        });
        actions.addView(prev, Ui.lpw(1f, Ui.dpi(this, 46)));

        TextView next = Ui.action(this, "下一张 ›", 0xFFFFFFFF);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                step(1);
            }
        });
        actions.addView(next, Ui.lpw(1f, Ui.dpi(this, 46)));

        TextView del = Ui.action(this, "删除", Ui.DANGER);
        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmDelete();
            }
        });
        actions.addView(del, Ui.lpw(1f, Ui.dpi(this, 46)));
        bottom.addView(actions);
        Ui.margin(actions, this, 0, 8, 0, 0);

        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.gravity = Gravity.BOTTOM;
        bottom.setLayoutParams(blp);
        Ui.applyInsets(bottom, false, true);
        return bottom;
    }

    private void reload() {
        shots = Media.listIn(this, new FolderStore(this).root(), rel);
        if (shots.isEmpty()) {
            finish();
            return;
        }
        if (index < 0) index = 0;
        if (index >= shots.size()) index = shots.size() - 1;
        show();
    }

    private Media.Shot current() {
        return shots.get(index);
    }

    private void show() {
        final Media.Shot s = current();
        // 屏幕长边已经很大，但没必要按原图解码（4096x3072 会吃掉 ~48MB）。
        // 2048 对整屏观看完全够，且内存安全。
        int maxPx = Math.min(2048, Math.max(
                getResources().getDisplayMetrics().widthPixels,
                getResources().getDisplayMetrics().heightPixels));
        image.setImageDrawable(null);
        Thumbs.large(s, maxPx, this, new Thumbs.Once() {
            @Override
            public void got(Bitmap bmp) {
                if (bmp != null) image.setImageBitmap(bmp);
            }
        });

        counter.setText((index + 1) + " / " + shots.size());
        info.setText(s.name + "　·　" + Media.humanSize(s.size)
                + (s.width > 0 ? "　·　" + s.width + "×" + s.height : ""));

        String dir = s.rel == null ? rel : s.rel;
        String root = new FolderStore(this).root();
        String shown = dir.startsWith(root + "/")
                ? "内部存储/" + dir.substring(0, dir.length() - 1) + "/" + s.name
                : dir + s.name;
        pathView.setText(s.isPrivate()
                ? shown + "　（App 私有目录，点可复制）"
                : shown);
        pathView.setSingleLine(false);
    }

    private void step(int d) {
        int n = index + d;
        if (n < 0 || n >= shots.size()) {
            Ui.toast(this, d < 0 ? "已经是第一张" : "已经是最后一张");
            return;
        }
        index = n;
        show();
    }

    // ------------------------------------------------------------------ 改名

    private void askRename() {
        final Media.Shot s = current();
        final EditText input = new EditText(this);
        input.setText(s.name);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setTextSize(15);
        input.setSelection(s.name == null ? 0 : s.name.length());
        FrameLayout box = new FrameLayout(this);
        Ui.padding(box, this, 8, 0, 8, 0);
        box.addView(input);

        final AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("给这张照片改名")
                .setMessage("只改文件名，不动照片内容。留在同一个文件夹里。")
                .setView(box)
                .setNegativeButton("取消", null)
                .setPositiveButton("确定", null)
                .create();
        dlg.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface d) {
                dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String err = Media.rename(ViewerActivity.this, s, input.getText().toString());
                        if (err != null) {
                            input.setError(err);
                            return;
                        }
                        dlg.dismiss();
                        Thumbs.clear();
                        show();
                        Ui.toast(ViewerActivity.this, "已改名");
                    }
                });
            }
        });
        dlg.show();
    }

    // ------------------------------------------------------------------ 分享 / 删除

    private void share() {
        Media.Shot s = current();
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("image/jpeg");
        // 优先给真实文件路径（微信等 App 对 file:// 有时不认，但 content:// 走我们的 provider 是通的）
        i.putExtra(Intent.EXTRA_STREAM, s.uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(Intent.createChooser(i, "分享这张"));
        } catch (Exception e) {
            Ui.toast(this, "没有可以接收图片的 App");
        }
    }

    private void confirmDelete() {
        final Media.Shot s = current();
        new AlertDialog.Builder(this)
                .setTitle("删除这张照片")
                .setMessage(s.name + "\n\n从文件夹和系统相册里一起删掉，不能恢复。")
                .setNegativeButton("取消", null)
                .setPositiveButton("删除", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        if (Media.remove(ViewerActivity.this, s)) {
                            Thumbs.clear();
                            shots.remove(s);
                            if (shots.isEmpty()) {
                                finish();
                                return;
                            }
                            if (index >= shots.size()) index = shots.size() - 1;
                            show();
                            Ui.toast(ViewerActivity.this, "已删除");
                        } else {
                            Ui.toast(ViewerActivity.this, "删除失败");
                        }
                    }
                })
                .show();
    }
}
