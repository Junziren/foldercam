package com.harness.foldercam;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.util.Size;
import android.widget.ImageView;

import java.io.File;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** 缩略图：3 线程池解码 + LruCache；GridView 复用 view 时用 tag 防串图。 */
final class Thumbs {

    private static final int CACHE_BYTES = 12 * 1024 * 1024;
    private static final LruCache<String, Bitmap> CACHE =
            new LruCache<String, Bitmap>(CACHE_BYTES) {
                @Override
                protected int sizeOf(String key, Bitmap value) {
                    return value.getByteCount();
                }
            };
    private static final ExecutorService POOL = Executors.newFixedThreadPool(3);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private Thumbs() {
    }

    interface Once {
        void got(Bitmap bmp);
    }

    static void into(final ImageView view, final Media.Shot shot, final int px) {
        final Context ctx = view.getContext();
        final String key = keyOf(shot, px);
        view.setTag(key);
        Bitmap hit = CACHE.get(key);
        if (hit != null) {
            view.setImageBitmap(hit);
            return;
        }
        view.setImageDrawable(null);
        POOL.execute(new Runnable() {
            @Override
            public void run() {
                final Bitmap bmp = decode(ctx, shot, px);
                if (bmp == null) return;
                CACHE.put(key, bmp);
                MAIN.post(new Runnable() {
                    @Override
                    public void run() {
                        if (key.equals(view.getTag())) view.setImageBitmap(bmp);
                    }
                });
            }
        });
    }

    /** 大图（详情页）：不走缩略图缓存。 */
    static void large(final Media.Shot shot, final int px, final Context ctx, final Once cb) {
        final String key = keyOf(shot, px);
        Bitmap hit = CACHE.get(key);
        if (hit != null) {
            cb.got(hit);
            return;
        }
        POOL.execute(new Runnable() {
            @Override
            public void run() {
                final Bitmap bmp = decode(ctx, shot, px);
                if (bmp != null) CACHE.put(key, bmp);
                MAIN.post(new Runnable() {
                    @Override
                    public void run() {
                        cb.got(bmp);
                    }
                });
            }
        });
    }

    static void clear() {
        CACHE.evictAll();
    }

    private static String keyOf(Media.Shot s, int px) {
        if (s.isPrivate()) return "f:" + s.file.getAbsolutePath() + "@" + px;
        if (s.isPublicFile()) return "p:" + s.file.getAbsolutePath() + "@" + px;
        return "u:" + s.uri + "@" + px;
    }

    private static Bitmap decode(Context ctx, Media.Shot shot, int px) {
        // 1) 优先用磁盘上的原图自己采样解码 —— 清晰度可控。
        //    MIUI 的 loadThumbnail 经常返回远小于请求尺寸的图，看着就是糊的缩略图。
        //    我们本来就有「所有文件访问」，原图就在磁盘上，直接解最高效。
        File f = shot.file;
        if (f == null) f = Media.publicFilePath(ctx, shot.rel, shot.name);
        if (f != null && f.exists() && f.length() > 0) {
            Bitmap b = decodeFile(f, px);
            if (b != null) return b;
        }
        // 2) 拿不到真实文件（别的卷 / 别的 App 的照片）才退回系统缩略图
        if (!shot.isPrivate() && shot.uri != null) {
            try {
                return ctx.getContentResolver().loadThumbnail(
                        shot.uri, new Size(px, px), null);
            } catch (Exception | OutOfMemoryError ignored) {
            }
        }
        // 3) 最后兜底：流式解码
        try {
            InputStream in = ctx.getContentResolver().openInputStream(shot.uri);
            if (in == null) return null;
            try {
                return decodeStream(in, px);
            } finally {
                in.close();
            }
        } catch (Exception | OutOfMemoryError e) {
            return null;
        }
    }

    private static Bitmap decodeFile(File f, int px) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(f.getAbsolutePath(), o);
        o.inSampleSize = sample(o.outWidth, o.outHeight, px);
        o.inJustDecodeBounds = false;
        return BitmapFactory.decodeFile(f.getAbsolutePath(), o);
    }

    private static Bitmap decodeStream(InputStream in, int px) throws Exception {
        // 流不能 seek，先整个读进内存再两次解码
        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[32 * 1024];
        int n;
        while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        byte[] bytes = bos.toByteArray();

        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(bytes, 0, bytes.length, o);
        o.inSampleSize = sample(o.outWidth, o.outHeight, px);
        o.inJustDecodeBounds = false;
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.length, o);
    }

    private static int sample(int w, int h, int px) {
        // 目标是：采样后长边 >= px（保证够清晰），同时 <= 2*px（限制内存）。
        int s = 1;
        int max = Math.max(w, h);
        while (max / (s * 2) >= px) s *= 2;
        return s;
    }
}
