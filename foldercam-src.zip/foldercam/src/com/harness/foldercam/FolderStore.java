package com.harness.foldercam;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

/**
 * 文件夹清单 / 上次使用的文件夹 / 根目录设置。
 * 照片本身以 MediaStore 为准，这里只记「用户建了哪些文件夹」——因为空文件夹在 MediaStore 里查不到。
 */
final class FolderStore {
    static final String ROOT_PICTURES = "Pictures/FolderCam";
    static final String ROOT_DCIM = "DCIM/FolderCam";

    private static final String PREF = "foldercam";
    private static final String KEY_FOLDERS = "folders";
    private static final String KEY_LAST = "last_folder";
    private static final String KEY_ROOT = "root";
    private static final String KEY_PRIVATE = "private_notice_seen";
    private static final String KEY_ONBOARDED = "onboarded";

    private final SharedPreferences sp;

    FolderStore(Context c) {
        sp = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    String root() {
        return sp.getString(KEY_ROOT, ROOT_PICTURES);
    }

    void setRoot(String root) {
        sp.edit().putString(KEY_ROOT, root).apply();
    }

    String rootLabel() {
        return ROOT_DCIM.equals(root()) ? "DCIM（与相机照片同级）" : "Pictures（与相机照片分开）";
    }

    List<String> folders() {
        List<String> out = new ArrayList<>();
        String raw = sp.getString(KEY_FOLDERS, "[]");
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) {
                String n = a.optString(i, null);
                if (n != null && n.length() > 0) out.add(n);
            }
        } catch (JSONException ignored) {
        }
        return out;
    }

    private void saveFolders(List<String> names) {
        JSONArray a = new JSONArray();
        for (String n : names) a.put(n);
        sp.edit().putString(KEY_FOLDERS, a.toString()).apply();
    }

    boolean exists(String name) {
        return folders().contains(name);
    }

    /** 返回 null 表示成功，否则返回给用户看的错误原因。 */
    String add(String name) {
        String clean = sanitize(name);
        if (clean == null) return "文件夹名不能为空";
        if (clean.length() > 60) return "名字太长了（最多 60 个字符）";
        List<String> cur = folders();
        if (cur.contains(clean)) return "已经有这个文件夹了";
        // 新建的排最前，方便刚建完就用
        cur.add(0, clean);
        saveFolders(cur);
        return null;
    }

    String rename(String from, String to) {
        String clean = sanitize(to);
        if (clean == null) return "文件夹名不能为空";
        if (clean.equals(from)) return null;
        List<String> cur = folders();
        if (cur.contains(clean)) return "已经有这个文件夹了";
        int i = cur.indexOf(from);
        if (i < 0) return "找不到这个文件夹";
        cur.set(i, clean);
        saveFolders(cur);
        if (from.equals(last())) setLast(clean);
        return null;
    }

    void remove(String name) {
        List<String> cur = folders();
        cur.remove(name);
        saveFolders(cur);
        if (name.equals(last())) setLast(null);
    }

    String last() {
        String n = sp.getString(KEY_LAST, null);
        return (n != null && folders().contains(n)) ? n : null;
    }

    void setLast(String name) {
        sp.edit().putString(KEY_LAST, name).apply();
    }

    boolean privateNoticeSeen() {
        return sp.getBoolean(KEY_PRIVATE, false);
    }

    void setPrivateNoticeSeen() {
        sp.edit().putBoolean(KEY_PRIVATE, true).apply();
    }

    /** 首次启动的引导页看过没有。 */
    boolean onboarded() {
        return sp.getBoolean(KEY_ONBOARDED, false);
    }

    void setOnboarded() {
        sp.edit().putBoolean(KEY_ONBOARDED, true).apply();
    }

    void setOnboarded(boolean v) {
        sp.edit().putBoolean(KEY_ONBOARDED, v).apply();
    }

    // ---------- 路径工具 ----------

    /** "Pictures/FolderCam/产品A/" —— MediaStore 的 RELATIVE_PATH 需要尾部斜杠。 */
    static String relPath(String root, String folder) {
        return root + "/" + folder + "/";
    }

    static String displayPath(String root, String folder) {
        return "内部存储/" + root + "/" + folder;
    }

    /** 去掉文件名里 MediaStore 不接受的字符。返回 null 表示清完是空的。 */
    static String sanitize(String name) {
        if (name == null) return null;
        String s = name.trim();
        // MediaStore 的 RELATIVE_PATH / DISPLAY_NAME 不接受这些字符
        s = s.replaceAll("[\\\\/:*?\"<>|\\n\\r\\t]", "");
        // 圆点开头会让文件变成隐藏文件
        while (s.startsWith(".")) s = s.substring(1);
        s = s.trim();
        return s.isEmpty() ? null : s;
    }

    /** 生成本次拍照用的文件名，例如 IMG_20260924_063012_01.jpg */
    static String photoName(int seq) {
        java.text.SimpleDateFormat f =
                new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US);
        return String.format(java.util.Locale.US, "IMG_%s_%02d.jpg", f.format(new java.util.Date()),
                Math.max(0, Math.min(99, seq)));
    }
}
