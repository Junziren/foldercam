package com.harness.foldercam;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * 极简 FileProvider（不依赖 AndroidX）。把 App 私有目录里的文件以 content:// 暴露出去：
 *
 *   files/shots/&lt;文件夹&gt;/&lt;照片&gt;   —— 兜底模式下相机写不进去时暂存的照片
 *   files/share/&lt;名字&gt;.zip          —— 打包分享用的压缩包
 *
 * 路径全部经过白名单校验，杜绝 ../ 穿越。
 */
public class LocalFileProvider extends ContentProvider {

    public static final String AUTHORITY = "com.harness.foldercam.files";

    private static final String DIR_SHOTS = "shots";
    private static final String DIR_SHARE = "share";

    /** 兜底照片：files/shots/<一个子目录>/<文件名> */
    public static Uri uriFor(File f) {
        return new Uri.Builder().scheme("content").authority(AUTHORITY)
                .appendPath(f.getName()).build();
    }

    /** 打包产物：files/share/<文件名> */
    public static Uri shareUri(File f) {
        return new Uri.Builder().scheme("content").authority(AUTHORITY)
                .appendPath(DIR_SHARE)
                .appendPath(f.getName()).build();
    }

    @Override
    public boolean onCreate() {
        return true;
    }

    /** 把 URI 解析成真实文件；只允许上面两类路径。 */
    private File resolve(Uri uri) throws FileNotFoundException {
        if (getContext() == null) throw new FileNotFoundException("no context");
        java.util.List<String> seg = uri.getPathSegments();
        if (seg.isEmpty()) throw new FileNotFoundException("empty uri");

        File base = new File(getContext().getFilesDir(), DIR_SHARE);
        if (DIR_SHARE.equals(seg.get(0))) {
            if (seg.size() != 2) throw new FileNotFoundException("bad share path");
            return safeJoin(base, seg.get(1));
        }

        // 兜底照片：按文件名在 shots/<任意一层子目录>/ 下找
        File root = new File(getContext().getFilesDir(), DIR_SHOTS);
        String name = seg.get(seg.size() - 1);
        File direct = new File(root, name);
        if (direct.exists()) return direct;
        File[] subs = root.listFiles();
        if (subs != null) {
            for (File d : subs) {
                if (!d.isDirectory()) continue;
                File cand = new File(d, name);
                if (cand.exists()) return cand;
            }
        }
        return direct;
    }

    /** 只允许「直接子项」，任何含分隔符或 .. 的名字都拒绝。 */
    private static File safeJoin(File dir, String name) throws FileNotFoundException {
        if (name == null || name.isEmpty()
                || name.contains("/") || name.contains("\\") || name.contains("..")) {
            throw new FileNotFoundException("bad name: " + name);
        }
        return new File(dir, name);
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        File f = resolve(uri);
        int flags = ParcelFileDescriptor.MODE_CREATE;
        if (mode != null && mode.contains("w")) {
            flags |= ParcelFileDescriptor.MODE_READ_WRITE | ParcelFileDescriptor.MODE_TRUNCATE;
        } else {
            flags |= ParcelFileDescriptor.MODE_READ_ONLY;
        }
        return ParcelFileDescriptor.open(f, flags);
    }

    @Override
    public String getType(Uri uri) {
        String last = uri.getLastPathSegment();
        if (last != null && last.toLowerCase(java.util.Locale.US).endsWith(".zip")) {
            return "application/zip";
        }
        return Media.MIME;
    }

    /**
     * 必须实现：微信/QQ/邮件等 App 拿到 content:// 后，会先查
     * OpenableColumns.DISPLAY_NAME 和 SIZE 来显示文件名和大小。
     * 不实现的话它们只能瞎编一个名字（实测微信会把 zip 显示成 "share_file.zip"，
     * 用户根本认不出这是哪个文件夹的包）。
     */
    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        File f;
        try {
            f = resolve(uri);
        } catch (FileNotFoundException e) {
            return null;
        }

        String[] cols;
        Object[] vals;
        if (projection == null) {
            cols = new String[]{
                    android.provider.OpenableColumns.DISPLAY_NAME,
                    android.provider.OpenableColumns.SIZE};
            vals = new Object[]{f.getName(), f.exists() ? f.length() : 0L};
        } else {
            cols = new String[projection.length];
            vals = new Object[projection.length];
            for (int i = 0; i < projection.length; i++) {
                String col = projection[i];
                cols[i] = col;
                if (android.provider.OpenableColumns.DISPLAY_NAME.equals(col)) {
                    vals[i] = f.getName();
                } else if (android.provider.OpenableColumns.SIZE.equals(col)) {
                    vals[i] = f.exists() ? f.length() : 0L;
                } else {
                    vals[i] = null;
                }
            }
        }

        android.database.MatrixCursor c =
                new android.database.MatrixCursor(cols);
        c.addRow(vals);
        return c;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }
}
