package com.harness.foldercam;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.drawable.Drawable;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.ImageView;

/**
 * 可缩放的大图控件：双指捏合缩放、双击放大/还原、放大后拖动看细节。
 *
 * 没放大到超出屏幕时，左右滑动的手势会让给外面（用来翻上一张/下一张），
 * 这样「看细节」和「翻页」两种操作不会互相打架。
 */
public class ZoomImageView extends ImageView {

    private static final float MAX_SCALE = 6f;
    private static final float DOUBLE_TAP_SCALE = 2.5f;

    private final Matrix matrix = new Matrix();
    private final ScaleGestureDetector scaleDetector;
    private final GestureDetector gestureDetector;

    private float currentScale = 1f;
    private float baseScale = 1f;     // FIT_CENTER 下的初始缩放
    private float lastX, lastY;
    private boolean dragging;

    /** 当前是不是已经放大到能拖动了（用来决定左右滑动要不要翻页）。 */
    public interface OnZoomListener {
        void onZoomChanged(boolean zoomed);
    }

    private OnZoomListener zoomListener;

    public ZoomImageView(Context c) {
        super(c);
        setScaleType(ScaleType.MATRIX);

        scaleDetector = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector d) {
                if (getDrawable() == null) return true;
                float factor = d.getScaleFactor();
                float target = currentScale * factor;
                if (target < baseScale) factor = baseScale / currentScale;
                if (target > baseScale * MAX_SCALE) factor = baseScale * MAX_SCALE / currentScale;
                if (factor == 1f) return true;
                currentScale *= factor;
                matrix.postScale(factor, factor, d.getFocusX(), d.getFocusY());
                clamp();
                setImageMatrix(matrix);
                notifyZoom();
                return true;
            }
        });

        gestureDetector = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDoubleTap(MotionEvent e) {
                if (getDrawable() == null) return true;
                if (currentScale > baseScale * 1.05f) {
                    resetZoom();
                } else {
                    float target = Math.min(baseScale * DOUBLE_TAP_SCALE, baseScale * MAX_SCALE);
                    float factor = target / currentScale;
                    currentScale = target;
                    matrix.postScale(factor, factor, e.getX(), e.getY());
                    clamp();
                    setImageMatrix(matrix);
                    notifyZoom();
                }
                return true;
            }

            @Override
            public boolean onDown(MotionEvent e) {
                return true;
            }
        });
        gestureDetector.setOnDoubleTapListener(new GestureDetector.OnDoubleTapListener() {
            @Override
            public boolean onSingleTapConfirmed(MotionEvent e) {
                performClick();
                return false;
            }

            @Override
            public boolean onDoubleTap(MotionEvent e) {
                return false;
            }

            @Override
            public boolean onDoubleTapEvent(MotionEvent e) {
                return false;
            }
        });
    }

    public void setOnZoomListener(OnZoomListener l) {
        this.zoomListener = l;
    }

    private void notifyZoom() {
        if (zoomListener != null) zoomListener.onZoomChanged(isZoomed());
    }

    public boolean isZoomed() {
        return currentScale > baseScale * 1.02f;
    }

    @Override
    public void setImageDrawable(Drawable d) {
        super.setImageDrawable(d);
        if (d == null) {
            matrix.reset();
            currentScale = 1f;
            baseScale = 1f;
            setImageMatrix(matrix);
            return;
        }
        post(new Runnable() {
            @Override
            public void run() {
                resetZoom();
            }
        });
    }

    /** 按 FIT_CENTER 铺满并居中，回到 1 倍。 */
    public void resetZoom() {
        Drawable d = getDrawable();
        if (d == null) return;
        int vw = getWidth() - getPaddingLeft() - getPaddingRight();
        int vh = getHeight() - getPaddingTop() - getPaddingBottom();
        int dw = d.getIntrinsicWidth();
        int dh = d.getIntrinsicHeight();
        if (vw <= 0 || vh <= 0 || dw <= 0 || dh <= 0) return;

        float scale = Math.min((float) vw / dw, (float) vh / dh);
        baseScale = scale;
        currentScale = scale;

        float dx = (vw - dw * scale) / 2f + getPaddingLeft();
        float dy = (vh - dh * scale) / 2f + getPaddingTop();
        matrix.reset();
        matrix.postScale(scale, scale);
        matrix.postTranslate(dx, dy);
        setImageMatrix(matrix);
        notifyZoom();
    }

    /** 把图拉回到视图范围内（图片比屏幕小时就居中）。 */
    private void clamp() {
        Drawable d = getDrawable();
        if (d == null) return;
        float[] v = new float[9];
        matrix.getValues(v);
        float scale = v[Matrix.MSCALE_X];
        float transX = v[Matrix.MTRANS_X];
        float transY = v[Matrix.MTRANS_Y];
        float imgW = d.getIntrinsicWidth() * scale;
        float imgH = d.getIntrinsicHeight() * scale;
        float vw = getWidth();
        float vh = getHeight();

        float maxX = 0, maxY = 0, minX = 0, minY = 0;
        if (imgW > vw) {
            minX = vw - imgW;
            maxX = 0;
        } else {
            minX = maxX = (vw - imgW) / 2f;
        }
        if (imgH > vh) {
            minY = vh - imgH;
            maxY = 0;
        } else {
            minY = maxY = (vh - imgH) / 2f;
        }
        float nx = Math.min(maxX, Math.max(minX, transX));
        float ny = Math.min(maxY, Math.max(minY, transY));
        v[Matrix.MTRANS_X] = nx;
        v[Matrix.MTRANS_Y] = ny;
        matrix.setValues(v);
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        scaleDetector.onTouchEvent(ev);
        gestureDetector.onTouchEvent(ev);

        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastX = ev.getX();
                lastY = ev.getY();
                dragging = false;
                break;
            case MotionEvent.ACTION_MOVE:
                if (ev.getPointerCount() == 1 && isZoomed()) {
                    float dx = ev.getX() - lastX;
                    float dy = ev.getY() - lastY;
                    if (Math.abs(dx) > 1 || Math.abs(dy) > 1) {
                        dragging = true;
                        matrix.postTranslate(dx, dy);
                        clamp();
                        setImageMatrix(matrix);
                    }
                    lastX = ev.getX();
                    lastY = ev.getY();
                }
                break;
            case MotionEvent.ACTION_UP:
                lastX = ev.getX();
                lastY = ev.getY();
                break;
            default:
                break;
        }
        return true;
    }

    /** 是否正在拖动（拖动时不要翻页）。 */
    public boolean isDragging() {
        return dragging;
    }
}
