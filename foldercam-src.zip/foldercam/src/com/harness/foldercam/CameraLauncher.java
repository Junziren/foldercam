package com.harness.foldercam;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Log;

import java.io.File;
import java.util.Locale;

/**
 * 把拍照完全交给本机相机 App：ACTION_IMAGE_CAPTURE + EXTRA_OUTPUT。
 * HDR / 夜景 / 人像 / 徕卡滤镜 / 变焦 / 水印 全部原样保留，我们一行相机代码都不写。
 *
 * 相机把原图直接写进我们在目标文件夹里预建的文件；返回后校验文件大小：
 *   写入成功 -> 清 IS_PENDING，正式落盘
 *   没写进去 -> 用应用私有目录自动重试一次，再不行就报错
 *   用户取消 -> 删掉占位的 pending 行，不留 0 字节垃圾
 */
final class CameraLauncher {

    static final int REQ = 0x7C41;
    private static final String TAG = "FolderCam";

    interface Sink {
        void onCaptured(Media.Shot shot, String rel);

        void onCancelled();

        void onFailed(String message);
    }

    private final Activity act;
    private final Sink sink;

    private Uri pending;
    private File pendingFile;
    private String pendingRel;
    private String pendingName;
    private long shotStartedAt;
    private boolean pendingPublic; // true = 直接写公共目录（file:// 输出）
    private int pendingMode = MODE_CONTENT; // 本次用的是哪种输出方式
    private int triedModes;                 // 已经试过哪些方式（位掩码），防止来回打转

    CameraLauncher(Activity a, Sink s) {
        this.act = a;
        this.sink = s;
    }

    boolean busy() {
        return pending != null;
    }

    /** 本次拍摄的起始时间，用来在相机把照片写到别处时把它找回来。 */
    long startedAt() {
        return shotStartedAt;
    }

    /** rel 形如 "Pictures/FolderCam/产品A/"；name 由调用方保证同文件夹内不重名。 */
    void shoot(String rel, String name) {
        triedModes = 0;
        shotStartedAt = System.currentTimeMillis();
        begin(rel, name, nextMode());
    }

    // 尝试顺序：主路径 -> 另一种公共路径 -> 私有目录兜底
    private static final int MODE_FILE = 0;     // file:// 直写公共目录
    private static final int MODE_CONTENT = 1;  // content:// 交给 MediaStore
    private static final int MODE_PRIVATE = 2;  // 应用私有目录（最后兜底）

    /** 按照本机情况决定第一次尝试用哪种输出方式。 */
    private int firstMode() {
        boolean canFile = Media.hasAllFilesAccess(act);
        boolean miui = Media.cameraPrefersFileUri();
        if (miui) {
            // MIUI 相机只认 file://（content:// 会把照片弄丢）
            return canFile ? MODE_FILE : MODE_CONTENT;
        }
        // 其它 ROM：content:// 才是官方支持的方式。
        // 相机是沙盒应用，file:// 指向的公共目录它未必写得进去。
        return MODE_CONTENT;
    }

    /** 按优先顺序挑一个还没试过的输出方式；都试过了返回 MODE_PRIVATE。 */
    private int nextMode() {
        // 顺序：ROM 偏好的那个 -> 另一种公共方式 -> 私有目录
        int first = firstMode();
        int second = (first == MODE_FILE) ? MODE_CONTENT : MODE_FILE;
        if ((triedModes & (1 << first)) == 0) return first;
        if ((triedModes & (1 << second)) == 0
                && (second != MODE_FILE || Media.hasAllFilesAccess(act))) {
            return second;
        }
        return MODE_PRIVATE;
    }

    /** 这一种方式建文件就失败了：直接换下一种，别打扰用户。 */
    private void fallbackOrFail(String rel, String name, int mode, String message) {
        triedModes |= (1 << mode);
        int next = nextMode();
        if (next != mode && next != MODE_PRIVATE) {
            Log.w(TAG, "mode=" + mode + " 建文件失败，换 mode=" + next + " 再试");
            begin(rel, name, next);
            return;
        }
        Log.w(TAG, "建文件失败且无路可退: " + message);
        sink.onFailed(message);
    }

    private void begin(String rel, String name, int mode) {
        final Uri uri;
        File file = null;
        boolean publicDir = false;
        try {
            if (mode == MODE_PRIVATE) {
                file = Media.newPrivateFile(act, rel, name);
                if (file == null) {
                    sink.onFailed("无法创建文件（私有目录不可写）");
                    return;
                }
                uri = Media.privateUri(act, file);
            } else if (mode == MODE_FILE) {
                file = Media.newPublicFile(rel, name);
                if (file == null) {
                    // 建不了文件通常是没有存储权限，换回 content:// 试试
                    fallbackOrFail(rel, name, mode, "无法在目标文件夹创建文件");
                    return;
                }
                uri = Uri.fromFile(file);
                publicDir = true;
            } else {
                uri = Media.createPending(act, rel, name);
                if (uri == null) {
                    fallbackOrFail(rel, name, mode, "无法在目标文件夹创建文件");
                    return;
                }
            }
        } catch (Exception e) {
            fallbackOrFail(rel, name, mode, "创建文件失败：" + e.getMessage());
            return;
        }

        pending = uri;
        pendingFile = file;
        pendingRel = rel;
        pendingName = name;
        pendingPublic = publicDir;
        pendingMode = mode;

        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        i.putExtra(MediaStore.EXTRA_OUTPUT, uri);
        i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        // Android 11+ 光靠 flag 传不下去，必须带上 clipData 才会真正授权给相机
        // （file:// 时这个只是保险，真正生效的是相机自己的文件权限）
        if ("content".equals(uri.getScheme())) {
            i.setClipData(ClipData.newUri(act.getContentResolver(), "foldercam", uri));
        }
        Log.i(TAG, "发起拍照 mode=" + mode + " uri=" + uri + " name=" + name);
        try {
            act.startActivityForResult(i, REQ);
        } catch (ActivityNotFoundException e) {
            discard();
            sink.onFailed("这台设备上没找到可用的相机 App");
        } catch (Exception e) {
            discard();
            sink.onFailed("打开相机失败：" + e.getMessage());
        }
    }

    void onActivityResult(int reqCode, int result, Intent data) {
        if (reqCode != REQ || pending == null) return;

        final Uri uri = pending;
        File file = pendingFile;
        final String rel = pendingRel;
        String name = pendingName;
        final boolean wasPublic = pendingPublic;
        final int mode = pendingMode;
        pending = null;
        pendingFile = null;
        pendingPublic = false;

        long size = file != null ? Media.sizeOfFile(file) : Media.sizeOf(act, uri);
        Log.i(TAG, "onActivityResult result=" + result + " name=" + name
                + " uri=" + uri + " file=" + file + " size=" + size
                + " mode=" + mode + " public=" + wasPublic);

        if (size > 0) {
            // 相机可能写出 HEIC 内容却用着 .jpg 的名字（三星/Pixel 拍 HEIC 时会这样），
            // 按文件头纠正扩展名，否则有些相册和微信打不开。
            if (file != null) {
                String fixed = Media.fixExtensionByContent(file, name);
                if (fixed != null && !fixed.equals(name)) {
                    File renamed = new File(file.getParentFile(), fixed);
                    if (renamed.exists()) {
                        name = fixed;
                        file = renamed;
                    }
                }
            }
            if (wasPublic) {
                // 公共目录直写：让 MediaStore 收录，相册和本 App 才看得到
                Media.scanFile(act, file);
            } else if (file == null) {
                Media.publish(act, uri);
            }
            Media.Shot shot = new Media.Shot();
            shot.file = file;
            shot.uri = uri;
            shot.name = name;
            shot.rel = rel;
            shot.size = size;
            shot.dateAdded = System.currentTimeMillis() / 1000L;
            shot.pending = wasPublic; // 需要重查一次拿到 MediaStore 的 _id
            if (file == null) shot.id = android.content.ContentUris.parseId(uri);
            Log.i(TAG, "拍到了: " + name + " (" + size + " 字节) -> " + rel);
            sink.onCaptured(shot, rel);
            return;
        }

        // 一张都没写进来。
        // 注意顺序：先试着「收编」—— 相机可能把照片写到了它自己的目录；
        // 只有确认磁盘上确实没有，才清掉占位行（否则会把照片一起删掉）。
        Log.w(TAG, "相机会话没有产生数据 (result=" + result + "), 尝试收编相机写到别处的照片");
        int adopted = Media.adoptOrphans(act, rootOf(rel), rel, shotStartedAt);
        if (adopted > 0) {
            Log.i(TAG, "收编成功 " + adopted + " 张");
            Media.Shot shot = new Media.Shot();
            shot.name = name;
            shot.rel = rel;
            shot.file = null;
            shot.uri = uri;
            shot.dateAdded = System.currentTimeMillis() / 1000L;
            sink.onCaptured(shot, rel);
            return;
        }

        // 确认没有：清掉占位，别留 0 字节文件
        if (file == null) {
            try {
                act.getContentResolver().delete(uri, null, null);
            } catch (Exception ignored) {
            }
        } else if (file.exists()) {
            //noinspection ResultOfMethodCallIgnored
            file.delete();
        }

        // 换下一种输出方式再试（MIUI 上通常会从 content:// 换到 file://，反之亦然）。
        // 全都试过才会落到私有目录兜底。
        triedModes |= (1 << mode);
        int next = nextMode();
        if (next != mode) {
            Log.i(TAG, "mode=" + mode + " 没拿到照片，换 mode=" + next + " 再试");
            begin(rel, name, next);
            return;
        }
        if (result == Activity.RESULT_OK) {
            sink.onFailed("相机没有把照片写进指定文件夹（这台设备的相机可能不支持自定义保存路径）");
        } else {
            sink.onCancelled();
        }
    }

    /** "Pictures/FolderCam/A/" -> "Pictures/FolderCam" */
    private static String rootOf(String rel) {
        String r = rel.endsWith("/") ? rel.substring(0, rel.length() - 1) : rel;
        int i = r.lastIndexOf('/');
        return i > 0 ? r.substring(0, i) : r;
    }

    private void discard() {
        if (pending != null && pendingFile == null) {
            try {
                act.getContentResolver().delete(pending, null, null);
            } catch (Exception ignored) {
            }
        } else if (pendingFile != null && pendingFile.exists()) {
            //noinspection ResultOfMethodCallIgnored
            pendingFile.delete();
        }
        pending = null;
        pendingFile = null;
    }
}
