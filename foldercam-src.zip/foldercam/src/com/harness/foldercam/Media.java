package com.harness.foldercam;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * 照片读写。主路径走 MediaStore（直接落在 Pictures/FolderCam/&lt;文件夹&gt;/，不需要存储权限，
 * 文件管理器 / USB / 微信都能直接拿到）。
 *
 * 相机如果不认 EXTRA_OUTPUT，就把照片降级存到应用私有目录（file != null），
 * 界面上会有提示，并提供「导出到相册目录」。
 */
final class Media {

    // 【重要】用老的 external 卷（content://media/external/images/media），
    // 不要用 external_primary。MIUI 相机对 URI 是硬匹配的，
    // 收到 external_primary 形式的 URI 会直接返回 RESULT_CANCELED 且什么都不写
    // （实测日志：onActivityResult result=0，磁盘上也没有文件）。
    // EXTERNAL_CONTENT_URI 在 Android 10+ 依然可用，指向同一个主卷。
    @SuppressWarnings("deprecation")
    static final Uri COLLECTION = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
    static final String MIME = "image/jpeg";
    private static final String PRIVATE_DIR = "shots";

    private Media() {
    }

    // ------------------------------------------------------------------ 数据结构

    static final class Shot {
        long id;
        Uri uri;
        String name;
        String rel;
        long dateAdded;
        long size;
        int width;
        int height;
        /** 磁盘上的真实文件。公共目录直写和私有兜底都会设置它。 */
        File file;
        /** true = 这个文件在 App 私有目录里（需要导出）；false = 在公共目录。 */
        boolean privateDir;
        /** 刚拍完、MediaStore 里还没索引到，需要重查一次拿 _id。 */
        boolean pending;

        /** 在 App 私有目录里，需要对用户提示并能「导出到相册目录」。 */
        boolean isPrivate() {
            return privateDir;
        }

        /** 公共目录里的真实文件。 */
        boolean isPublicFile() {
            return file != null && !privateDir;
        }
    }

    // ------------------------------------------------------------------ 查询

    private static final String[] COLS = {
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.RELATIVE_PATH,
            MediaStore.MediaColumns.DATE_ADDED,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.WIDTH,
            MediaStore.MediaColumns.HEIGHT,
    };

    /**
     * 一次查出 root 下所有文件夹的照片，按「拍摄顺序」排列（DATE_ADDED 升序，同秒用 _ID 兜底）。
     * 返回 key = RELATIVE_PATH（尾部带斜杠），空文件夹不会出现在结果里。
     */
    static Map<String, List<Shot>> snapshot(Context ctx, String root) {
        Map<String, List<Shot>> map = new LinkedHashMap<>();
        String sel = MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ? ESCAPE '\\'";
        String[] args = {escapeLike(root + "/") + "%"};
        String order = MediaStore.MediaColumns.DATE_ADDED + " ASC, "
                + MediaStore.MediaColumns._ID + " ASC";

        Cursor c = null;
        try {
            c = ctx.getContentResolver().query(COLLECTION, COLS, sel, args, order);
            while (c != null && c.moveToNext()) {
                Shot s = new Shot();
                s.id = c.getLong(0);
                s.name = c.getString(1);
                s.rel = c.getString(2);
                s.dateAdded = c.getLong(3);
                s.size = c.getLong(4);
                s.width = c.getInt(5);
                s.height = c.getInt(6);
                s.uri = ContentUris.withAppendedId(COLLECTION, s.id);
                if (s.rel == null) continue;
                List<Shot> bucket = map.get(s.rel);
                if (bucket == null) {
                    bucket = new ArrayList<>();
                    map.put(s.rel, bucket);
                }
                bucket.add(s);
            }
        } catch (Exception ignored) {
            // 没权限 / 查询被拒时当作空
        } finally {
            if (c != null) c.close();
        }

        // 私有目录里的兜底照片并进同一个 key。
        // 注意：不能只遍历已有的 key —— 如果某个文件夹里「只有」私有兜底照片，
        // 它的 key 在 MediaStore 结果里根本不存在，那样这些照片就永远显示不出来。
        java.util.Set<String> keys = new java.util.LinkedHashSet<>(map.keySet());
        for (String rel : privateFolders(ctx)) keys.add(rel);
        for (String rel : keys) {
            List<Shot> bucket = map.get(rel);
            if (bucket == null) {
                bucket = new ArrayList<>();
                map.put(rel, bucket);
            }
            bucket.addAll(listPrivate(ctx, rel));
        }
        return map;
    }

    /** 私有兜底目录下都有哪些文件夹（rel 形式）。 */
    private static java.util.Set<String> privateFolders(Context ctx) {
        java.util.Set<String> out = new java.util.LinkedHashSet<>();
        File base = new File(ctx.getFilesDir(), PRIVATE_DIR);
        File[] dirs = base.listFiles();
        if (dirs == null) return out;
        String root = new FolderStore(ctx).root();
        for (File d : dirs) {
            if (d.isDirectory()) out.add(root + "/" + d.getName() + "/");
        }
        return out;
    }

    /** SQLite LIKE 的通配符转义。 */
    private static String escapeLike(String s) {
        return s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_");
    }

    static List<Shot> listIn(Context ctx, String root, String rel) {
        List<Shot> v = snapshot(ctx, root).get(rel);
        return v == null ? new ArrayList<Shot>() : v;
    }

    // ------------------------------------------------------------------ 建 / 发布 / 删

    /** 在目标文件夹里占一个空的 pending 行，把它的 URI 交给系统相机去写。 */
    static Uri createPending(Context ctx, String rel, String displayName) {
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, displayName);
        v.put(MediaStore.MediaColumns.MIME_TYPE, MIME);
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, rel);
        v.put(MediaStore.MediaColumns.IS_PENDING, 1);
        return ctx.getContentResolver().insert(COLLECTION, v);
    }

    /** 拍完了：清掉 IS_PENDING，让这张图对其他 App（相册、文件管理器）可见。 */
    static boolean publish(Context ctx, Uri uri) {
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.IS_PENDING, 0);
        return ctx.getContentResolver().update(uri, v, null, null) > 0;
    }

    static boolean remove(Context ctx, Shot s) {
        // 私有目录的文件直接删；公共目录的优先走 MediaStore（这样相册索引也一起清掉）
        if (s.isPrivate()) return s.file != null && s.file.delete();
        if (s.uri != null && s.id != 0) {
            try {
                if (ctx.getContentResolver().delete(s.uri, null, null) > 0) return true;
            } catch (Exception ignored) {
            }
        }
        // 还没进 MediaStore 的（刚拍完直写的文件），直接删磁盘文件
        return s.file != null && s.file.delete();
    }

    /** 相机返回后校验：文件到底写进去没有。
     *
     * 【重要】不能只信 MediaStore 的 _size：刚写完的 pending 行这个字段可能还是 NULL，
     * 那样会把拍好的照片误判成「没写进去」，然后删掉占位行（连带删掉磁盘上的照片），
     * 表现就是：拍完照、文件夹却空了、App 里也看不到。
     * 所以优先用文件描述符问真实大小，并且给 MediaStore 一点刷新时间。
     */
    static long sizeOf(Context ctx, Uri uri) {
        for (int i = 0; i < 8; i++) {
            long n = probeSize(ctx, uri);
            if (n > 0) return n;
            try {
                Thread.sleep(150);
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
                break;
            }
        }
        return 0L;
    }

    /**
     * 兜底：相机如果不认 EXTRA_OUTPUT，可能把照片写到了它自己的默认目录。
     * 这里在「拍完照之后」去 MediaStore 里找刚刚出现的新照片，
     * 把它挪进我们的目标文件夹。需要 MANAGE_EXTERNAL_STORAGE（否则改不了别人的文件）。
     *
     * @param sinceMs 只认这个时间点之后新增的记录
     * @return 收编成功的张数
     */
    static int adoptOrphans(Context ctx, String root, String rel, long sinceMs) {
        if (!hasAllFilesAccess(ctx)) return 0;
        int adopted = 0;
        String[] cols = {
                MediaStore.MediaColumns._ID,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.RELATIVE_PATH,
                MediaStore.MediaColumns.DATE_ADDED,
        };
        long sinceSec = sinceMs / 1000L - 5;
        String sel = MediaStore.MediaColumns.DATE_ADDED + " >= ?";
        String order = MediaStore.MediaColumns.DATE_ADDED + " DESC";
        Cursor c = null;
        try {
            c = ctx.getContentResolver().query(COLLECTION, cols, sel,
                    new String[]{String.valueOf(sinceSec)}, order);
            while (c != null && c.moveToNext()) {
                long id = c.getLong(0);
                String name = c.getString(1);
                String r = c.getString(2);
                if (name == null || r == null) continue;
                // 已经在我们的目录里，或有其他 App 的目录，就跳过
                if (r.startsWith(root + "/")) continue;
                // 只认相机拍的照片
                if (!name.toUpperCase(Locale.US).startsWith("IMG")
                        && !name.toUpperCase(Locale.US).startsWith("MVIMG")) {
                    continue;
                }
                Uri uri = ContentUris.withAppendedId(COLLECTION, id);
                Shot s = new Shot();
                s.id = id;
                s.uri = uri;
                s.name = name;
                s.rel = r;
                String target = uniqueName(ctx, rel, name);
                if (move(ctx, s, rel, target)) {
                    adopted++;
                    Log.i("FolderCam", "收编相机写到别处的照片: " + r + name + " -> " + rel);
                }
            }
        } catch (Exception e) {
            Log.w("FolderCam", "收编失败: " + e);
        } finally {
            if (c != null) c.close();
        }
        return adopted;
    }

    /**
     * 我们能不能往公共目录直接写文件（也就是能不能用 file:// 作为相机输出）。
     *
     * 注意各版本拿权限的方式不同：
     *   Android 11+ (API 30)  MANAGE_EXTERNAL_STORAGE（「所有文件访问」，手动开）
     *   Android 10 及以下      没有这个权限，靠 WRITE_EXTERNAL_STORAGE 运行时权限
     */
    static boolean hasAllFilesAccess(Context ctx) {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                return android.os.Environment.isExternalStorageManager();
            } catch (Throwable t) {
                return false;
            }
        }
        return ctx.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == android.content.pm.PackageManager.PERMISSION_GRANTED;
    }

    /** Android 10 及以下需要在运行时申请这个权限。 */
    static String legacyWritePermission() {
        return android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
    }

    /**
     * 这台设备的相机是不是「必须给 file:// 才肯写」。
     *
     * MIUI/HyperOS 的相机对 content:// 形式的 EXTRA_OUTPUT 有 bug：它把保存路径
     * 硬编码成 DCIM/Camera，MediaStore 记录建不起来，照片在内存里拍完就丢。
     * 换成 file:// 才正常。
     *
     * 反过来，AOSP/Pixel/三星这类系统的相机是沙盒应用，写不了 file:// 指向的
     * 公共目录路径（我们的权限不能借给它），必须走 content://。
     * 所以要按 ROM 选主路径，而不是无脑用某一种。
     */
    static boolean cameraPrefersFileUri() {
        try {
            // MIUI 专有类，最可靠的判据
            Class.forName("miui.os.Build");
            return true;
        } catch (Throwable ignored) {
        }
        String m = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.toLowerCase(Locale.US);
        String b = Build.BRAND == null ? "" : Build.BRAND.toLowerCase(Locale.US);
        return m.contains("xiaomi") || m.contains("redmi") || m.contains("poco")
                || b.contains("xiaomi") || b.contains("redmi") || b.contains("poco");
    }

    /**
     * 相机可能写出 HEIC/HEIF 内容，但文件名还是我们给的 .jpg
     * （三星、Pixel 默认拍 HEIC 时会这样）。内容对不上扩展名，
     * 有些相册/微信会打不开，所以按文件头纠正一下扩展名。
     *
     * @return 纠正后的文件名；不需要改就返回原名
     */
    static String fixExtensionByContent(File f, String name) {
        if (f == null || !f.exists() || name == null) return name;
        try {
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            byte[] head = new byte[12];
            int n;
            try {
                n = in.read(head);
            } finally {
                in.close();
            }
            if (n < 12) return name;

            String want = null;
            if ((head[0] & 0xFF) == 0xFF && (head[1] & 0xFF) == 0xD8) {
                want = ".jpg";
            } else if (head[4] == 'f' && head[5] == 't' && head[6] == 'y' && head[7] == 'p') {
                String brand = new String(head, 8, 4, java.nio.charset.StandardCharsets.US_ASCII)
                        .toLowerCase(Locale.US);
                if (brand.startsWith("hei") || brand.startsWith("mif") || brand.startsWith("msf")
                        || brand.startsWith("mif1")) {
                    want = ".heic";
                }
            } else if ((head[0] & 0xFF) == 0x89 && head[1] == 'P') {
                want = ".png";
            }
            if (want == null) return name;

            int dot = name.lastIndexOf('.');
            String stem = dot > 0 ? name.substring(0, dot) : name;
            String have = dot > 0 ? name.substring(dot).toLowerCase(Locale.US) : "";
            // jpg / jpeg 视为同一种
            boolean same = have.equals(want)
                    || (want.equals(".jpg") && have.equals(".jpeg"));
            if (same) return name;

            File dst = new File(f.getParentFile(), stem + want);
            if (dst.exists()) return name;
            if (f.renameTo(dst)) {
                Log.i("FolderCam", "按内容纠正扩展名: " + name + " -> " + dst.getName());
                return dst.getName();
            }
        } catch (Exception e) {
            Log.w("FolderCam", "纠正扩展名失败: " + e);
        }
        return name;
    }

    private static long probeSize(Context ctx, Uri uri) {
        // 1) 文件描述符的 statSize —— 最可靠，直接反映磁盘上的真实大小
        ParcelFileDescriptor pfd = null;
        try {
            pfd = ctx.getContentResolver().openFileDescriptor(uri, "r");
            if (pfd != null) {
                long n = pfd.getStatSize();
                if (n > 0) return n;
            }
        } catch (Exception ignored) {
        } finally {
            if (pfd != null) {
                try {
                    pfd.close();
                } catch (Exception ignored) {
                }
            }
        }
        // 2) 退回 MediaStore 的 _size
        Cursor c = null;
        try {
            c = ctx.getContentResolver().query(uri,
                    new String[]{MediaStore.MediaColumns.SIZE}, null, null, null);
            if (c != null && c.moveToFirst() && !c.isNull(0)) {
                return c.getLong(0);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return 0L;
    }

    /** 私有兜底文件的大小；同样给一点写入完成的时间。 */
    static long sizeOfFile(File f) {
        // 相机是异步写盘的：给了确认之后还可能过几秒才落盘。
        // 所以这里耐心一点（最多约 12 秒），别把刚拍好的照片判成「没拍到」。
        for (int i = 0; i < 80; i++) {
            if (f != null && f.length() > 0) return f.length();
            try {
                Thread.sleep(150);
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
                break;
            }
        }
        return f == null ? 0L : f.length();
    }

    // ------------------------------------------------------------------ 公共目录直写（file:// 输出）

    /**
     * 在公共目录里直接建一个空文件。
     *
     * 【为什么需要它】MIUI 相机不认 content:// 形式的 EXTRA_OUTPUT：
     * 它会把自己的保存路径硬编码成 DCIM/Camera，最后照片在内存里处理完就丢了
     * （日志：setShotSavePath=/storage/emulated/0/DCIM/Camera/xxx.jpg，
     *        DbItemSaveTask: updateFinalImageState ... update count 0）。
     * 换成 file:// 路径它才肯按我们说的写。实测：4.6MB 照片正常落盘。
     * 代价是要有「所有文件访问」权限（MANAGE_EXTERNAL_STORAGE）。
     */
    static File newPublicFile(String rel, String name) {
        File root = android.os.Environment.getExternalStorageDirectory();
        File dir = new File(root, rel);
        if (!dir.exists() && !dir.mkdirs()) return null;
        return new File(dir, name);
    }

    /** 公共目录里某个文件夹下某个文件的真实路径（我们有所有文件访问，能直接读）。 */
    static File publicFilePath(Context ctx, String rel, String name) {
        if (rel == null || name == null) return null;
        try {
            File root = android.os.Environment.getExternalStorageDirectory();
            return new File(new File(root, rel), name);
        } catch (Throwable t) {
            return null;
        }
    }

    /** 让刚写进去的文件被 MediaStore 收录，这样相册和本 App 都能看到。 */
    static void scanFile(Context ctx, File f) {
        if (f == null || !f.exists()) return;
        try {
            android.media.MediaScannerConnection.scanFile(
                    ctx, new String[]{f.getAbsolutePath()}, new String[]{MIME}, null);
        } catch (Exception e) {
            Log.w("FolderCam", "scanFile 失败: " + e);
        }
    }

    // ------------------------------------------------------------------ 改名 / 移动

    /**
     * 给单张照片改名（保持在同一个文件夹里）。
     * MediaStore 记录的改名走 update DISPLAY_NAME，磁盘文件会跟着改。
     *
     * @return null 表示成功，否则是给用户看的失败原因
     */
    static String rename(Context ctx, Shot s, String newName) {
        String clean = FolderStore.sanitize(newName);
        if (clean == null) return "文件名不能为空";
        // 保留原扩展名，避免改成没有后缀的名字后相册认不出来
        if (clean.lastIndexOf('.') <= 0) {
            String old = s.name == null ? "" : s.name;
            int dot = old.lastIndexOf('.');
            if (dot > 0) clean = clean + old.substring(dot);
        }
        if (clean.equals(s.name)) return null;

        String rel = s.rel;
        // 同文件夹内不能重名
        for (Shot other : listIn(ctx, rootOf(rel), rel)) {
            if (other != s && other.name != null
                    && other.name.equalsIgnoreCase(clean)) {
                return "这个文件夹里已经有叫「" + clean + "」的文件了";
            }
        }

        if (s.isPrivate()) {
            File dst = newPrivateFile(ctx, rel, clean);
            if (dst == null) return "改名失败";
            if (!s.file.renameTo(dst)) return "改名失败";
            s.file = dst;
            s.name = clean;
            return null;
        }

        if (s.id == 0 || s.uri == null) {
            // 刚拍完、还没被 MediaStore 收录的文件：直接改磁盘名
            if (s.file == null) return "文件不存在";
            File dst = newPublicFile(rel, clean);
            if (dst == null) return "改名失败";
            if (!s.file.renameTo(dst)) return "改名失败";
            s.file = dst;
            s.name = clean;
            scanFile(ctx, dst);
            return null;
        }

        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, clean);
            if (ctx.getContentResolver().update(s.uri, v, null, null) <= 0) {
                return "改名失败";
            }
            s.name = clean;
            return null;
        } catch (Exception e) {
            return "改名失败：" + e.getMessage();
        }
    }

    /** 目标文件夹里已有同名文件时，追加 _1 / _2 … */
    static String uniqueName(Context ctx, String rel, String desired) {
        java.util.Set<String> taken = new java.util.HashSet<>();
        for (Shot s : listIn(ctx, rootOf(rel), rel)) taken.add(s.name == null ? "" : s.name.toLowerCase(Locale.US));
        if (!taken.contains(desired.toLowerCase(Locale.US))) return desired;
        int dot = desired.lastIndexOf('.');
        String base = dot > 0 ? desired.substring(0, dot) : desired;
        String ext = dot > 0 ? desired.substring(dot) : "";
        for (int i = 1; i < 1000; i++) {
            String cand = base + "_" + i + ext;
            if (!taken.contains(cand.toLowerCase(Locale.US))) return cand;
        }
        return base + "_" + System.currentTimeMillis() + ext;
    }

    /** "Pictures/FolderCam/A/" -> "Pictures/FolderCam" */
    private static String rootOf(String rel) {
        String r = rel.endsWith("/") ? rel.substring(0, rel.length() - 1) : rel;
        int i = r.lastIndexOf('/');
        return i > 0 ? r.substring(0, i) : r;
    }

    /** 把一张照片挪到别的文件夹：先置 pending，改 RELATIVE_PATH，再取消 pending。 */
    static boolean move(Context ctx, Shot s, String newRel, String newName) {
        // 私有兜底文件：直接改文件名
        if (s.isPrivate()) {
            File dst = newPrivateFile(ctx, newRel, newName);
            if (dst == null) return false;
            return s.file.renameTo(dst);
        }
        // 公共目录里还没进 MediaStore 的文件（刚拍完直写的）：直接移动磁盘文件
        if (s.id == 0 || s.uri == null) {
            if (s.file == null) return false;
            File dst = newPublicFile(newRel, newName);
            if (dst == null) return false;
            if (!s.file.renameTo(dst)) return false;
            scanFile(ctx, dst);
            return true;
        }
        // 正经的 MediaStore 记录：让 MediaStore 帮我们搬（会一起挪物理文件）
        ContentResolver cr = ctx.getContentResolver();
        try {
            ContentValues p = new ContentValues();
            p.put(MediaStore.MediaColumns.IS_PENDING, 1);
            cr.update(s.uri, p, null, null);

            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, newRel);
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, newName);
            v.put(MediaStore.MediaColumns.IS_PENDING, 0);
            boolean ok = cr.update(s.uri, v, null, null) > 0;
            if (!ok) {
                ContentValues back = new ContentValues();
                back.put(MediaStore.MediaColumns.IS_PENDING, 0);
                cr.update(s.uri, back, null, null);
            }
            return ok;
        } catch (Exception e) {
            return false;
        }
    }

    // ------------------------------------------------------------------ 私有目录兜底

    static File newPrivateFile(Context ctx, String rel, String name) {
        String tail = rel.endsWith("/") ? rel.substring(0, rel.length() - 1) : rel;
        int i = tail.lastIndexOf('/');
        String folder = i >= 0 ? tail.substring(i + 1) : tail;
        File dir = new File(new File(ctx.getFilesDir(), PRIVATE_DIR), folder);
        if (!dir.exists() && !dir.mkdirs()) return null;
        return new File(dir, name);
    }

    static Uri privateUri(Context ctx, File f) {
        return LocalFileProvider.uriFor(f);
    }

    static List<Shot> listPrivate(Context ctx, String rel) {
        List<Shot> out = new ArrayList<>();
        String tail = rel.endsWith("/") ? rel.substring(0, rel.length() - 1) : rel;
        int i = tail.lastIndexOf('/');
        String folder = i >= 0 ? tail.substring(i + 1) : tail;
        File dir = new File(new File(ctx.getFilesDir(), PRIVATE_DIR), folder);
        File[] files = dir.listFiles();
        if (files == null) return out;
        for (File f : files) {
            if (!f.isFile() || f.length() == 0) continue;
            Shot s = new Shot();
            s.file = f;
            s.privateDir = true;
            s.name = f.getName();
            s.rel = rel;
            s.size = f.length();
            s.dateAdded = f.lastModified() / 1000L;
            s.uri = privateUri(ctx, f);
            out.add(s);
        }
        Collections.sort(out, new Comparator<Shot>() {
            @Override
            public int compare(Shot a, Shot b) {
                return Long.compare(a.dateAdded, b.dateAdded);
            }
        });
        return out;
    }

    /** 把私有目录里的照片搬进 Pictures/FolderCam/<文件夹>/，然后删掉私有副本。 */
    static boolean exportPrivate(Context ctx, Shot s, String rel) {
        if (!s.isPrivate()) return false;
        Uri dst = createPending(ctx, rel, uniqueName(ctx, rel, s.name));
        if (dst == null) return false;
        InputStream in = null;
        OutputStream out = null;
        try {
            in = new java.io.FileInputStream(s.file);
            out = ctx.getContentResolver().openOutputStream(dst);
            if (out == null) throw new java.io.IOException("no stream");
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.flush();
        } catch (Exception e) {
            try {
                ctx.getContentResolver().delete(dst, null, null);
            } catch (Exception ignored) {
            }
            return false;
        } finally {
            closeQuietly(in);
            closeQuietly(out);
        }
        publish(ctx, dst);
        return s.file.delete();
    }

    private static void closeQuietly(java.io.Closeable c) {
        if (c == null) return;
        try {
            c.close();
        } catch (Exception ignored) {
        }
    }

    // ------------------------------------------------------------------ 展示用

    static String humanSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format(Locale.US, "%.0f KB", bytes / 1024.0);
        return String.format(Locale.US, "%.1f MB", bytes / 1048576.0);
    }

    static String humanDate(long epochSeconds) {
        return new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
                .format(new java.util.Date(epochSeconds * 1000L));
    }
}
