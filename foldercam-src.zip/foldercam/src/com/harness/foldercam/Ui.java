package com.harness.foldercam;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** 尺寸、颜色、圆角、insets 等零碎工具。UI 全部用代码搭，不依赖 AndroidX。 */
final class Ui {
    static final int BG = 0xFFFFFFFF;
    static final int SURFACE = 0xFFF5F6F8;
    static final int INK = 0xFF16181D;
    static final int INK2 = 0xFF6B7280;
    static final int INK3 = 0xFF9AA1AC;
    static final int LINE = 0xFFE6E8EC;
    static final int ACCENT = 0xFF2F6BFF;
    static final int DANGER = 0xFFE5484D;
    static final int WARN_BG = 0xFFFFF7E6;
    static final int WARN_FG = 0xFF8A6100;

    private Ui() {
    }

    // ---------- 尺寸 ----------

    static float dp(Context c, float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                c.getResources().getDisplayMetrics());
    }

    static int dpi(Context c, float v) {
        return Math.round(dp(c, v));
    }

    static void padding(View v, Context c, float l, float t, float r, float b) {
        v.setPadding(dpi(c, l), dpi(c, t), dpi(c, r), dpi(c, b));
    }

    static void margin(View v, Context c, float l, float t, float r, float b) {
        // 注意：必须在 addView 之后（或已有 LayoutParams 时）才能调。
        // 这里做个保护，避免 NullPointerException 把整个界面搞崩。
        ViewGroup.LayoutParams raw = v.getLayoutParams();
        if (!(raw instanceof ViewGroup.MarginLayoutParams)) {
            throw new IllegalStateException(
                    "Ui.margin() 要在 addView 之后调用: " + v.getClass().getSimpleName());
        }
        ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) raw;
        lp.leftMargin = dpi(c, l);
        lp.topMargin = dpi(c, t);
        lp.rightMargin = dpi(c, r);
        lp.bottomMargin = dpi(c, b);
        v.setLayoutParams(lp);
    }

    static LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    static LinearLayout.LayoutParams lpw(float weight, int h) {
        return new LinearLayout.LayoutParams(0, h, weight);
    }

    // ---------- 背景 ----------

    static GradientDrawable round(int color, float radius, Context c) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(c, radius));
        return d;
    }

    static GradientDrawable roundStroke(int color, int stroke, float width, float radius, Context c) {
        GradientDrawable d = round(color, radius, c);
        d.setStroke(dpi(c, width), stroke);
        return d;
    }

    // ---------- 文本 ----------

    static TextView text(Context c, CharSequence s, float sp, int color) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setIncludeFontPadding(false);
        return t;
    }

    static TextView bold(TextView t) {
        t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
        return t;
    }

    /** 顶宽底窄、可点的文本按钮（最小点击区 44dp）。 */
    static TextView action(Context c, CharSequence s, int color) {
        TextView t = text(c, s, 14, color);
        t.setGravity(android.view.Gravity.CENTER);
        t.setBackground(round(0x00000000, 8, c));
        t.setPadding(dpi(c, 12), dpi(c, 10), dpi(c, 12), dpi(c, 10));
        t.setMinWidth(dpi(c, 44));
        t.setMinHeight(dpi(c, 44));
        return t;
    }

    static void toast(Context c, CharSequence s) {
        Toast.makeText(c, s, Toast.LENGTH_SHORT).show();
    }

    // ---------- 边到边显示：把系统栏高度变成 padding ----------

    static void applyInsets(final View root, final boolean top, final boolean bottom) {
        final int pl = root.getPaddingLeft(), pt = root.getPaddingTop();
        final int pr = root.getPaddingRight(), pb = root.getPaddingBottom();
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets in) {
                int t = top ? in.getSystemWindowInsetTop() : 0;
                int b = bottom ? in.getSystemWindowInsetBottom() : 0;
                v.setPadding(pl + in.getSystemWindowInsetLeft(), pt + t,
                        pr + in.getSystemWindowInsetRight(), pb + b);
                return in;
            }
        });
    }

    /** API 30+ 用新接口关掉系统的自动避让；29 用旧 flag。 */
    static void edgeToEdge(android.view.Window w) {
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
        } else {
            w.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
    }

    // ---------- 快门按钮 ----------

    /** 相机风格的大圆快门：外圈细描边 + 内圈实心，按下时内圈缩小。 */
    static final class Shutter extends View {
        private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private boolean pressed;

        Shutter(Context c) {
            super(c);
            ringPaint.setStyle(Paint.Style.STROKE);
            ringPaint.setStrokeWidth(dpi(c, 3));
            ringPaint.setColor(INK);
            dotPaint.setStyle(Paint.Style.FILL);
            dotPaint.setColor(ACCENT);
        }

        void setPressedState(boolean p) {
            if (pressed != p) {
                pressed = p;
                invalidate();
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float w = getWidth(), h = getHeight();
            float cx = w / 2f, cy = h / 2f;
            float outer = Math.min(w, h) / 2f - dp(getContext(), 3);
            canvas.drawCircle(cx, cy, outer, ringPaint);
            canvas.drawCircle(cx, cy, outer * (pressed ? 0.62f : 0.78f), dotPaint);
        }
    }
}
